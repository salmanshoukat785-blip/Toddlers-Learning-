#!/usr/bin/env python3
"""
Downloads 3D emoji PNGs (Microsoft Fluent Emoji, MIT licence) for every emoji used in the
app's Kotlin source, into app/src/main/res/drawable-nodpi/e_<codepoint>.png.

Runs automatically before every Gradle build (see app/build.gradle.kts). It never fails the
build: if the network is unavailable or an emoji is not found, the app simply shows the
normal text emoji for it.

Usage: python3 tools/fetch_emoji.py [--dry]
"""
import difflib
import json
import os
import re
import sys
import unicodedata
import urllib.error
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, "app", "src", "main", "java")
OUT = os.path.join(ROOT, "app", "src", "main", "res", "drawable-nodpi")
REPO = "microsoft/fluentui-emoji"
DRY = "--dry" in sys.argv

EMOJI_RE = re.compile("[\U0001F300-\U0001FAFF☀-➿⭐⭕⌚⌛⏩-⏳✅]")
SKIP = {0x2713, 0x2714, 0x2022}  # check marks etc. are plain symbols, not pictures

# Unicode name -> Fluent folder name, where the two differ.
ALIASES = {
    "dromedary camel": "camel", "aubergine": "eggplant", "ear of maize": "ear of corn",
    "long drum": "drum", "triangular flag on post": "triangular flag", "house building": "house",
    "electric light bulb": "light bulb", "athletic shoe": "running shoe",
    "steam locomotive": "locomotive", "black sun with rays": "sun", "ice cube": "ice",
    "earth globe europe-africa": "globe showing europe-africa", "dash symbol": "dashing away",
    "eyeglasses": "glasses", "lower left ballpoint pen": "pen", "laptop computer": "laptop",
    "bath": "bathtub", "medium white circle": "white circle", "medium black circle": "black circle",
    "sailboat": "sailboat", "white medium star": "star", "snow capped mountain": "snow-capped mountain",
    "lock": "locked", "wind blowing face": "wind face", "money with wings": "money with wings",
}


def emoji_set():
    found = set()
    for dirpath, _, files in os.walk(SRC):
        for f in files:
            if f.endswith(".kt"):
                with open(os.path.join(dirpath, f), encoding="utf-8") as fh:
                    for ch in EMOJI_RE.findall(fh.read()):
                        if ord(ch) not in SKIP:
                            found.add(ch)
    return sorted(found)


def http(url, binary=False):
    headers = {"User-Agent": "little-learners-build"}
    tok = os.environ.get("GITHUB_TOKEN")
    if tok and "api.github.com" in url:
        headers["Authorization"] = "Bearer " + tok
    req = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(req, timeout=30) as r:
        data = r.read()
    return data if binary else json.loads(data.decode("utf-8"))


def folder_names():
    try:
        tree = http(f"https://api.github.com/repos/{REPO}/git/trees/main:assets")
        return {t["path"].lower(): t["path"] for t in tree.get("tree", []) if t.get("type") == "tree"}
    except Exception as e:  # noqa: BLE001
        print("could not list emoji folders:", e)
        return {}


def candidates(ch):
    try:
        n = unicodedata.name(ch).lower()
    except ValueError:
        return []
    c = [n]
    if n in ALIASES:
        c.insert(0, ALIASES[n])
    for w in ("large ", "medium "):
        c.append(n.replace(w, ""))
    if n.endswith(" face"):
        c.append(n[:-5])
    c.append(n.replace("-", " "))
    return c


def resolve(ch, names):
    """Returns a list of Fluent folder names to try, best first."""
    cands = candidates(ch)
    if not cands:
        return []
    if not names:  # folder listing unavailable: guess names directly ("Dog face")
        out = []
        for c in cands:
            g = c[:1].upper() + c[1:]
            if g not in out:
                out.append(g)
        return out
    for c in cands:
        if c in names:
            return [names[c]]
    m = difflib.get_close_matches(cands[0], list(names), n=1, cutoff=0.82)
    return [names[m[0]]] if m else []


def download(item):
    ch, folders = item
    out = os.path.join(OUT, "e_%x.png" % ord(ch))
    if os.path.exists(out):
        return ch, True
    for folder in folders:
        fname = folder.lower().replace(" ", "_") + "_3d.png"
        url = "https://raw.githubusercontent.com/%s/main/assets/%s/3D/%s" % (
            REPO, urllib.parse.quote(folder), urllib.parse.quote(fname))
        try:
            data = http(url, binary=True)
            if data[:4] == b"\x89PNG":
                with open(out, "wb") as fh:
                    fh.write(data)
                return ch, True
        except Exception:  # noqa: BLE001
            continue
    return ch, False


def main():
    chars = emoji_set()
    print("emoji used in app:", len(chars))
    if DRY:
        for ch in chars:
            print(" ", ch, "U+%04X" % ord(ch), candidates(ch)[:2])
        return
    os.makedirs(OUT, exist_ok=True)
    names = folder_names()
    work, unresolved = [], []
    for ch in chars:
        folders = resolve(ch, names)
        if folders:
            work.append((ch, folders))
        else:
            unresolved.append(ch)
    with ThreadPoolExecutor(8) as ex:
        results = list(ex.map(download, work))
    ok = [c for c, good in results if good]
    bad = [c for c, good in results if not good]
    print("3D emoji ready: %d, failed: %d, not matched: %d" % (len(ok), len(bad), len(unresolved)))
    if bad or unresolved:
        print("using text emoji for:", " ".join(bad + unresolved))


if __name__ == "__main__":
    try:
        main()
    except Exception as e:  # noqa: BLE001
        print("emoji fetch skipped:", e)
