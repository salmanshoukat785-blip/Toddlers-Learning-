# Little Learners – test checklist (run on a real phone before sharing)

Install the APK, then tick each line.

**Home / basics**
- [ ] App opens, 13 category chips scroll, last category is remembered after closing the app
- [ ] Airplane mode: everything still works (no internet needed)
- [ ] Rotate phone: no crash

**Per category (spot-check Animals, Birds, Colors, Numbers)**
- [ ] English ABC: photo + word + sound for A–Z
- [ ] Urdu alphabet: photo + word, Urdu speaks
- [ ] Numbers 1–20 with pictures
- [ ] No missing/blank pictures

**Games & Quizzes**
- [ ] Memory (3 levels), Match, Puzzle (2×2, 3×3) can be completed
- [ ] Quizzes: Name, Letter, اردو, Odd one finish and show score
- [ ] Categories with fewer than 8 items show "Coming soon" (no crash)

**Phase 5**
- [ ] Stars go up after a game/quiz; Sticker Book unlocks 1 sticker per 2 stars
- [ ] Animal Sounds: sound plays, "Who says?" quiz works
- [ ] Worlds: all 5 worlds, Explore + Find it
- [ ] Music: piano keys make sound, 3 songs play with lit keys (volume up!)
- [ ] Stories: 5 stories read aloud, Next/Back, Finish gives stars
- [ ] Animal Care: all 5 meters fill → +3 stars

**Phase 6**
- [ ] Parents: sum gate works; set a PIN; PIN gate works; "Forgot PIN" works
- [ ] Progress tab numbers match what you played
- [ ] Set limit 15 min (test by temporarily choosing it and playing; or trust the logic) → "Time is up" screen; parent can add 15 min
- [ ] Reset progress clears stars

**If TTS is silent:** phone Settings → Language → Text-to-speech must have English and Urdu voices installed.
