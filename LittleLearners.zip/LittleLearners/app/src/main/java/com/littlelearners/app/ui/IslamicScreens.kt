@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.littlelearners.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.littlelearners.app.Speaker
import com.littlelearners.app.UrduLocale
import com.littlelearners.app.rememberSpeaker
import java.util.Locale

private val ArabicLocale = Locale("ar")

private class Item(val emoji: String, val title: String, val arabic: String, val urdu: String, val english: String)

// NOTE: please have an elder / scholar check the Arabic text before you publish.
private val duas = listOf(
    Item("🍽️", "Before eating (کھانے سے پہلے)", "بِسْمِ اللَّهِ", "اللہ کے نام سے", "In the name of Allah."),
    Item("😋", "After eating (کھانے کے بعد)", "الْحَمْدُ لِلَّهِ الَّذِي أَطْعَمَنَا وَسَقَانَا وَجَعَلَنَا مُسْلِمِينَ",
        "سب تعریف اللہ کے لیے ہے جس نے ہمیں کھلایا، پلایا اور مسلمان بنایا", "All praise is for Allah who fed us, gave us drink and made us Muslims."),
    Item("🛏️", "Before sleeping (سونے سے پہلے)", "بِاسْمِكَ اللَّهُمَّ أَمُوتُ وَأَحْيَا",
        "اے اللہ! تیرے نام کے ساتھ میں سوتا اور جاگتا ہوں", "O Allah, in Your name I sleep and I wake."),
    Item("🌅", "After waking up (جاگنے کے بعد)", "الْحَمْدُ لِلَّهِ الَّذِي أَحْيَانَا بَعْدَ مَا أَمَاتَنَا وَإِلَيْهِ النُّشُورُ",
        "سب تعریف اللہ کے لیے ہے جس نے ہمیں سلانے کے بعد جگایا اور اسی کی طرف لوٹنا ہے", "All praise is for Allah who gave us life after He made us sleep, and to Him we return."),
    Item("🚪", "Leaving home (گھر سے نکلتے وقت)", "بِسْمِ اللَّهِ تَوَكَّلْتُ عَلَى اللَّهِ وَلَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ",
        "اللہ کے نام سے، میں نے اللہ پر بھروسا کیا، طاقت اور قوت اللہ ہی سے ہے", "In the name of Allah, I trust in Allah; there is no power or strength except with Allah."),
    Item("🤧", "After sneezing (چھینک کے بعد)", "الْحَمْدُ لِلَّهِ", "سب تعریف اللہ کے لیے ہے", "All praise is for Allah."),
    Item("🙏", "Saying thank you (شکریہ)", "جَزَاكَ اللَّهُ خَيْرًا", "اللہ تمہیں بہتر بدلہ دے", "May Allah reward you with goodness."),
    Item("📚", "For knowledge (علم کے لیے)", "رَبِّ زِدْنِي عِلْمًا", "اے میرے رب! میرا علم بڑھا دے", "My Lord, increase me in knowledge."),
    Item("🤝", "Greeting (سلام)", "السَّلَامُ عَلَيْكُمْ", "تم پر سلامتی ہو", "Peace be upon you."),
    Item("✨", "Wonderful things (ماشاءاللہ)", "مَا شَاءَ اللَّهُ", "جو اللہ نے چاہا", "What Allah has willed."),
    Item("🌟", "Glory to Allah (سبحان اللہ)", "سُبْحَانَ اللَّهِ", "اللہ پاک ہے", "Glory be to Allah."),
    Item("🕌", "Allah is greatest (اللہ اکبر)", "اللَّهُ أَكْبَرُ", "اللہ سب سے بڑا ہے", "Allah is the Greatest.")
)

private val names = listOf(
    Item("💗", "Ar-Rahman", "الرَّحْمَن", "بہت مہربان", "The Most Merciful"),
    Item("🤲", "Ar-Raheem", "الرَّحِيم", "بہت رحم کرنے والا", "The Most Kind"),
    Item("👑", "Al-Malik", "الْمَلِك", "بادشاہ", "The King"),
    Item("🕊️", "As-Salam", "السَّلَام", "سلامتی دینے والا", "The Source of Peace"),
    Item("🌍", "Al-Khaliq", "الْخَالِق", "پیدا کرنے والا", "The Creator"),
    Item("🍞", "Ar-Razzaq", "الرَّزَّاق", "رزق دینے والا", "The Provider"),
    Item("💧", "Al-Ghafoor", "الْغَفُور", "بخشنے والا", "The Forgiving"),
    Item("🧠", "Al-Aleem", "الْعَلِيم", "سب کچھ جاننے والا", "The All-Knowing"),
    Item("❤️", "Al-Wadood", "الْوَدُود", "محبت کرنے والا", "The Loving"),
    Item("🛡️", "Al-Hafeez", "الْحَفِيظ", "حفاظت کرنے والا", "The Protector")
)

private val pillars = listOf(
    Item("☝️", "1. Kalma (کلمہ)", "لَا إِلَٰهَ إِلَّا اللَّهُ مُحَمَّدٌ رَسُولُ اللَّهِ", "اللہ کے سوا کوئی معبود نہیں، محمد ﷺ اللہ کے رسول ہیں", "There is no god but Allah; Muhammad (peace be upon him) is the messenger of Allah."),
    Item("🕌", "2. Namaz (نماز)", "الصَّلَاة", "دن میں پانچ نمازیں پڑھنا", "Praying five times a day."),
    Item("🌙", "3. Roza (روزہ)", "الصَّوْم", "رمضان میں روزے رکھنا", "Fasting in the month of Ramadan."),
    Item("💝", "4. Zakat (زکوٰۃ)", "الزَّكَاة", "اپنے مال میں سے غریبوں کا حق دینا", "Giving a share of wealth to the poor."),
    Item("🕋", "5. Hajj (حج)", "الْحَجّ", "مکہ میں خانہ کعبہ کا سفر کرنا", "Travelling to the Kaaba in Makkah.")
)

private val prayers = listOf(
    Item("🌄", "Fajr (فجر)", "الْفَجْر", "صبح سورج نکلنے سے پہلے • 2 رکعت فرض", "Before sunrise • 2 rakat fard"),
    Item("☀️", "Zuhr (ظہر)", "الظُّهْر", "دوپہر کے بعد • 4 رکعت فرض", "Afternoon • 4 rakat fard"),
    Item("🌤️", "Asr (عصر)", "الْعَصْر", "سہ پہر • 4 رکعت فرض", "Late afternoon • 4 rakat fard"),
    Item("🌇", "Maghrib (مغرب)", "الْمَغْرِب", "سورج ڈوبنے کے بعد • 3 رکعت فرض", "After sunset • 3 rakat fard"),
    Item("🌌", "Isha (عشاء)", "الْعِشَاء", "رات کو • 4 رکعت فرض", "Night • 4 rakat fard")
)

private val days = listOf(
    Item("🌙", "Ramadan (رمضان)", "رَمَضَان", "روزوں کا مبارک مہینہ", "The blessed month of fasting."),
    Item("🌃", "Sehri (سحری)", "", "صبح سے پہلے روزے کا کھانا", "The meal before dawn to start the fast."),
    Item("🍇", "Iftar (افطار)", "", "غروب آفتاب پر روزہ کھولنا", "Breaking the fast at sunset."),
    Item("🎉", "Eid ul Fitr (عید الفطر)", "عِيد", "رمضان کے بعد خوشی کی عید", "The happy festival after Ramadan."),
    Item("🐑", "Eid ul Adha (عید الاضحیٰ)", "عِيد", "قربانی کی عید", "The festival of sacrifice."),
    Item("🕌", "Masjid (مسجد)", "الْمَسْجِد", "نماز پڑھنے کی جگہ", "The place where we pray."),
    Item("📖", "Quran (قرآن)", "الْقُرْآن", "اللہ کی مقدس کتاب", "The holy book of Allah."),
    Item("🕋", "Kaaba (کعبہ)", "الْكَعْبَة", "مکہ میں اللہ کا گھر", "The House of Allah in Makkah.")
)

@Composable
private fun ItemCard(it: Item, accent: Color, speaker: Speaker) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(3.dp, accent),
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)
    ) {
        Column(Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("${it.emoji}  ${it.title}", fontSize = 17.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            if (it.arabic.isNotBlank()) {
                Spacer(Modifier.height(6.dp))
                Text(it.arabic, fontSize = 26.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center,
                    color = Color(0xFF2E7D32), modifier = Modifier.fillMaxWidth())
            }
            Spacer(Modifier.height(4.dp))
            Text(it.urdu, fontSize = 18.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            Text(it.english, fontSize = 15.sp, color = Color.Gray, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.Center, modifier = Modifier.fillMaxWidth()) {
                if (it.arabic.isNotBlank()) TextButton(onClick = { speaker.say(it.arabic, ArabicLocale, 0.7f) }) { Text("🔊 عربی") }
                TextButton(onClick = { speaker.say(it.urdu, UrduLocale) }) { Text("🔊 اردو") }
                TextButton(onClick = { speaker.say(it.english) }) { Text("🔊 EN") }
            }
        }
    }
}

@Composable
private fun Section(title: String, items: List<Item>, accent: Color, speaker: Speaker) {
    Text(title, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(top = 8.dp, bottom = 2.dp))
    items.forEach { ItemCard(it, accent, speaker) }
}

/** Duas, names of Allah, pillars, prayers and special days — with Arabic, Urdu and English, plus a quiz. */
@Composable
fun IslamicScreen(onBack: () -> Unit) {
    val accent = Color(0xFFA5D6A7)
    val speaker = rememberSpeaker()
    var tab by remember { mutableStateOf(0) }

    ScreenScaffold("Islamic Learning 🕌", accent, onBack) {
        TabsBar(listOf("Duas", "Names", "Basics", "Quiz"), tab, accent) { tab = it }
        Spacer(Modifier.height(8.dp))
        when (tab) {
            0 -> Column(Modifier.verticalScroll(rememberScrollState())) {
                duas.forEach { ItemCard(it, accent, speaker) }
            }
            1 -> Column(Modifier.verticalScroll(rememberScrollState())) {
                Text("Allah's beautiful names ✨", fontSize = 16.sp, color = Color.Gray)
                names.forEach { ItemCard(it, accent, speaker) }
            }
            2 -> Column(Modifier.verticalScroll(rememberScrollState())) {
                Section("5 Pillars of Islam", pillars, accent, speaker)
                Section("5 Daily Prayers", prayers, accent, speaker)
                Section("Special things", days, accent, speaker)
            }
            else -> QuizView(accent, speaker, "Islamic") {
                val mix = (duas.shuffled().take(3).map { it to 0 } + names.shuffled().take(2).map { it to 1 }).shuffled()
                mix.map { (item, kind) ->
                    val pool = if (kind == 0) duas else names
                    val wrong = pool.filter { it !== item }.shuffled().take(2)
                    val opts = (wrong + item).shuffled()
                    Question(
                        prompt = if (kind == 0) "When do we say this?" else "What does this name mean?",
                        big = item.arabic,
                        bigSize = 26,
                        options = opts.map { Option(if (kind == 0) it.title.substringBefore(" (") else it.english) },
                        correct = opts.indexOf(item),
                        say = item.arabic,
                        sayLocale = ArabicLocale
                    )
                }
            }
        }
    }
}
