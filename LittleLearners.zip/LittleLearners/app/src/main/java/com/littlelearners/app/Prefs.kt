package com.littlelearners.app

import android.content.Context

/** Local-only storage (no network, no login). */
class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("little_learners", Context.MODE_PRIVATE)

    var lastCategory: Category
        get() = Category.fromName(sp.getString(KEY_CATEGORY, null))
        set(value) = sp.edit().putString(KEY_CATEGORY, value.name).apply()

    private companion object {
        const val KEY_CATEGORY = "last_category"
    }
}
