@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.littlelearners.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.littlelearners.app.Rewards
import com.littlelearners.app.rememberSpeaker

private class Pet(val photo: String, val name: String)
private class Need(val emoji: String, val label: String, val cheer: String)

private val pets = listOf(
    Pet("an_rabbit", "Rabbit"), Pet("an_horse", "Horse"), Pet("an_cow", "Cow"),
    Pet("an_sheep", "Sheep"), Pet("bi_hen", "Hen"), Pet("bi_duck", "Duck"), Pet("an_panda", "Panda")
)

private val needs = listOf(
    Need("🍎", "Feed", "Yum yum! Thank you!"),
    Need("💧", "Water", "Glug glug! So refreshing!"),
    Need("🛁", "Wash", "Splash splash! So clean!"),
    Need("⚽", "Play", "Wheee! This is fun!"),
    Need("😴", "Sleep", "Zzz... good night!")
)

/** Animal Care: feed, water, wash, play and put the pet to sleep. Each tap fills a meter. */
@Composable
fun AnimalCareScreen(onBack: () -> Unit) {
    val accent = Color(0xFFFFAB91)
    val ctx = LocalContext.current
    val speaker = rememberSpeaker()
    var pet by remember { mutableStateOf(0) }
    var levels by remember(pet) { mutableStateOf(List(needs.size) { 1 }) }   // 0..4
    var rewarded by remember(pet) { mutableStateOf(false) }
    var message by remember(pet) { mutableStateOf("Take care of me!") }
    val allDone = levels.all { it >= 4 }
    val mood = when {
        allDone -> "😍"
        levels.average() >= 2.5 -> "😊"
        levels.average() >= 1.5 -> "🙂"
        else -> "🥺"
    }

    ScreenScaffold("Animal Care 🐾", accent, onBack) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            pets.forEachIndexed { i, p ->
                Card(
                    onClick = { pet = i },
                    colors = CardDefaults.cardColors(containerColor = if (i == pet) accent else Color.White),
                    border = BorderStroke(2.dp, accent),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Box(Modifier.fillMaxWidth().padding(3.dp), contentAlignment = Alignment.Center) {
                        PhotoImage(p.photo, Modifier.size(40.dp))
                    }
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            PhotoImage(pets[pet].photo, Modifier.size(170.dp))
        }
        Text(
            "$mood  ${if (allDone) "I am so happy! Thank you!" else message}",
            fontSize = 20.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
        )
        needs.forEachIndexed { i, n ->
            Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                Card(
                    onClick = {
                        if (levels[i] < 4) {
                            levels = levels.toMutableList().also { it[i] = it[i] + 1 }
                        }
                        message = n.cheer
                        speaker.say(n.cheer)
                        if (levels.all { it >= 4 } && !rewarded) {
                            rewarded = true
                            Rewards.add(ctx, 3)
                            speaker.say("${pets[pet].name} is happy! You get 3 stars!")
                        }
                    },
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(2.dp, accent),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.width(120.dp)
                ) {
                    Text("${n.emoji} ${n.label}", fontSize = 18.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(10.dp))
                }
                Spacer(Modifier.width(10.dp))
                LinearProgressIndicator(
                    progress = { levels[i] / 4f },
                    color = if (levels[i] >= 4) Color(0xFF66BB6A) else accent,
                    modifier = Modifier.weight(1f).height(14.dp)
                )
            }
        }
        if (allDone) {
            Spacer(Modifier.height(8.dp))
            Text("⭐ +3 stars! Pick another pet to care for.", fontSize = 16.sp, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth())
        }
    }
}
