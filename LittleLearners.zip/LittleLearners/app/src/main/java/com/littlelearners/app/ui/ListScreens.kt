@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.littlelearners.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.littlelearners.app.Category
import com.littlelearners.app.UrduLocale
import com.littlelearners.app.englishAlphabetFor
import com.littlelearners.app.numberItemsFor
import com.littlelearners.app.rememberSpeaker

/** One page that lists everything in the selected category. Tap the English or Urdu name to hear it. */
@Composable
fun LearningListScreen(category: Category, onBack: () -> Unit) {
    val accent = Color(0xFF80CBC4)
    val speaker = rememberSpeaker()
    val letters = remember(category) { englishAlphabetFor(category).filter { it.photo != null } }
    val numbers = remember(category) { numberItemsFor(category).orEmpty() }
    var tab by remember { mutableStateOf(0) }

    ScreenScaffold("Learning List ${category.emoji}", accent, onBack) {
        TabsBar(listOf("A – Z  (${letters.size})", "1 – 20  (${numbers.size})"), tab, accent) { tab = it }
        Spacer(Modifier.height(8.dp))
        Text("Tap a name to hear it 🔊", fontSize = 14.sp, color = Color.Gray,
            modifier = Modifier.align(Alignment.CenterHorizontally))
        Spacer(Modifier.height(6.dp))

        if (tab == 0) {
            if (letters.isEmpty()) { ComingSoon(accent, category); return@ScreenScaffold }
            LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                itemsIndexed(letters) { _, l ->
                    ListRow(
                        badge = "${l.letter}${l.letter.lowercaseChar()}",
                        photo = l.photo!!,
                        en = l.word,
                        ur = l.urdu,
                        accent = accent,
                        onEn = { speaker.say(l.word) },
                        onUr = { if (l.urdu.isNotBlank()) speaker.say(l.urdu, UrduLocale) }
                    )
                }
            }
        } else {
            if (numbers.isEmpty()) { ComingSoon(accent, category); return@ScreenScaffold }
            LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                itemsIndexed(numbers) { i, n ->
                    ListRow(
                        badge = "${i + 1}",
                        photo = n.photo,
                        en = n.en,
                        ur = n.ur,
                        accent = accent,
                        onEn = { speaker.say(n.en) },
                        onUr = { speaker.say(n.ur, UrduLocale) }
                    )
                }
            }
        }
    }
}

@Composable
private fun ListRow(
    badge: String, photo: String, en: String, ur: String, accent: Color,
    onEn: () -> Unit, onUr: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(2.dp, accent),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.width(52.dp), contentAlignment = Alignment.Center) {
                Text(badge, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
            }
            PhotoImage(photo, Modifier.size(76.dp))
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(en, fontSize = 20.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.clickable(onClick = onEn).padding(vertical = 6.dp))
                if (ur.isNotBlank()) {
                    Text(ur, fontSize = 22.sp, textAlign = TextAlign.Start,
                        modifier = Modifier.clickable(onClick = onUr).padding(vertical = 6.dp))
                }
            }
        }
    }
}
