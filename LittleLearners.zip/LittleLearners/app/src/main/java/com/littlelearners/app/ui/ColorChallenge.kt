package com.littlelearners.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.littlelearners.app.NamedColor
import com.littlelearners.app.ParentStore
import com.littlelearners.app.Rewards
import com.littlelearners.app.Speaker
import com.littlelearners.app.mixPalette
import com.littlelearners.app.mixResults

private const val ROUNDS = 5

/** "Make this color!" game: the child picks two paint colors that mix into the target. */
@Composable
fun ColorChallenge(accent: Color, speaker: Speaker) {
    val ctx = LocalContext.current
    val targets = remember { mixResults.values.toList() }
    var round by remember { mutableStateOf(0) }
    var score by remember { mutableStateOf(0) }
    var order by remember { mutableStateOf(targets.shuffled()) }
    var a by remember { mutableStateOf<NamedColor?>(null) }
    var b by remember { mutableStateOf<NamedColor?>(null) }
    var feedback by remember { mutableStateOf("") }
    var solved by remember { mutableStateOf(false) }

    if (round >= ROUNDS) {
        LaunchedEffect(Unit) {
            Rewards.add(ctx, score)
            speaker.say("Well done! $score out of $ROUNDS")
        }
        Text("🎉", fontSize = 80.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        Text(
            "$score / $ROUNDS", fontSize = 40.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center
        )
        Text(
            "⭐ x $score", fontSize = 28.sp,
            modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = { order = targets.shuffled(); round = 0; score = 0; a = null; b = null; feedback = ""; solved = false },
            modifier = Modifier.fillMaxWidth().height(54.dp)
        ) { Text("Play again", fontSize = 18.sp) }
        return
    }

    val target = order[round % order.size]
    LaunchedEffect(round) { speaker.say("Make ${target.en}") }

    Text("Round ${round + 1} of $ROUNDS", fontSize = 16.sp, color = Color.Gray)
    Text("Make this color!", fontWeight = FontWeight.Bold, fontSize = 24.sp)
    Spacer(Modifier.height(8.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
        Card(
            colors = CardDefaults.cardColors(containerColor = target.color),
            shape = CircleShape,
            border = BorderStroke(2.dp, Color.Gray),
            modifier = Modifier.height(110.dp).aspectRatio(1f)
        ) {}
    }
    Text(
        target.en, fontSize = 28.sp, fontWeight = FontWeight.Bold,
        modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center
    )
    Spacer(Modifier.height(10.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
        MixDot(a?.color)
        Text("  +  ", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        MixDot(b?.color)
    }
    Spacer(Modifier.height(10.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        mixPalette.forEach { c ->
            Card(
                onClick = {
                    if (solved) return@Card
                    speaker.say(c.en)
                    if (a == null) a = c
                    else if (b == null && c != a) b = c
                    else if (b == null) feedback = "Pick a different color!"
                    val x = a; val y = b
                    if (x != null && y != null) {
                        val got = mixResults[setOf(x.en, y.en)]
                        if (got == target) {
                            solved = true; score++
                            feedback = "✅ ${x.en} + ${y.en} = ${target.en}"
                            ParentStore.recordAnswer(ctx, "Mixing", true)
                            speaker.say("Great! ${x.en} and ${y.en} make ${target.en}")
                        } else {
                            feedback = "Try again! 🙂"
                            ParentStore.recordAnswer(ctx, "Mixing", false)
                            a = null; b = null
                        }
                    }
                },
                colors = CardDefaults.cardColors(containerColor = c.color),
                border = BorderStroke(if (c == a || c == b) 5.dp else 1.dp, if (c == a || c == b) accent else Color.LightGray),
                shape = CircleShape,
                modifier = Modifier.weight(1f).aspectRatio(1f)
            ) {}
        }
    }
    Spacer(Modifier.height(10.dp))
    Text(
        feedback, fontSize = 22.sp, fontWeight = FontWeight.Bold,
        modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center
    )
    Spacer(Modifier.height(8.dp))
    if (solved) {
        Button(
            onClick = { round++; a = null; b = null; feedback = ""; solved = false },
            modifier = Modifier.fillMaxWidth().height(54.dp)
        ) { Text(if (round == ROUNDS - 1) "Finish ⭐" else "Next ➡", fontSize = 18.sp) }
    }
}

@Composable
private fun MixDot(color: Color?) {
    Card(
        colors = CardDefaults.cardColors(containerColor = color ?: Color(0xFFEEEEEE)),
        shape = CircleShape,
        border = BorderStroke(1.dp, Color.LightGray),
        modifier = Modifier.height(60.dp).aspectRatio(1f)
    ) {
        if (color == null) Text("?", fontSize = 26.sp, color = Color.Gray, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
    }
}
