@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.littlelearners.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.littlelearners.app.LearningModule
import com.littlelearners.app.ParentStore
import com.littlelearners.app.Rewards

/** Asks for the parent PIN (if one is set) or a simple sum. Calls onPass when correct. */
@Composable
fun ParentCheck(onPass: () -> Unit, onCancel: () -> Unit) {
    val ctx = LocalContext.current
    val pin = remember { ParentStore.pin(ctx) }
    var useSum by remember { mutableStateOf(pin == null) }
    val a = remember { (3..9).random() }
    val b = remember { (3..9).random() }
    var answer by remember { mutableStateOf("") }
    var wrong by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("Parents only 🔒", style = MaterialTheme.typography.headlineLarge)
        Spacer(Modifier.height(12.dp))
        Text(if (useSum) "What is $a + $b ?" else "Enter your 4-digit PIN", fontSize = 22.sp)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = answer,
            onValueChange = { answer = it.filter(Char::isDigit).take(if (useSum) 2 else 4); wrong = false },
            singleLine = true,
            visualTransformation = if (useSum) androidx.compose.ui.text.input.VisualTransformation.None else PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
        )
        if (wrong) Text("Try again", color = MaterialTheme.colorScheme.error)
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = onCancel) { Text("Back") }
            Button(onClick = {
                val ok = if (useSum) answer.toIntOrNull() == a + b else answer == pin
                if (ok) onPass() else wrong = true
            }) { Text("Enter") }
        }
        if (!useSum) {
            TextButton(onClick = { useSum = true; answer = ""; wrong = false }) { Text("Forgot PIN? Solve a sum instead") }
        }
    }
}

@Composable
fun ParentGateScreen(onBack: () -> Unit) {
    var unlocked by remember { mutableStateOf(false) }
    if (!unlocked) ParentCheck(onPass = { unlocked = true }, onCancel = onBack)
    else ParentDashboard(onBack)
}

@Composable
private fun ParentDashboard(onBack: () -> Unit) {
    val accent = Color(0xFF90CAF9)
    var tab by remember { mutableStateOf(0) }
    ScreenScaffold("Parent Section 👨‍👩‍👧", accent, onBack) {
        TabsBar(listOf("Progress", "Settings"), tab, accent) { tab = it }
        Spacer(Modifier.height(10.dp))
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            if (tab == 0) ProgressTab() else SettingsTab()
        }
    }
}

@Composable
private fun StatLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, fontSize = 17.sp)
        Text(value, fontSize = 17.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun ProgressTab() {
    val ctx = LocalContext.current
    val stars = remember { Rewards.stars(ctx) }
    val mins = remember { ParentStore.usedSec(ctx) / 60 }
    val used = remember {
        LearningModule.entries.map { it to ParentStore.opens(ctx, it) }.filter { it.second > 0 }.sortedByDescending { it.second }
    }
    Text("${ParentStore.avatars[ParentStore.profileId(ctx)]} ${ParentStore.profileLabel(ctx, ParentStore.profileId(ctx))}",
        fontSize = 20.sp, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(6.dp))
    StatLine("⭐ Stars earned", "$stars")
    StatLine("🏷️ Stickers unlocked", "${stars / Rewards.STARS_PER_STICKER}")
    StatLine("⏱️ Play time today", "$mins min")
    Spacer(Modifier.height(10.dp))
    Text("Quiz accuracy (first try)", fontSize = 18.sp, fontWeight = FontWeight.Bold)
    val acc = remember { ParentStore.accuracy(ctx).sortedBy { it.second.toFloat() / it.third } }
    if (acc.isEmpty()) Text("No quiz answers yet.", color = Color.Gray)
    acc.forEach { (area, ok, total) ->
        val pct = ok * 100 / total
        StatLine((if (total >= 5 && pct < 60) "⚠️ " else "✅ ") + area, "$ok/$total  ($pct%)")
    }
    if (acc.any { it.third >= 5 && it.second * 100 / it.third < 60 }) {
        Text("⚠️ = needs practice (below 60%).", fontSize = 13.sp, color = Color.Gray)
    }
    Spacer(Modifier.height(10.dp))
    Text("Favourite activities", fontSize = 18.sp, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(4.dp))
    if (used.isEmpty()) Text("Nothing played yet.", color = Color.Gray)
    used.take(8).forEach { (m, n) -> StatLine("${m.emoji} ${m.title}", "$n×") }
}

@Composable
private fun VoiceChoice(title: String, lang: String, sample: String, locale: java.util.Locale) {
    val ctx = LocalContext.current
    val speaker = com.littlelearners.app.rememberSpeaker()
    var mode by remember { mutableStateOf(ParentStore.voiceMode(ctx, lang)) }
    Text(title, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        listOf("Auto", "Offline", "Online").forEachIndexed { m, label ->
            val pad = androidx.compose.foundation.layout.PaddingValues(0.dp)
            if (mode == m) Button(onClick = {}, modifier = Modifier.weight(1f), contentPadding = pad) { Text(label) }
            else OutlinedButton(
                onClick = { mode = m; ParentStore.setVoiceMode(ctx, lang, m) },
                modifier = Modifier.weight(1f), contentPadding = pad
            ) { Text(label) }
        }
    }
    TextButton(onClick = { speaker.say(sample, locale) }) { Text("🔊 Test voice") }
}

@Composable
private fun VoiceSettings() {
    val ctx = LocalContext.current
    Text("Voice", fontSize = 18.sp, fontWeight = FontWeight.Bold)
    Text(
        "Auto = phone default. Offline = only voices stored on the phone. Online = better-sounding network voices " +
            "(the phone's speech engine needs internet; this app itself never connects).",
        fontSize = 13.sp, color = Color.Gray
    )
    Spacer(Modifier.height(6.dp))
    VoiceChoice("English voice", "en", "Hello! This is the English voice.", java.util.Locale.US)
    VoiceChoice("Urdu voice (اردو)", "ur", "آپ کا خوش آمدید", com.littlelearners.app.UrduLocale)
    OutlinedButton(
        onClick = {
            try {
                ctx.startActivity(
                    android.content.Intent("com.android.settings.TTS_SETTINGS").addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (_: Exception) {
                try {
                    ctx.startActivity(
                        android.content.Intent(android.provider.Settings.ACTION_SETTINGS).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                } catch (_: Exception) {
                }
            }
        },
        modifier = Modifier.fillMaxWidth()
    ) { Text("Open phone voice settings (download voices)") }
}

@Composable
private fun ChildrenSettings() {
    val ctx = LocalContext.current
    var count by remember { mutableStateOf(ParentStore.profileCount(ctx)) }
    var active by remember { mutableStateOf(ParentStore.profileId(ctx)) }
    var names by remember { mutableStateOf(List(3) { ParentStore.profileNames(ctx).getOrNull(it).orEmpty() }) }
    Text("Children", fontSize = 18.sp, fontWeight = FontWeight.Bold)
    Text("Each child has their own stars, stickers and streak. The active child is the one playing now.", fontSize = 13.sp, color = Color.Gray)
    for (i in 0 until count) {
        Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(ParentStore.avatars[i], fontSize = 26.sp)
            Spacer(Modifier.width(6.dp))
            OutlinedTextField(
                value = names[i],
                onValueChange = { v ->
                    val clean = v.replace("|", "").take(12)
                    names = names.toMutableList().also { it[i] = clean }
                    ParentStore.renameProfile(ctx, i, clean)
                },
                placeholder = { Text("Player ${i + 1}") },
                singleLine = true,
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.width(6.dp))
            if (active == i) Button(onClick = {}) { Text("Active") }
            else OutlinedButton(onClick = { active = i; ParentStore.setProfile(ctx, i) }) { Text("Use") }
        }
    }
    if (count < 3) {
        OutlinedButton(onClick = { if (ParentStore.addProfile(ctx)) count = ParentStore.profileCount(ctx) }) { Text("➕ Add child") }
    }
}

@Composable
private fun BackupSettings() {
    val ctx = LocalContext.current
    var text by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    Text("Backup & restore", fontSize = 18.sp, fontWeight = FontWeight.Bold)
    Text("Share a backup code (WhatsApp, notes, email) and paste it on a new phone. It holds stars, stickers and settings but not the PIN.",
        fontSize = 13.sp, color = Color.Gray)
    OutlinedButton(
        onClick = {
            val send = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(android.content.Intent.EXTRA_TEXT, ParentStore.exportBackup(ctx))
            }
            try {
                ctx.startActivity(android.content.Intent.createChooser(send, "Backup").addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (_: Exception) { note = "Could not open share" }
        },
        modifier = Modifier.fillMaxWidth()
    ) { Text("📤 Share backup code") }
    OutlinedTextField(
        value = text, onValueChange = { text = it; note = "" },
        label = { Text("Paste backup code here") },
        modifier = Modifier.fillMaxWidth()
    )
    Button(onClick = {
        note = if (ParentStore.importBackup(ctx, text)) "Restored ✅ Please close and reopen the app." else "That code did not work"
    }, enabled = text.isNotBlank()) { Text("📥 Restore") }
    if (note.isNotEmpty()) Text(note, fontSize = 14.sp)
}

@Composable
private fun SettingsTab() {
    val ctx = LocalContext.current
    var limit by remember { mutableStateOf(ParentStore.limitMin(ctx)) }
    var hasPin by remember { mutableStateOf(ParentStore.pin(ctx) != null) }
    var newPin by remember { mutableStateOf("") }
    var confirmReset by remember { mutableStateOf(false) }
    var note by remember { mutableStateOf("") }

    var bedtime by remember { mutableStateOf(ParentStore.bedtime(ctx)) }
    Text("Bedtime mode 🌙", fontSize = 18.sp, fontWeight = FontWeight.Bold)
    Text("Home shows only Stories, Music and Rhymes & Lullabies. Turn off to see everything again.", fontSize = 13.sp, color = Color.Gray)
    if (bedtime) Button(onClick = { bedtime = false; ParentStore.setBedtime(ctx, false) }) { Text("🌙 ON – tap to turn off") }
    else OutlinedButton(onClick = { bedtime = true; ParentStore.setBedtime(ctx, true) }) { Text("Turn on bedtime mode") }
    Spacer(Modifier.height(20.dp))
    ChildrenSettings()
    Spacer(Modifier.height(20.dp))
    Text("Daily play-time limit", fontSize = 18.sp, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(6.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        listOf(0, 15, 30, 45, 60).forEach { m ->
            val on = limit == m
            val label = if (m == 0) "Off" else "$m"
            if (on) Button(onClick = {}, modifier = Modifier.weight(1f), contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)) { Text(label) }
            else OutlinedButton(
                onClick = { limit = m; ParentStore.setLimitMin(ctx, m) },
                modifier = Modifier.weight(1f),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
            ) { Text(label) }
        }
    }
    Text("minutes per day. When time is up, the app locks until a parent enters the PIN.", fontSize = 13.sp, color = Color.Gray)

    Spacer(Modifier.height(20.dp))
    VoiceSettings()

    Spacer(Modifier.height(20.dp))
    Text("Parent PIN", fontSize = 18.sp, fontWeight = FontWeight.Bold)
    Text(if (hasPin) "A PIN is set." else "No PIN yet (a simple sum is used).", fontSize = 13.sp, color = Color.Gray)
    OutlinedTextField(
        value = newPin,
        onValueChange = { newPin = it.filter(Char::isDigit).take(4); note = "" },
        label = { Text("New 4-digit PIN") },
        singleLine = true,
        visualTransformation = PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = Modifier.fillMaxWidth()
    )
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = {
            if (newPin.length == 4) { ParentStore.setPin(ctx, newPin); hasPin = true; newPin = ""; note = "PIN saved ✅" }
            else note = "PIN must be 4 digits"
        }) { Text("Save PIN") }
        if (hasPin) OutlinedButton(onClick = { ParentStore.setPin(ctx, null); hasPin = false; note = "PIN removed" }) { Text("Remove") }
    }
    if (note.isNotEmpty()) Text(note, fontSize = 14.sp)

    Spacer(Modifier.height(20.dp))
    BackupSettings()

    Spacer(Modifier.height(20.dp))
    OutlinedButton(onClick = { confirmReset = true }, modifier = Modifier.fillMaxWidth()) { Text("Reset stars & progress (active child)") }
    Spacer(Modifier.height(20.dp))

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("Reset progress?") },
            text = { Text("Stars, stickers and activity history will be erased.") },
            confirmButton = { TextButton(onClick = { ParentStore.resetProgress(ctx); confirmReset = false; note = "Progress reset" }) { Text("Reset") } },
            dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("Cancel") } }
        )
    }
}

/** Shown when the daily limit is reached. A parent can unlock 15 more minutes. */
@Composable
fun TimeUpScreen(onExtend: () -> Unit) {
    var asking by remember { mutableStateOf(false) }
    if (asking) {
        ParentCheck(onPass = onExtend, onCancel = { asking = false })
    } else {
        Column(
            Modifier.fillMaxSize().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("😴", fontSize = 90.sp)
            Text("Time is up for today!", style = MaterialTheme.typography.headlineLarge, textAlign = TextAlign.Center)
            Spacer(Modifier.height(8.dp))
            Text("See you tomorrow! 👋", fontSize = 20.sp)
            Spacer(Modifier.height(28.dp))
            OutlinedButton(onClick = { asking = true }) { Text("Parents: add 15 minutes") }
        }
    }
}
