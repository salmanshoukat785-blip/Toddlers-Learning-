@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.littlelearners.app.ui

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.littlelearners.app.rememberSpeaker
import com.littlelearners.app.urduAlphabet

private val paintColors = listOf(
    Color(0xFFE53935), Color(0xFFFB8C00), Color(0xFFFDD835), Color(0xFF43A047),
    Color(0xFF1E88E5), Color(0xFF8E24AA), Color(0xFFF48FB1), Color(0xFF795548),
    Color(0xFF212121)
)

@Composable
private fun ColorRow(selected: Color, colors: List<Color> = paintColors, onPick: (Color) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        colors.forEach { c ->
            Box(
                Modifier
                    .weight(1f)
                    .aspectRatio(1f)
                    .clip(CircleShape)
                    .background(c)
                    .border(if (c == selected) 4.dp else 1.dp, if (c == selected) Color(0xFF7B3FA0) else Color.LightGray, CircleShape)
                    .pointerInput(c) { detectTapGestures { onPick(c) } }
            )
        }
    }
}

@Composable
private fun ActionButton(label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Button(onClick = onClick, modifier = modifier.height(50.dp)) { Text(label, fontSize = 16.sp) }
}

// ======================= TRACING CENTER =======================

@Composable
fun TracingScreen(onBack: () -> Unit) {
    val accent = Color(0xFFB39DDB)
    val speaker = rememberSpeaker()
    val board = remember {
        StrokeBoard().apply { color = Color(0xFF7B3FA0); width = 34f }
    }
    var set by remember { mutableStateOf(0) }
    var selected by remember { mutableStateOf(0) }
    var message by remember { mutableStateOf("Trace with your finger 👆") }

    val sets: List<List<String>> = listOf(
        (1..10).map { "$it" },
        ('A'..'Z').map { "$it" },
        urduAlphabet.map { it.letter }
    )
    val items = sets[set]
    val glyph = items[selected.coerceIn(items.indices)]

    ScreenScaffold("Tracing Center", accent, onBack) {
        TabsBar(listOf("123", "ABC", "اردو"), set, accent) {
            set = it
            selected = 0
            board.clear()
            message = "Trace with your finger 👆"
        }
        Spacer(Modifier.height(8.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            itemsIndexed(items) { i, g ->
                Card(
                    onClick = { selected = i; board.clear(); message = "Trace with your finger 👆" },
                    colors = CardDefaults.cardColors(containerColor = if (i == selected) accent else Color.White),
                    border = BorderStroke(2.dp, accent),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.size(52.dp)
                ) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(g, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .clip(RoundedCornerShape(28.dp))
                .background(Color.White)
                .border(3.dp, accent, RoundedCornerShape(28.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text(glyph, fontSize = 260.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFFE6E0F0))
            DrawingCanvas(board, Modifier.fillMaxSize())
        }
        Spacer(Modifier.height(6.dp))
        Text(message, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.CenterHorizontally))
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ActionButton("🗑 Clear", Modifier.weight(1f)) { board.clear(); message = "Trace with your finger 👆" }
            ActionButton("✓ Done", Modifier.weight(1f)) {
                if (board.strokes.isEmpty()) {
                    message = "Try tracing first 🙂"
                } else {
                    message = "🌟 Great job!"
                    speaker.say("Great job!")
                }
            }
            ActionButton("Next ▶", Modifier.weight(1f)) {
                selected = (selected + 1) % items.size
                board.clear()
                message = "Trace with your finger 👆"
            }
        }
    }
}

// ======================= DRAWING STUDIO =======================

@Composable
fun DrawingScreen(onBack: () -> Unit) {
    val accent = Color(0xFFF48FB1)
    val context = LocalContext.current
    val board = remember { StrokeBoard() }
    // eraser == paper color
    val paper = Color.White

    ScreenScaffold("Drawing Studio", accent, onBack) {
        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(paper)
                .border(3.dp, accent, RoundedCornerShape(24.dp))
        ) {
            DrawingCanvas(board, Modifier.fillMaxSize())
        }
        Spacer(Modifier.height(8.dp))
        ColorRow(board.color) { board.color = it }
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            ActionButton("•", Modifier.weight(1f)) { board.width = 10f }
            ActionButton("●", Modifier.weight(1f)) { board.width = 24f }
            ActionButton("⬤", Modifier.weight(1f)) { board.width = 48f }
            ActionButton("🧽", Modifier.weight(1f)) { board.color = paper }
        }
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            ActionButton("↩ Undo", Modifier.weight(1f)) { board.undo() }
            ActionButton("🗑 Clear", Modifier.weight(1f)) { board.clear() }
            ActionButton("💾 Save", Modifier.weight(1f)) {
                val size = board.size
                if (size.width > 0 && size.height > 0 && board.strokes.isNotEmpty()) {
                    val bmp = renderToBitmap(size.width, size.height, paper) { drawStrokes(board.strokes) }
                    val ok = saveArt(context, bmp, "drawing")
                    Toast.makeText(context, if (ok) "Saved to Pictures ✓" else "Could not save", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(context, "Draw something first 🙂", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}

// ======================= COLORING BOOK =======================

@Composable
fun ColoringScreen(onBack: () -> Unit) {
    val accent = Color(0xFFAED581)
    val context = LocalContext.current
    val speaker = rememberSpeaker()
    var pictureIndex by remember { mutableStateOf(0) }
    var current by remember { mutableStateOf(paintColors[0]) }
    var canvasSize by remember { mutableStateOf(IntSize.Zero) }
    val fillsByPicture = remember { pictures.map { mutableStateMapOf<Int, Color>() } }
    val picture = pictures[pictureIndex]
    val fills = fillsByPicture[pictureIndex]

    ScreenScaffold("Coloring Book", accent, onBack) {
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            itemsIndexed(pictures) { i, p ->
                Card(
                    onClick = { pictureIndex = i },
                    colors = CardDefaults.cardColors(containerColor = if (i == pictureIndex) accent else Color.White),
                    border = BorderStroke(2.dp, accent),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.size(64.dp)
                ) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(p.emoji, fontSize = 30.sp)
                    }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .clip(RoundedCornerShape(24.dp))
                .background(Color.White)
                .border(3.dp, accent, RoundedCornerShape(24.dp))
        ) {
            Canvas(
                Modifier
                    .fillMaxSize()
                    .onSizeChanged { canvasSize = it }
                    .pointerInput(pictureIndex) {
                        detectTapGestures { tap ->
                            val x = tap.x / size.width
                            val y = tap.y / size.height
                            val hit = picture.hit(x, y)
                            if (hit >= 0) {
                                fills[hit] = current
                            }
                        }
                    }
            ) {
                drawPicture(picture, fills)
            }
        }
        Spacer(Modifier.height(10.dp))
        Text("Pick a color, then tap a part", fontSize = 15.sp, color = Color.Gray)
        Spacer(Modifier.height(6.dp))
        ColorRow(current) { current = it }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ActionButton("↺ Reset", Modifier.weight(1f)) { fills.clear() }
            ActionButton("💾 Save", Modifier.weight(1f)) {
                if (canvasSize.width > 0) {
                    val bmp = renderToBitmap(canvasSize.width, canvasSize.height, Color.White) {
                        drawPicture(picture, fills)
                    }
                    val ok = saveArt(context, bmp, "coloring_${picture.name.lowercase()}")
                    Toast.makeText(context, if (ok) "Saved to Pictures ✓" else "Could not save", Toast.LENGTH_SHORT).show()
                    if (ok) speaker.say("Beautiful!")
                }
            }
        }
    }
}
