package com.littlelearners.app.ui

import androidx.compose.material3.LocalTextStyle
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.TextUnit
import com.littlelearners.app.R

/** Jameel Noori Nastaleeq (free Urdu font) — used automatically for any text containing Urdu/Arabic letters. */
val NastaliqFont = FontFamily(Font(R.font.jameel_noori))

/** Arabic with harakat (duas, Quran) stays on the system Naskh font; only plain Urdu gets Nastaliq. */
private fun isArabicWithHarakat(s: String): Boolean = s.any { it.code in 0x064B..0x065F || it.code == 0x0670 }

private fun hasUrdu(s: String): Boolean =
    s.any { it.code in 0x0600..0x06FF || it.code in 0xFB50..0xFEFF } && !isArabicWithHarakat(s)

/**
 * Drop-in replacement for material3 Text (same package, so every screen picks it up).
 * Text with Urdu letters gets the Nastaliq font and extra line height; everything else is unchanged.
 */
@Composable
fun Text(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = Color.Unspecified,
    fontSize: TextUnit = TextUnit.Unspecified,
    fontStyle: FontStyle? = null,
    fontWeight: FontWeight? = null,
    fontFamily: FontFamily? = null,
    letterSpacing: TextUnit = TextUnit.Unspecified,
    textDecoration: TextDecoration? = null,
    textAlign: TextAlign? = null,
    lineHeight: TextUnit = TextUnit.Unspecified,
    overflow: TextOverflow = TextOverflow.Clip,
    softWrap: Boolean = true,
    maxLines: Int = Int.MAX_VALUE,
    minLines: Int = 1,
    onTextLayout: ((TextLayoutResult) -> Unit)? = null,
    style: TextStyle = LocalTextStyle.current
) {
    val urdu = fontFamily == null && hasUrdu(text)
    androidx.compose.material3.Text(
        text = text,
        modifier = modifier,
        color = color,
        fontSize = fontSize,
        fontStyle = fontStyle,
        fontWeight = if (urdu) null else fontWeight,
        fontFamily = if (urdu) NastaliqFont else fontFamily,
        letterSpacing = letterSpacing,
        textDecoration = textDecoration,
        textAlign = textAlign,
        lineHeight = lineHeight,
        overflow = overflow,
        softWrap = softWrap,
        maxLines = maxLines,
        minLines = minLines,
        onTextLayout = onTextLayout,
        style = style
    )
}
