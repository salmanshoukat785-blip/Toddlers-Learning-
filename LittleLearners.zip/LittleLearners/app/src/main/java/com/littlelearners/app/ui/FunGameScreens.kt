@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.littlelearners.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.withFrameNanos
import com.littlelearners.app.Category
import com.littlelearners.app.ParentStore
import com.littlelearners.app.Rewards
import com.littlelearners.app.rememberSpeaker
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/** Fun Games: Shape Sorter, Find it (hidden object), Bubble Pop and Dots Join. All give stars. */
@Composable
fun FunGamesScreen(category: Category, onBack: () -> Unit) {
    val accent = Color(0xFFFFAB91)
    var tab by remember { mutableStateOf(0) }
    val own = remember(category) { gameItems(category) }
    val animals = remember { gameItems(Category.ANIMALS) }
    val pool = if (own.size >= 8) own else animals

    ScreenScaffold("Fun Games 🎈", accent, onBack) {
        TabsBar(listOf("Shapes", "Find it", "Pop", "Dots"), tab, accent) { tab = it }
        Spacer(Modifier.height(8.dp))
        when (tab) {
            0 -> ShapeSorter(accent)
            1 -> FindIt(pool, accent)
            2 -> BubblePop(accent)
            else -> DotsJoin(accent)
        }
    }
}

// ---------------------------------------------------------------- Shape sorter

private val shapeNames = listOf("Circle", "Square", "Triangle", "Star", "Diamond")
private val shapeColors = listOf(Color(0xFFEF5350), Color(0xFF42A5F5), Color(0xFF66BB6A), Color(0xFFFFCA28), Color(0xFFAB47BC))

private fun DrawScope.drawShape(kind: Int, color: Color, filled: Boolean) {
    val s = minOf(size.width, size.height)
    val style = if (filled) Fill else Stroke(width = 8f)
    val c = Offset(size.width / 2, size.height / 2)
    when (kind) {
        0 -> drawCircle(color, radius = s * 0.42f, center = c, style = style)
        1 -> drawRect(color, topLeft = Offset(c.x - s * 0.38f, c.y - s * 0.38f), size = Size(s * 0.76f, s * 0.76f), style = style)
        2 -> drawPath(Path().apply {
            moveTo(c.x, c.y - s * 0.42f); lineTo(c.x + s * 0.42f, c.y + s * 0.36f); lineTo(c.x - s * 0.42f, c.y + s * 0.36f); close()
        }, color, style = style)
        3 -> drawPath(Path().apply {
            for (i in 0 until 10) {
                val r = if (i % 2 == 0) s * 0.45f else s * 0.2f
                val a = -PI / 2 + i * PI / 5
                val x = c.x + (r * cos(a)).toFloat(); val y = c.y + (r * sin(a)).toFloat()
                if (i == 0) moveTo(x, y) else lineTo(x, y)
            }
            close()
        }, color, style = style)
        else -> drawPath(Path().apply {
            moveTo(c.x, c.y - s * 0.45f); lineTo(c.x + s * 0.32f, c.y); lineTo(c.x, c.y + s * 0.45f); lineTo(c.x - s * 0.32f, c.y); close()
        }, color, style = style)
    }
}

@Composable
private fun ShapeSorter(accent: Color) {
    val ctx = LocalContext.current
    val speaker = rememberSpeaker()
    var round by remember { mutableStateOf(0) }
    val kinds = remember(round) { (0..4).shuffled().take(4) }
    val holes = remember(round) { kinds.shuffled() }
    val pieces = remember(round) { kinds.shuffled() }
    var placed by remember(round) { mutableStateOf(setOf<Int>()) }
    var selected by remember(round) { mutableStateOf(-1) }
    var msg by remember(round) { mutableStateOf("Tap a shape, then tap its hole") }
    val won = placed.size == kinds.size
    LaunchedEffect(won, round) { if (won) Rewards.add(ctx, 2) }

    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(if (won) "🎉 Great job! +2 ⭐" else msg, fontSize = 20.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            holes.forEach { k ->
                Canvas(
                    Modifier.size(76.dp).clip(CircleShape).background(Color(0xFFF5F5F5))
                        .clickable {
                            if (selected < 0) { msg = "Pick a shape first 👇" }
                            else if (selected == k) { placed = placed + k; selected = -1; msg = "Yes! ${shapeNames[k]}"; speaker.say(shapeNames[k]) }
                            else msg = "Not here, try again"
                        }
                ) {
                    if (k in placed) drawShape(k, shapeColors[k], true) else drawShape(k, Color(0xFF9E9E9E), false)
                }
            }
        }
        Spacer(Modifier.height(36.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            pieces.forEach { k ->
                if (k !in placed) {
                    Canvas(
                        Modifier.size(76.dp).clip(CircleShape)
                            .background(if (selected == k) Color(0xFFFFF59D) else Color.Transparent)
                            .clickable { selected = k; msg = shapeNames[k]; speaker.say(shapeNames[k]) }
                    ) { drawShape(k, shapeColors[k], true) }
                } else Spacer(Modifier.size(76.dp))
            }
        }
        if (won) {
            Spacer(Modifier.height(20.dp))
            Button(onClick = { round++ }) { Text("Play again 🔁") }
        }
    }
}

// ---------------------------------------------------------------- Find it (hidden object)

@Composable
private fun FindIt(pool: List<GameItem>, accent: Color) {
    val ctx = LocalContext.current
    val speaker = rememberSpeaker()
    var round by remember { mutableStateOf(0) }
    var index by remember(round) { mutableStateOf(0) }
    var found by remember(round) { mutableStateOf(0) }
    var msg by remember(round, index) { mutableStateOf("") }
    val scenes = remember(round, pool) {
        List(5) {
            val items = pool.shuffled().take(if (ParentStore.easy(ctx)) 9 else 14)
            items to items.random()
        }
    }
    // jitter per cell, kept for the whole round
    val jit = remember(round) { List(5) { List(16) { Triple(Random.nextFloat(), Random.nextFloat(), Random.nextInt(-12, 13).toFloat()) } } }

    if (index >= 5) {
        LaunchedEffect(round) { Rewards.add(ctx, found) }
        Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text("🎉", fontSize = 70.sp)
            Text("You found $found / 5  ⭐ +$found", fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(16.dp))
            Button(onClick = { round++ }) { Text("Play again 🔁") }
        }
        return
    }
    Column(Modifier.fillMaxSize()) {
        val (items, target) = scenes[index]
        LaunchedEffect(index, round) { speaker.say("Find the ${target.en}") }
        Text("🔍 Find the ${target.en}", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold,
            textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        if (msg.isNotEmpty()) Text(msg, fontSize = 15.sp, color = Color.Gray, modifier = Modifier.align(Alignment.CenterHorizontally))
        BoxWithConstraints(Modifier.fillMaxSize().padding(top = 6.dp)) {
            val cw = maxWidth / 4
            val ch = maxHeight / 4
            val size = 64.dp
            items.forEachIndexed { i, g ->
                val (jx, jy, rot) = jit[index][i]
                Box(
                    Modifier
                        .offset(x = cw * (i % 4) + (cw - size) * jx, y = ch * (i / 4) + (ch - size) * jy)
                        .size(size)
                        .rotate(rot)
                        .clickable {
                            if (g.photo == target.photo) { found++; index++ }
                            else { msg = "That is a ${g.en}. Keep looking!"; speaker.say(g.en) }
                        },
                    contentAlignment = Alignment.Center
                ) { PhotoImage(g.photo, Modifier.fillMaxSize()) }
            }
        }
    }
}

// ---------------------------------------------------------------- Bubble pop

private data class Bubble(val id: Int, val label: String, val fx: Float, val p: Float, val speed: Float, val color: Color)

@Composable
private fun BubblePop(accent: Color) {
    val ctx = LocalContext.current
    val speaker = rememberSpeaker()
    var mode by remember { mutableStateOf(0) }
    var round by remember { mutableStateOf(0) }
    val easy = ParentStore.easy(ctx)
    val labels = remember(mode, easy) { if (mode == 0) (1..(if (easy) 5 else 9)).map { "$it" } else ('A'..(if (easy) 'E' else 'J')).map { "$it" } }
    var target by remember(mode, round) { mutableStateOf(labels.random()) }
    var popped by remember(mode, round) { mutableStateOf(0) }
    var bubbles by remember(mode, round) { mutableStateOf(listOf<Bubble>()) }
    var msg by remember(mode, round) { mutableStateOf("") }
    val won = popped >= 5
    LaunchedEffect(won, mode, round) { if (won) Rewards.add(ctx, 3) }
    LaunchedEffect(target, mode, round) { speaker.say("Pop $target") }
    val colors = remember { listOf(Color(0xFFEF5350), Color(0xFF42A5F5), Color(0xFF66BB6A), Color(0xFFFFCA28), Color(0xFFAB47BC), Color(0xFFFF7043)) }

    LaunchedEffect(won, mode, round) {
        if (won) return@LaunchedEffect
        var last = 0L
        var spawn = 0f
        var nextId = 0
        while (true) {
            withFrameNanos { now ->
                if (last == 0L) last = now
                val dt = (now - last) / 1_000_000_000f
                last = now
                spawn += dt
                var list = bubbles.map { it.copy(p = it.p + dt * it.speed) }.filter { it.p < 1.05f }
                if (spawn > 0.8f) {
                    spawn = 0f
                    val lab = if (Random.nextInt(3) == 0) target else labels.random()
                    list = list + Bubble(nextId++, lab, Random.nextFloat(), 0f, (if (easy) 0.11f else 0.18f) + Random.nextFloat() * 0.1f, colors.random())
                }
                bubbles = list
            }
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { mode = 0; round++ }, modifier = Modifier.weight(1f)) { Text("123") }
            Button(onClick = { mode = 1; round++ }, modifier = Modifier.weight(1f)) { Text("ABC") }
        }
        Text(if (won) "🎉 You popped them all! +3 ⭐" else "🎈 Pop  $target   ($popped / 5)",
            fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp))
        if (msg.isNotEmpty() && !won) Text(msg, fontSize = 14.sp, color = Color.Gray, modifier = Modifier.align(Alignment.CenterHorizontally))
        if (won) {
            Button(onClick = { round++ }, modifier = Modifier.align(Alignment.CenterHorizontally)) { Text("Play again 🔁") }
        } else BoxWithConstraints(Modifier.fillMaxSize()) {
            val d = 64.dp
            bubbles.forEach { b ->
                Box(
                    Modifier
                        .offset(x = (maxWidth - d) * b.fx, y = (maxHeight - d) * (1f - b.p))
                        .size(d)
                        .clip(CircleShape)
                        .background(b.color.copy(alpha = 0.85f))
                        .clickable {
                            if (b.label == target) {
                                popped++
                                bubbles = bubbles.filter { it.id != b.id }
                                speaker.say(b.label)
                                msg = ""
                                target = labels.random()
                            } else msg = "That is ${b.label}. Pop $target!"
                        },
                    contentAlignment = Alignment.Center
                ) { Text(b.label, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = Color.White) }
            }
        }
    }
}

// ---------------------------------------------------------------- Dots join

private class Figure(val name: String, val pts: List<Pair<Float, Float>>)

private val figures = listOf(
    Figure("House", listOf(0.2f to 0.9f, 0.2f to 0.5f, 0.5f to 0.15f, 0.8f to 0.5f, 0.8f to 0.9f)),
    Figure("Rocket", listOf(0.5f to 0.08f, 0.66f to 0.35f, 0.66f to 0.72f, 0.85f to 0.92f, 0.15f to 0.92f, 0.34f to 0.72f, 0.34f to 0.35f)),
    Figure("Star", (0 until 10).map { i ->
        val r = if (i % 2 == 0) 0.45f else 0.2f
        val a = -PI / 2 + i * PI / 5
        (0.5f + (r * cos(a)).toFloat()) to (0.52f + (r * sin(a)).toFloat())
    }),
    Figure("Boat", listOf(0.1f to 0.6f, 0.9f to 0.6f, 0.75f to 0.85f, 0.25f to 0.85f, 0.5f to 0.6f, 0.5f to 0.1f, 0.78f to 0.5f, 0.5f to 0.5f))
)

@Composable
private fun DotsJoin(accent: Color) {
    val ctx = LocalContext.current
    val speaker = rememberSpeaker()
    var fig by remember { mutableStateOf(0) }
    var next by remember(fig) { mutableStateOf(0) }
    var msg by remember(fig) { mutableStateOf("Tap the dots in order: 1, 2, 3 ...") }
    val f = figures[fig]
    val done = next >= f.pts.size
    LaunchedEffect(done, fig) { if (done) { Rewards.add(ctx, 2); speaker.say("Wow! A ${f.name}!") } }

    Column(Modifier.fillMaxSize()) {
        Text(if (done) "🎉 It is a ${f.name}! +2 ⭐" else msg, fontSize = 20.sp, fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        BoxWithConstraints(Modifier.weight(1f).fillMaxWidth().padding(16.dp)) {
            val w = maxWidth
            val h = maxHeight
            Canvas(Modifier.fillMaxSize()) {
                val pts = f.pts.map { Offset(it.first * size.width, it.second * size.height) }
                for (i in 1 until minOf(next, pts.size)) drawLine(Color(0xFF5C6BC0), pts[i - 1], pts[i], strokeWidth = 10f)
                if (done) drawLine(Color(0xFF5C6BC0), pts.last(), pts.first(), strokeWidth = 10f)
            }
            val d = 40.dp
            f.pts.forEachIndexed { i, p ->
                Box(
                    Modifier
                        .offset(x = w * p.first - d / 2, y = h * p.second - d / 2)
                        .size(d)
                        .clip(CircleShape)
                        .background(if (i < next) Color(0xFF66BB6A) else Color(0xFFFFB74D))
                        .clickable {
                            if (i == next) { next++; speaker.say("${i + 1}") }
                            else if (i > next) msg = "Find number ${next + 1} first"
                        },
                    contentAlignment = Alignment.Center
                ) { Text("${i + 1}", fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = Color.White) }
            }
        }
        if (done) {
            Button(onClick = { fig = (fig + 1) % figures.size }, modifier = Modifier.align(Alignment.CenterHorizontally)) { Text("Next picture ▶") }
        }
    }
}
