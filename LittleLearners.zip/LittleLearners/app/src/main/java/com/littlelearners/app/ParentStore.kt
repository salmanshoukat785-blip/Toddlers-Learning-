package com.littlelearners.app

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Parent settings and progress. Everything stays on the device (no network, no login). */
object ParentStore {
    private fun sp(ctx: Context) =
        ctx.applicationContext.getSharedPreferences("little_learners", Context.MODE_PRIVATE)

    private fun today(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    // ---- PIN ----
    fun pin(ctx: Context): String? = sp(ctx).getString("pin", null)?.takeIf { it.length == 4 }
    fun setPin(ctx: Context, pin: String?) {
        sp(ctx).edit().apply { if (pin == null) remove("pin") else putString("pin", pin) }.apply()
    }

    // ---- Daily time limit (0 = off) ----
    fun limitMin(ctx: Context): Int = sp(ctx).getInt("limit_min", 0)
    fun setLimitMin(ctx: Context, min: Int) = sp(ctx).edit().putInt("limit_min", min).apply()

    private fun rollDay(ctx: Context) {
        val s = sp(ctx)
        if (s.getString("usage_day", null) != today()) {
            s.edit().putString("usage_day", today()).putInt("usage_sec", 0).putInt("extra_min", 0).apply()
        }
    }

    fun usedSec(ctx: Context): Int { rollDay(ctx); return sp(ctx).getInt("usage_sec", 0) }
    fun addUsed(ctx: Context, sec: Int) {
        rollDay(ctx)
        sp(ctx).edit().putInt("usage_sec", usedSec(ctx) + sec).apply()
    }

    fun grantExtra(ctx: Context, min: Int) {
        rollDay(ctx)
        sp(ctx).edit().putInt("extra_min", sp(ctx).getInt("extra_min", 0) + min).apply()
    }

    fun timeUp(ctx: Context): Boolean {
        val limit = limitMin(ctx)
        if (limit <= 0) return false
        rollDay(ctx)
        return usedSec(ctx) >= (limit + sp(ctx).getInt("extra_min", 0)) * 60
    }

    // ---- Voice (per language: "en", "ur") ----
    const val VOICE_AUTO = 0
    const val VOICE_OFFLINE = 1
    const val VOICE_ONLINE = 2
    fun voiceMode(ctx: Context, lang: String): Int = sp(ctx).getInt("voice_$lang", VOICE_AUTO)
    fun setVoiceMode(ctx: Context, lang: String, mode: Int) = sp(ctx).edit().putInt("voice_$lang", mode).apply()

    // ---- Bedtime mode: home shows only calm activities ----
    fun bedtime(ctx: Context): Boolean = sp(ctx).getBoolean("bedtime", false)
    fun setBedtime(ctx: Context, on: Boolean) = sp(ctx).edit().putBoolean("bedtime", on).apply()
    val bedtimeModules = setOf(LearningModule.RHYMES, LearningModule.STORIES, LearningModule.MUSIC)

    // ---- Children (up to 3 profiles). Profile 0 keeps the old key names, so nothing is lost. ----
    val avatars = listOf("🐯", "🐼", "🦊")
    fun profileId(ctx: Context): Int = sp(ctx).getInt("profile_id", 0)
    fun setProfile(ctx: Context, id: Int) = sp(ctx).edit().putInt("profile_id", id).apply()
    fun profileNames(ctx: Context): List<String> = (sp(ctx).getString("profile_names", "") ?: "").split("|")
    private fun saveNames(ctx: Context, names: List<String>) =
        sp(ctx).edit().putString("profile_names", names.joinToString("|")).apply()
    fun profileLabel(ctx: Context, id: Int): String {
        val n = profileNames(ctx).getOrNull(id).orEmpty().trim()
        return if (n.isEmpty()) "Player ${id + 1}" else n
    }
    fun renameProfile(ctx: Context, id: Int, name: String) {
        val names = profileNames(ctx).toMutableList()
        while (names.size <= id) names.add("")
        names[id] = name.replace("|", "").take(12)
        saveNames(ctx, names)
    }
    fun profileCount(ctx: Context): Int = (sp(ctx).getInt("profile_count", 1)).coerceIn(1, 3)
    fun addProfile(ctx: Context): Boolean {
        val n = profileCount(ctx)
        if (n >= 3) return false
        sp(ctx).edit().putInt("profile_count", n + 1).apply()
        return true
    }

    /** Per-child storage key. */
    fun key(ctx: Context, base: String): String = profileId(ctx).let { if (it == 0) base else "p${it}_$base" }

    // ---- Daily reward & streak, first-run tutorial ----
    class Daily(val isNew: Boolean, val streak: Int, val stars: Int)

    fun tutorialDone(ctx: Context): Boolean = sp(ctx).getBoolean("tutorial_done", false)
    fun setTutorialDone(ctx: Context) = sp(ctx).edit().putBoolean("tutorial_done", true).apply()

    /** First open of the day: +1 star (+3 bonus every 5th day in a row). Same day again: nothing new. */
    fun claimDaily(ctx: Context): Daily {
        val s = sp(ctx)
        val now = today()
        val last = s.getString(key(ctx, "streak_last"), null)
        val count = s.getInt(key(ctx, "streak_count"), 0)
        if (last == now) return Daily(false, count, 0)
        val yesterday = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -1) }.time
        val y = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(yesterday)
        val newCount = if (last == y) count + 1 else 1
        val stars = 1 + if (newCount % 5 == 0) 3 else 0
        s.edit().putString(key(ctx, "streak_last"), now).putInt(key(ctx, "streak_count"), newCount).apply()
        Rewards.add(ctx, stars)
        return Daily(true, newCount, stars)
    }

    // ---- Quiz accuracy per area (for the parent report) ----
    val extraAreas = listOf("Math", "Islamic", "Sounds", "Worlds", "Vocabulary", "Calendar", "Clock", "Money")

    fun recordAnswer(ctx: Context, area: String, ok: Boolean) {
        val a = area.ifBlank { Category.fromName(sp(ctx).getString("last_category", null)).label }
        val k = key(ctx, (if (ok) "ok_" else "bad_") + a)
        sp(ctx).edit().putInt(k, sp(ctx).getInt(k, 0) + 1).apply()
    }

    /** area -> (correct first try, total answered), only areas with answers. */
    fun accuracy(ctx: Context): List<Triple<String, Int, Int>> =
        (Category.entries.map { it.label } + extraAreas).mapNotNull { a ->
            val ok = sp(ctx).getInt(key(ctx, "ok_$a"), 0)
            val bad = sp(ctx).getInt(key(ctx, "bad_$a"), 0)
            if (ok + bad == 0) null else Triple(a, ok, ok + bad)
        }

    // ---- Backup / restore (text code, no network). The PIN is not included. ----
    fun exportBackup(ctx: Context): String {
        val o = org.json.JSONObject()
        sp(ctx).all.forEach { (k, v) -> if (k != "pin" && v != null) o.put(k, v) }
        return "LL1:" + android.util.Base64.encodeToString(o.toString().toByteArray(Charsets.UTF_8), android.util.Base64.NO_WRAP)
    }

    fun importBackup(ctx: Context, text: String): Boolean {
        return try {
            val t = text.trim()
            if (!t.startsWith("LL1:")) return false
            val json = String(android.util.Base64.decode(t.removePrefix("LL1:"), android.util.Base64.NO_WRAP), Charsets.UTF_8)
            val o = org.json.JSONObject(json)
            val e = sp(ctx).edit()
            o.keys().forEach { k ->
                when (val v = o.get(k)) {
                    is Boolean -> e.putBoolean(k, v)
                    is Int -> e.putInt(k, v)
                    is String -> e.putString(k, v)
                }
            }
            e.apply()
            true
        } catch (_: Exception) {
            false
        }
    }

    // ---- Progress ----
    fun openModule(ctx: Context, m: LearningModule) {
        sp(ctx).edit().putInt(key(ctx, "open_${m.name}"), opens(ctx, m) + 1).apply()
    }
    fun opens(ctx: Context, m: LearningModule): Int = sp(ctx).getInt(key(ctx, "open_${m.name}"), 0)

    fun resetProgress(ctx: Context) {
        val e = sp(ctx).edit()
        e.remove(key(ctx, "stars")).remove(key(ctx, "streak_last")).remove(key(ctx, "streak_count"))
        LearningModule.entries.forEach { e.remove(key(ctx, "open_${it.name}")) }
        (Category.entries.map { it.label } + extraAreas).forEach { e.remove(key(ctx, "ok_$it")).remove(key(ctx, "bad_$it")) }
        e.apply()
    }
}
