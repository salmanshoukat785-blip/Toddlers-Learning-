@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.littlelearners.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.littlelearners.app.ParentStore
import com.littlelearners.app.Rewards
import com.littlelearners.app.rememberSpeaker

/** A perfect maze on an n x n grid. right[r][c] / down[r][c] = the wall is open (you can walk through). */
private class Maze(val n: Int, val right: Array<BooleanArray>, val down: Array<BooleanArray>) {
    fun open(a: Int, b: Int): Boolean {
        val ar = a / n; val ac = a % n
        return when (b) {
            a + 1 -> ac < n - 1 && right[ar][ac]
            a - 1 -> ac > 0 && right[ar][ac - 1]
            a + n -> ar < n - 1 && down[ar][ac]
            a - n -> ar > 0 && down[ar - 1][ac]
            else -> false
        }
    }
}

private fun makeMaze(n: Int): Maze {
    val right = Array(n) { BooleanArray(n) }
    val down = Array(n) { BooleanArray(n) }
    val seen = BooleanArray(n * n)
    val stack = ArrayDeque<Int>()
    seen[0] = true
    stack.addLast(0)
    while (stack.isNotEmpty()) {
        val cur = stack.last()
        val r = cur / n; val c = cur % n
        val next = buildList {
            if (c < n - 1 && !seen[cur + 1]) add(cur + 1)
            if (c > 0 && !seen[cur - 1]) add(cur - 1)
            if (r < n - 1 && !seen[cur + n]) add(cur + n)
            if (r > 0 && !seen[cur - n]) add(cur - n)
        }
        if (next.isEmpty()) { stack.removeLast(); continue }
        val nx = next.random()
        when (nx) {
            cur + 1 -> right[r][c] = true
            cur - 1 -> right[r][c - 1] = true
            cur + n -> down[r][c] = true
            else -> down[r - 1][c] = true
        }
        seen[nx] = true
        stack.addLast(nx)
    }
    return Maze(n, right, down)
}

private val mazeHeroes = listOf("🐰" to "🥕", "🐭" to "🧀", "🐻" to "🍯", "🐒" to "🍌", "🐶" to "🦴", "🐝" to "🌸")

/** Maze: drag a finger from the animal to its food. */
@Composable
fun MazeScreen(onBack: () -> Unit) {
    val accent = Color(0xFF9FA8DA)
    val ctx = LocalContext.current
    val speaker = rememberSpeaker()
    val n = if (ParentStore.easy(ctx)) 4 else 6
    var round by remember { mutableStateOf(0) }
    val maze = remember(round, n) { makeMaze(n) }
    val hero = remember(round) { mazeHeroes.random() }
    var path by remember(round, n) { mutableStateOf(listOf(0)) }
    val goal = n * n - 1
    val won = path.last() == goal
    LaunchedEffect(won, round) { if (won) { Rewards.add(ctx, 2); speaker.say("You found the way!") } }

    ScreenScaffold("Maze 🌀", accent, onBack) {
        Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(if (won) "🎉 You found the way! +2 ⭐" else "Drag your finger from ${hero.first} to ${hero.second}",
                fontSize = 18.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            BoxWithConstraints(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                val side = if (maxWidth < maxHeight) maxWidth else maxHeight
                val cell = side / n
                Box(Modifier.size(side).background(Color.White)) {
                    Canvas(
                        Modifier.fillMaxSize().pointerInput(round, n) {
                            detectDragGestures { change, _ ->
                                if (path.last() != goal) {
                                    val cs = size.width / n.toFloat()
                                    val cx = (change.position.x / cs).toInt().coerceIn(0, n - 1)
                                    val cy = (change.position.y / cs).toInt().coerceIn(0, n - 1)
                                    val target = cy * n + cx
                                    val cur = path.last()
                                    if (target != cur && maze.open(cur, target)) {
                                        path = if (path.size >= 2 && path[path.size - 2] == target) path.dropLast(1)
                                        else if (target !in path) path + target else path
                                    }
                                }
                            }
                        }
                    ) {
                        val cs = size.width / n
                        val wall = Color(0xFF455A64)
                        val sw = 8f
                        // outer border
                        drawLine(wall, Offset(0f, 0f), Offset(size.width, 0f), sw)
                        drawLine(wall, Offset(0f, 0f), Offset(0f, size.height), sw)
                        drawLine(wall, Offset(size.width, 0f), Offset(size.width, size.height), sw)
                        drawLine(wall, Offset(0f, size.height), Offset(size.width, size.height), sw)
                        for (r in 0 until n) for (c in 0 until n) {
                            if (c < n - 1 && !maze.right[r][c]) drawLine(wall, Offset((c + 1) * cs, r * cs), Offset((c + 1) * cs, (r + 1) * cs), sw)
                            if (r < n - 1 && !maze.down[r][c]) drawLine(wall, Offset(c * cs, (r + 1) * cs), Offset((c + 1) * cs, (r + 1) * cs), sw)
                        }
                        for (i in 1 until path.size) {
                            val a = path[i - 1]; val b = path[i]
                            drawLine(
                                Color(0xFFFF7043),
                                Offset((a % n + 0.5f) * cs, (a / n + 0.5f) * cs),
                                Offset((b % n + 0.5f) * cs, (b / n + 0.5f) * cs),
                                strokeWidth = cs * 0.3f, cap = StrokeCap.Round
                            )
                        }
                    }
                    Text(hero.first, fontSize = (cell.value * 0.6f).sp, modifier = Modifier.offset(
                        x = cell * (path.last() % n) + cell * 0.1f, y = cell * (path.last() / n) + cell * 0.05f))
                    Text(hero.second, fontSize = (cell.value * 0.6f).sp, modifier = Modifier.offset(
                        x = cell * (goal % n) + cell * 0.1f, y = cell * (goal / n) + cell * 0.05f))
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedButton(onClick = { path = listOf(0) }) { Text("↩ Restart") }
                if (won) Button(onClick = { round++ }) { Text("Next maze ▶") }
                else OutlinedButton(onClick = { round++ }) { Text("🔁 New maze") }
            }
        }
    }
}
