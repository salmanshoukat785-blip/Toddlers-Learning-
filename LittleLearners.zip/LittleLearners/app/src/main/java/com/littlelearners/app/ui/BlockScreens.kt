@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.littlelearners.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.littlelearners.app.Rewards
import com.littlelearners.app.rememberSpeaker

private val blockColors = listOf(
    Color(0xFFEF5350), Color(0xFF42A5F5), Color(0xFF66BB6A), Color(0xFFFFCA28), Color(0xFFAB47BC), Color(0xFFFF7043)
)
private val colorNames = listOf("Red", "Blue", "Green", "Yellow", "Purple", "Orange")

/** Build Blocks: pick a colour, tap a column and a block drops on top of the tower. */
@Composable
fun BlocksScreen(onBack: () -> Unit) {
    val accent = Color(0xFFFFAB91)
    val ctx = LocalContext.current
    val speaker = rememberSpeaker()
    val cols = 6
    val maxRows = 9
    var picked by remember { mutableStateOf(0) }
    var grid by remember { mutableStateOf(List(cols) { listOf<Int>() }) }
    var history by remember { mutableStateOf(listOf<Int>()) }
    var rewarded by remember { mutableStateOf(false) }
    val total = grid.sumOf { it.size }
    val tallest = grid.maxOf { it.size }
    LaunchedEffect(total) {
        if (total >= 10 && !rewarded) { rewarded = true; Rewards.add(ctx, 2); speaker.say("Wow! Ten blocks! You get two stars") }
        else if (total == 5) speaker.say("Five blocks!")
    }

    ScreenScaffold("Build Blocks 🧱", accent, onBack) {
        Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Blocks: $total    Tallest tower: $tallest", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text(if (rewarded) "⭐ +2 for 10 blocks!" else "Build 10 blocks to win a star", fontSize = 14.sp, color = Color.Gray)
            Spacer(Modifier.height(6.dp))
            Row(
                Modifier.fillMaxWidth().weight(1f).background(Color(0xFFE3F2FD), RoundedCornerShape(16.dp)).padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                for (c in 0 until cols) {
                    Column(
                        Modifier.weight(1f).fillMaxHeight()
                            .clickable {
                                if (grid[c].size < maxRows) {
                                    grid = grid.toMutableList().also { it[c] = it[c] + picked }
                                    history = history + c
                                    speaker.say(colorNames[picked])
                                }
                            },
                        verticalArrangement = Arrangement.Bottom
                    ) {
                        grid[c].asReversed().forEach { colorIdx ->
                            Box(
                                Modifier.fillMaxWidth().height(34.dp).padding(1.dp)
                                    .background(blockColors[colorIdx], RoundedCornerShape(6.dp))
                                    .border(1.dp, Color(0x55000000), RoundedCornerShape(6.dp))
                            )
                        }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                blockColors.forEachIndexed { i, col ->
                    Box(
                        Modifier.size(if (i == picked) 50.dp else 40.dp).clip(CircleShape).background(col)
                            .border(if (i == picked) 4.dp else 0.dp, Color(0xFF424242), CircleShape)
                            .clickable { picked = i; speaker.say(colorNames[i]) }
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedButton(
                    onClick = {
                        val c = history.lastOrNull()
                        if (c != null) {
                            grid = grid.toMutableList().also { it[c] = it[c].dropLast(1) }
                            history = history.dropLast(1)
                        }
                    },
                    enabled = history.isNotEmpty()
                ) { Text("↩ Undo") }
                OutlinedButton(onClick = { grid = List(cols) { listOf() }; history = listOf() }) { Text("🗑️ Clear") }
            }
        }
    }
}
