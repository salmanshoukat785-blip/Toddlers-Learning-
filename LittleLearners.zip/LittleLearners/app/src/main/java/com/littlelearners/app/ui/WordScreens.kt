@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.littlelearners.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.littlelearners.app.Category
import com.littlelearners.app.ParentStore
import com.littlelearners.app.Rewards
import com.littlelearners.app.UrduLocale
import com.littlelearners.app.rememberSpeaker
import java.util.Calendar
import java.util.Locale

// ------------------------------------------------------------------ Make Words

/** Tap the letters in the right order to spell the word shown in the picture. */
@Composable
fun WordBuildScreen(category: Category, onBack: () -> Unit) {
    val accent = Color(0xFF81D4FA)
    val ctx = LocalContext.current
    val speaker = rememberSpeaker()
    val maxLen = if (ParentStore.easy(ctx)) 4 else 6
    val own = remember(category) { gameItems(category) }
    val animals = remember { gameItems(Category.ANIMALS) }
    val words = remember(category, maxLen) {
        val ok = (if (own.size >= 8) own else animals).filter { g -> g.en.all { it.isLetter() } && g.en.length in 3..maxLen }
        if (ok.size >= 3) ok else animals.filter { g -> g.en.all { it.isLetter() } && g.en.length in 3..maxLen }
    }
    var round by remember { mutableStateOf(0) }
    val item = remember(round, words) { words.random() }
    val target = item.en.uppercase()
    val tiles = remember(round, words) { target.toList().shuffled() }
    var filled by remember(round) { mutableStateOf(0) }
    var used by remember(round) { mutableStateOf(setOf<Int>()) }
    var msg by remember(round) { mutableStateOf("Tap the letters to spell the word") }
    val done = filled == target.length
    LaunchedEffect(done, round) { if (done) { Rewards.add(ctx, 1); speaker.say(item.en) } }

    var lang by remember { mutableStateOf(0) }
    ScreenScaffold("Make Words 🔠", accent, onBack) {
        TabsBar(listOf("English", "اردو"), lang, accent) { lang = it }
        Spacer(Modifier.height(8.dp))
        if (lang == 1) { UrduWordBuild(category, accent); return@ScreenScaffold }
        Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
            PhotoImage(item.photo, Modifier.size(170.dp).clickable { speaker.say(item.en) })
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                target.forEachIndexed { i, ch ->
                    Box(
                        Modifier.size(48.dp).clip(RoundedCornerShape(10.dp))
                            .background(if (i < filled) Color(0xFFA5D6A7) else Color(0xFFEEEEEE)),
                        contentAlignment = Alignment.Center
                    ) { Text(if (i < filled) "$ch" else "", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold) }
                }
            }
            Spacer(Modifier.height(12.dp))
            Text(if (done) "🎉 ${item.en}!  ${item.ur}  +1 ⭐" else msg, fontSize = 18.sp, fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                tiles.forEachIndexed { i, ch ->
                    if (i in used) Spacer(Modifier.size(52.dp))
                    else Card(
                        onClick = {
                            if (!done) {
                                if (ch == target[filled]) { filled++; used = used + i; speaker.say("$ch"); msg = "Good!" }
                                else msg = "Try another letter 🙂"
                            }
                        },
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        border = BorderStroke(3.dp, accent),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.size(52.dp)
                    ) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text("$ch", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
                        }
                    }
                }
            }
            if (done) {
                Spacer(Modifier.height(20.dp))
                Button(onClick = { round++ }) { Text("Next word ▶") }
            }
        }
    }
}

/** Urdu: tap the letters in the right order (right to left) to spell the Urdu name of the picture. */
@Composable
private fun UrduWordBuild(category: Category, accent: Color) {
    val ctx = LocalContext.current
    val speaker = rememberSpeaker()
    val maxLen = if (ParentStore.easy(ctx)) 3 else 5
    val own = remember(category) { gameItems(category) }
    val animals = remember { gameItems(Category.ANIMALS) }
    val words = remember(category, maxLen) {
        fun ok(g: GameItem) = g.ur.length in 2..maxLen && g.ur.all { it.isLetter() }
        val a = (if (own.size >= 8) own else animals).filter(::ok)
        if (a.size >= 3) a else animals.filter(::ok).ifEmpty { animals }
    }
    var round by remember { mutableStateOf(0) }
    val item = remember(round, words) { words.random() }
    val target = item.ur
    val tiles = remember(round, words) { target.toList().shuffled() }
    var filled by remember(round) { mutableStateOf(0) }
    var used by remember(round) { mutableStateOf(setOf<Int>()) }
    var msg by remember(round) { mutableStateOf("حروف کو ترتیب سے دبائیں") }
    val done = filled == target.length
    LaunchedEffect(done, round) { if (done) { Rewards.add(ctx, 1); speaker.say(target, UrduLocale) } }

    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        PhotoImage(item.photo, Modifier.size(170.dp).clickable { speaker.say(item.ur, UrduLocale) })
        Text(item.en, fontSize = 14.sp, color = Color.Gray)
        Spacer(Modifier.height(10.dp))
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                target.forEachIndexed { i, ch ->
                    Box(
                        Modifier.size(52.dp).clip(RoundedCornerShape(10.dp))
                            .background(if (i < filled) Color(0xFFA5D6A7) else Color(0xFFEEEEEE)),
                        contentAlignment = Alignment.Center
                    ) { Text(if (i < filled) "$ch" else "", fontSize = 30.sp, fontWeight = FontWeight.Bold) }
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        Text(if (done) "🎉 $target  +1 ⭐" else msg, fontSize = 20.sp, fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(16.dp))
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                tiles.forEachIndexed { i, ch ->
                    if (i in used) Spacer(Modifier.size(56.dp))
                    else Card(
                        onClick = {
                            if (!done) {
                                if (ch == target[filled]) { filled++; used = used + i; speaker.say("$ch", UrduLocale); msg = "شاباش!" }
                                else msg = "دوسرا حرف آزمائیں 🙂"
                            }
                        },
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        border = BorderStroke(3.dp, accent),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.size(56.dp)
                    ) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text("$ch", fontSize = 30.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
        if (done) {
            Spacer(Modifier.height(20.dp))
            Button(onClick = { round++ }) { Text("اگلا لفظ ▶") }
        }
    }
}

// ------------------------------------------------------------------ Days & Months

private class Cal(val en: String, val ur: String)

private val weekDays = listOf(
    Cal("Monday", "پیر"), Cal("Tuesday", "منگل"), Cal("Wednesday", "بدھ"), Cal("Thursday", "جمعرات"),
    Cal("Friday", "جمعہ"), Cal("Saturday", "ہفتہ"), Cal("Sunday", "اتوار")
)
private val months = listOf(
    Cal("January", "جنوری"), Cal("February", "فروری"), Cal("March", "مارچ"), Cal("April", "اپریل"),
    Cal("May", "مئی"), Cal("June", "جون"), Cal("July", "جولائی"), Cal("August", "اگست"),
    Cal("September", "ستمبر"), Cal("October", "اکتوبر"), Cal("November", "نومبر"), Cal("December", "دسمبر")
)
private val islamicMonths = listOf(
    Cal("Muharram", "محرم"), Cal("Safar", "صفر"), Cal("Rabi ul Awwal", "ربیع الاول"), Cal("Rabi ul Thani", "ربیع الثانی"),
    Cal("Jumada al-Awwal", "جمادی الاول"), Cal("Jumada al-Thani", "جمادی الثانی"), Cal("Rajab", "رجب"), Cal("Shaban", "شعبان"),
    Cal("Ramadan", "رمضان"), Cal("Shawwal", "شوال"), Cal("Dhul Qadah", "ذوالقعدہ"), Cal("Dhul Hijjah", "ذوالحجہ")
)

/** Days of the week, months, Islamic months, a "today" card and a quiz. */
@Composable
fun CalendarScreen(onBack: () -> Unit) {
    val accent = Color(0xFFFFCC80)
    val speaker = rememberSpeaker()
    var tab by remember { mutableStateOf(0) }
    val now = remember { Calendar.getInstance() }
    // Calendar.DAY_OF_WEEK: Sunday = 1 ... Saturday = 7  ->  our list starts on Monday
    val todayIdx = (now.get(Calendar.DAY_OF_WEEK) + 5) % 7
    val monthIdx = now.get(Calendar.MONTH)
    val todayText = "Today is ${weekDays[todayIdx].en}, ${now.get(Calendar.DAY_OF_MONTH)} ${months[monthIdx].en}"

    ScreenScaffold("Days & Months 📅", accent, onBack) {
        TabsBar(listOf("Days", "Months", "Islamic", "Quiz"), tab, accent) { tab = it }
        Spacer(Modifier.height(8.dp))
        if (tab == 3) {
            QuizView(accent, speaker, "Calendar") {
                List(5) {
                    when ((0..3).random()) {
                        0 -> {
                            val i = (0..6).random()
                            val ans = weekDays[(i + 1) % 7]
                            val (o, c) = buildChoices(ans, weekDays)
                            Question("What day comes after ${weekDays[i].en}?", "📅", o.map { Option(it.en) }, c, say = "What day comes after ${weekDays[i].en}?")
                        }
                        1 -> {
                            val i = (0..6).random()
                            val ans = weekDays[(i + 6) % 7]
                            val (o, c) = buildChoices(ans, weekDays)
                            Question("What day comes before ${weekDays[i].en}?", "📅", o.map { Option(it.en) }, c, say = "What day comes before ${weekDays[i].en}?")
                        }
                        2 -> {
                            val i = (0..11).random()
                            val ans = months[(i + 1) % 12]
                            val (o, c) = buildChoices(ans, months)
                            Question("Which month comes after ${months[i].en}?", "🗓️", o.map { Option(it.en) }, c, say = "Which month comes after ${months[i].en}?")
                        }
                        else -> {
                            val i = (0..11).random()
                            val ans = months[(i + 11) % 12]
                            val (o, c) = buildChoices(ans, months)
                            Question("Which month comes before ${months[i].en}?", "🗓️", o.map { Option(it.en) }, c, say = "Which month comes before ${months[i].en}?")
                        }
                    }
                }
            }
            return@ScreenScaffold
        }
        val list = when (tab) { 0 -> weekDays; 1 -> months; else -> islamicMonths }
        if (tab == 0) {
            Card(
                onClick = { speaker.say(todayText) },
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF59D)),
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
            ) {
                Text("🌞 $todayText", fontSize = 20.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(14.dp))
            }
        }
        LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            itemsIndexed(list) { i, c ->
                val isToday = (tab == 0 && i == todayIdx) || (tab == 1 && i == monthIdx)
                Card(
                    colors = CardDefaults.cardColors(containerColor = if (isToday) Color(0xFFFFF59D) else Color.White),
                    border = BorderStroke(2.dp, accent),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("${i + 1}", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.size(36.dp))
                        Text(c.en, fontSize = 22.sp, fontWeight = FontWeight.Bold,
                            modifier = Modifier.weight(1f).clickable { speaker.say(c.en) }.padding(vertical = 6.dp))
                        Text(c.ur, fontSize = 24.sp,
                            modifier = Modifier.clickable { speaker.say(c.ur, UrduLocale) }.padding(6.dp))
                    }
                }
            }
        }
    }
}
