package com.littlelearners.app.ui

import android.content.Context
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp

private val photoIds = HashMap<String, Int>()

/** Drawable id for a photo name such as "num_01" (res/drawable-nodpi/num_01.jpg), or 0. */
fun photoRes(ctx: Context, name: String): Int =
    photoIds.getOrPut(name) { ctx.resources.getIdentifier(name, "drawable", ctx.packageName) }

/** One photo at its natural aspect ratio. */
@Composable
fun PhotoImage(name: String, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val id = remember(name) { photoRes(ctx, name) }
    if (id == 0) return
    val painter = painterResource(id)
    val size = painter.intrinsicSize
    val ratio = if (size.width > 0f && size.height > 0f) size.width / size.height else 1.3f
    Image(
        painter = painter,
        contentDescription = null,
        contentScale = ContentScale.Fit,
        modifier = modifier.aspectRatio(ratio)
    )
}

/** (photos per row, photo width in dp) so that any count from 1 to 20 fits the card. */
fun photoLayout(n: Int): Pair<Int, Int> = when {
    n == 1 -> 1 to 260
    n == 2 -> 2 to 150
    n <= 4 -> 2 to 140
    n <= 6 -> 3 to 96
    n <= 12 -> 3 to 90
    else -> 4 to 72
}

/** [count] copies of one photo, in tidy rows. */
@Composable
fun PhotoGrid(name: String, count: Int) {
    val (perRow, width) = photoLayout(count)
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        List(count) { it }.chunked(perRow).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                row.forEach { _ -> PhotoImage(name, Modifier.width(width.dp)) }
            }
        }
    }
}
