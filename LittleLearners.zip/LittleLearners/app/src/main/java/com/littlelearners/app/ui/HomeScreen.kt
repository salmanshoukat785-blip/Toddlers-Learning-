@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.littlelearners.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.res.painterResource
import com.littlelearners.app.R
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.littlelearners.app.Category
import com.littlelearners.app.LearningModule

private val rainbow = Brush.horizontalGradient(
    listOf(
        Color(0xFFFFCDD2), Color(0xFFFFE0B2), Color(0xFFFFF9C4),
        Color(0xFFC8E6C9), Color(0xFFBBDEFB), Color(0xFFE1BEE7)
    )
)

@Composable
fun HomeScreen(
    selected: Category,
    onCategorySelected: (Category) -> Unit,
    onOpenModule: (LearningModule) -> Unit,
    onOpenParents: () -> Unit
) {
    Box(
        Modifier
            .fillMaxSize()
            .background(selected.color.copy(alpha = 0.22f).compositeOver(MaterialTheme.colorScheme.background))
    ) {
        val bedtime = com.littlelearners.app.ParentStore.bedtime(androidx.compose.ui.platform.LocalContext.current)
        LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 150.dp),
            contentPadding = PaddingValues(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            item(span = { GridItemSpan(maxLineSpan) }) { Header(selected, onCategorySelected) }

            val modules = if (bedtime) LearningModule.entries.filter { it in com.littlelearners.app.ParentStore.bedtimeModules } else LearningModule.entries
            items(modules) { module ->
                ModuleTile(module, selected, onClick = { onOpenModule(module) })
            }

            item(span = { GridItemSpan(maxLineSpan) }) { ParentsButton(onOpenParents) }
        }
    }
}

@Composable
private fun Header(selected: Category, onCategorySelected: (Category) -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .background(rainbow, RoundedCornerShape(32.dp))
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(
            painter = painterResource(R.drawable.logo),
            contentDescription = "Little Learners logo",
            modifier = Modifier.size(84.dp)
        )
        Text(
            "Little Learners",
            style = MaterialTheme.typography.headlineLarge,
            color = MaterialTheme.colorScheme.primary
        )
        Text(
            "Learn • Play • Trace • Draw • Explore",
            fontSize = 13.sp,
            color = Color(0xFFE64A19),
            fontWeight = FontWeight.SemiBold
        )
        Spacer(Modifier.height(12.dp))
        CategorySwitcher(selected, onCategorySelected)
        Spacer(Modifier.height(8.dp))
        Text(
            "No Ads  •  No Login  •  100% Offline",
            fontSize = 12.sp,
            color = Color(0xFF2E7D32),
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
fun CategorySwitcher(selected: Category, onSelected: (Category) -> Unit) {
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(Category.entries) { category ->
            val isSelected = category == selected
            Card(
                onClick = { onSelected(category) },
                colors = CardDefaults.cardColors(
                    containerColor = if (isSelected) category.color else Color.White
                ),
                border = BorderStroke(
                    if (isSelected) 3.dp else 1.dp,
                    if (isSelected) MaterialTheme.colorScheme.primary else category.color
                ),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.width(96.dp)
            ) {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    EmojiView(category.emoji, 36)
                    Text(category.label, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                }
            }
        }
    }
}

@Composable
private fun ModuleTile(module: LearningModule, category: Category, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        colors = CardDefaults.cardColors(containerColor = module.color),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
        shape = RoundedCornerShape(24.dp),
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(1f)
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            EmojiView(module.emoji, if (module == LearningModule.URDU) 36 else 64)
            Spacer(Modifier.height(6.dp))
            Text(
                module.title,
                style = MaterialTheme.typography.titleMedium,
                textAlign = TextAlign.Center,
                color = Color(0xFF212121)
            )
            Text(
                module.subtitle,
                style = MaterialTheme.typography.bodySmall,
                textAlign = TextAlign.Center,
                color = Color(0xFF424242)
            )
        }
    }
}

@Composable
private fun ParentsButton(onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .background(Color(0xFFFFF3E0), RoundedCornerShape(24.dp))
            .clickable(onClick = onClick)
            .padding(16.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("👨‍👩‍👧  Parent Section", fontWeight = FontWeight.Bold, fontSize = 16.sp)
    }
}
