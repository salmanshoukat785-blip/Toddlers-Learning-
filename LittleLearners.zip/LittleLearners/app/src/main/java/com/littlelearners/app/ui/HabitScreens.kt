@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.littlelearners.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.littlelearners.app.Rewards
import com.littlelearners.app.UrduLocale
import com.littlelearners.app.rememberSpeaker

private class Step(val emoji: String, val en: String, val ur: String)
private class Routine(val emoji: String, val title: String, val steps: List<Step>)

private val routines = listOf(
    Routine("🧼", "Wash your hands", listOf(
        Step("🚰", "Turn on the water", "پانی کھولو"),
        Step("🧼", "Rub soap on your hands", "ہاتھوں پر صابن لگاؤ"),
        Step("👏", "Rub, rub, rub for 20 seconds", "20 سیکنڈ تک ہاتھ ملو"),
        Step("💦", "Rinse off the soap", "صابن دھو لو"),
        Step("🧻", "Dry your hands with a towel", "تولیے سے ہاتھ خشک کرو"))),
    Routine("🪥", "Brush your teeth", listOf(
        Step("🪥", "Put a little paste on the brush", "برش پر تھوڑا سا پیسٹ لگاؤ"),
        Step("😁", "Brush the front teeth", "آگے کے دانت صاف کرو"),
        Step("🦷", "Brush the back teeth", "پیچھے کے دانت صاف کرو"),
        Step("💦", "Rinse your mouth with water", "پانی سے کلی کرو"),
        Step("🌟", "Smile! Clean teeth!", "مسکراؤ! دانت صاف!"))),
    Routine("👕", "Get dressed", listOf(
        Step("👕", "Put on your shirt", "قمیض پہنو"),
        Step("👖", "Put on your trousers", "پتلون پہنو"),
        Step("🧦", "Put on your socks", "موزے پہنو"),
        Step("👟", "Put on your shoes", "جوتے پہنو"))),
    Routine("🎒", "Get ready for school", listOf(
        Step("🥣", "Eat your breakfast", "ناشتہ کرو"),
        Step("🎒", "Pack your school bag", "بستہ تیار کرو"),
        Step("💧", "Take your water bottle", "پانی کی بوتل لو"),
        Step("🤝", "Say goodbye and salam", "الوداع اور سلام کہو"))),
    Routine("🌙", "Bedtime", listOf(
        Step("🛁", "Take a bath", "نہا لو"),
        Step("🪥", "Brush your teeth", "دانت صاف کرو"),
        Step("📖", "Listen to a story", "کہانی سنو"),
        Step("🤲", "Say your bedtime dua", "سونے کی دعا پڑھو"),
        Step("😴", "Close your eyes. Good night!", "آنکھیں بند کرو۔ شب بخیر!")))
)

private class Sound(val name: String, val sound: String)

private val sounds = listOf(
    Sound("🚗 Car", "Vroom vroom"),
    Sound("🚂 Train", "Choo choo"),
    Sound("🚑 Ambulance", "Wee woo wee woo"),
    Sound("🔔 Doorbell", "Ding dong"),
    Sound("⏰ Clock", "Tick tock tick tock"),
    Sound("📞 Phone", "Ring ring ring"),
    Sound("🌧️ Rain", "Pitter patter pitter patter"),
    Sound("👶 Baby", "Waa waa waa"),
    Sound("👏 Clapping", "Clap clap clap"),
    Sound("🥁 Drum", "Boom boom boom"),
    Sound("✈️ Aeroplane", "Whoosh"),
    Sound("🐝 Bee", "Buzz buzz")
)

/** Daily habits (step-by-step routines) and a "guess the sound" quiz. */
@Composable
fun HabitsScreen(onBack: () -> Unit) {
    val accent = Color(0xFF80DEEA)
    val ctx = LocalContext.current
    val speaker = rememberSpeaker()
    var tab by remember { mutableStateOf(0) }
    var current by remember { mutableStateOf<Routine?>(null) }
    var step by remember { mutableStateOf(0) }
    val open = current

    ScreenScaffold(open?.title ?: "Habits & Sounds 🧼", accent, { if (open != null) current = null else onBack() }) {
        if (open == null) {
            TabsBar(listOf("Daily habits", "Guess the sound"), tab, accent) { tab = it }
            Spacer(Modifier.height(8.dp))
            if (tab == 0) {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    routines.forEach { r ->
                        Card(
                            onClick = { current = r; step = 0 },
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = BorderStroke(3.dp, accent),
                            shape = RoundedCornerShape(18.dp),
                            modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)
                        ) {
                            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(r.emoji, fontSize = 40.sp)
                                Spacer(Modifier.padding(8.dp))
                                Text(r.title, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            } else {
                QuizView(accent, speaker, "Sounds") {
                    sounds.shuffled().take(5).map { s ->
                        val wrong = sounds.filter { it !== s }.shuffled().take(2)
                        val opts = (wrong + s).shuffled()
                        Question(
                            prompt = "What makes this sound?",
                            big = "🔊",
                            sub = s.sound + "!",
                            options = opts.map { Option(it.name) },
                            correct = opts.indexOf(s),
                            say = s.sound
                        )
                    }
                }
            }
        } else {
            val st = open.steps[step]
            val last = step == open.steps.size - 1
            LaunchedEffect(open, step) { speaker.say(st.en) }
            LaunchedEffect(open, last) { if (last) Rewards.add(ctx, 2) }
            Text("Step ${step + 1} / ${open.steps.size}", fontSize = 14.sp, color = Color.Gray,
                modifier = Modifier.align(Alignment.CenterHorizontally))
            Spacer(Modifier.height(10.dp))
            Text(st.emoji, fontSize = 110.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            Text(st.en, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth())
            Text(st.ur, fontSize = 24.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(top = 6.dp))
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                OutlinedButton(onClick = { speaker.say(st.en) }) { Text("🔊 EN") }
                OutlinedButton(onClick = { speaker.say(st.ur, UrduLocale) }) { Text("🔊 اردو") }
            }
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                OutlinedButton(onClick = { if (step > 0) step-- }, enabled = step > 0) { Text("◀ Back") }
                if (last) Button(onClick = { current = null }) { Text("🎉 Done! +2 ⭐") }
                else Button(onClick = { step++ }) { Text("Next ▶") }
            }
        }
    }
}
