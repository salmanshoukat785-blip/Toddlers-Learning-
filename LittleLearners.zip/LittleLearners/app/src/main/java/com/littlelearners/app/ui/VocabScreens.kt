@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.littlelearners.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.littlelearners.app.UrduLocale
import com.littlelearners.app.rememberSpeaker

/**
 * Toddler vocabulary. A word uses its photo res/drawable-nodpi/vo_<group>_<slug>.jpg when it exists,
 * otherwise its emoji (third field). Words with neither are hidden until a photo is added.
 * Slug = English name in lower case with non-letters turned into "_" (e.g. "Teddy bear" -> teddy_bear).
 */
private class VocabGroup(val key: String, val title: String, val emoji: String, val words: List<String>)

private class Word(val en: String, val ur: String, val photo: String?, val emoji: String)

private val vocabGroups = listOf(
    VocabGroup("family", "Family & People", "👨‍👩‍👧", listOf("Mother|ماں|", "Father|باپ|", "Baby|بچہ|", "Brother|بھائی|", "Sister|بہن|", "Grandmother|دادی|", "Grandfather|دادا|", "Boy|لڑکا|", "Girl|لڑکی|", "Teacher|استاد|", "Doctor|ڈاکٹر|", "Friends|دوست|")),
    VocabGroup("home", "Home", "🏠", listOf("Bed|بستر|🛏️", "Chair|کرسی|🪑", "Table|میز|", "Sofa|صوفہ|🛋️", "Door|دروازہ|🚪", "Window|کھڑکی|🪟", "Lamp|چراغ|💡", "Fan|پنکھا|🪭", "Clock|گھڑی|🕐", "Mirror|آئینہ|🪞", "Kitchen|باورچی خانہ|🍳", "Bathroom|غسل خانہ|🚿")),
    VocabGroup("food", "Food & Drinks", "🍞", listOf("Bread|روٹی|🍞", "Rice|چاول|🍚", "Egg|انڈا|🥚", "Milk|دودھ|🥛", "Water|پانی|💧", "Juice|جوس|🧃", "Cheese|پنیر|🧀", "Biscuit|بسکٹ|🍪", "Cake|کیک|🍰", "Ice cream|آئس کریم|🍦", "Chocolate|چاکلیٹ|🍫", "Soup|سوپ|🍲")),
    VocabGroup("clothes", "Clothes", "👕", listOf("Shirt|قمیض|👕", "Trousers|پتلون|👖", "Frock|فراک|👗", "Cap|ٹوپی|🧢", "Socks|موزے|🧦", "Shoes|جوتے|👟", "Jacket|جیکٹ|🧥", "Scarf|مفلر|🧣", "Gloves|دستانے|🧤", "Sweater|سویٹر|", "Pyjamas|پاجامہ|", "Bag|بستہ|🎒")),
    VocabGroup("toys", "Toys", "🧸", listOf("Ball|گیند|⚽", "Doll|گڑیا|🪆", "Teddy bear|ٹیڈی بیئر|🧸", "Toy car|کھلونا گاڑی|🚗", "Blocks|بلاکس|🧱", "Balloon|غبارہ|🎈", "Kite|پتنگ|🪁", "Drum|ڈھول|🥁", "Swing|جھولا|", "Slide|پھسلنی|", "Bicycle|سائیکل|🚲", "Puzzle|پہیلی|🧩")),
    VocabGroup("actions", "Actions", "🏃", listOf("Eat|کھانا|🍽️", "Drink|پینا|🥤", "Sleep|سونا|😴", "Run|دوڑنا|🏃", "Walk|چلنا|🚶", "Jump|کودنا|🤸", "Sit|بیٹھنا|", "Stand|کھڑے ہونا|🧍", "Clap|تالی بجانا|👏", "Wash hands|ہاتھ دھونا|🧼", "Brush teeth|دانت صاف کرنا|🪥", "Read|پڑھنا|📖")),
    VocabGroup("feelings", "Feelings", "😊", listOf("Happy|خوش|😊", "Sad|اداس|😢", "Angry|غصہ|😠", "Scared|ڈرا ہوا|😨", "Sleepy|نیند|😴", "Surprised|حیران|😲", "Laughing|ہنسنا|😂", "Crying|رونا|😭", "Hungry|بھوکا|", "Excited|پرجوش|🤩", "Shy|شرمیلا|😳", "Proud|فخر|")),
    VocabGroup("school", "School & Daily", "🎒", listOf("Book|کتاب|📖", "Pencil|پنسل|✏️", "Crayons|رنگین پنسلیں|🖍️", "Eraser|ربڑ|", "Scissors|قینچی|✂️", "School bag|اسکول بیگ|🎒", "Blackboard|بلیک بورڈ|", "Toothbrush|ٹوتھ برش|🪥", "Soap|صابن|🧼", "Towel|تولیہ|", "Comb|کنگھی|", "Water bottle|پانی کی بوتل|")),
    VocabGroup("opp", "Opposites", "↔️", listOf("Big|بڑا|", "Small|چھوٹا|", "Tall|لمبا|", "Short|چھوٹا قد|", "Long|لمبا (لکیر)|", "Short (length)|چھوٹا (لکیر)|", "Hot|گرم|🔥", "Cold|ٹھنڈا|🥶", "Full|بھرا ہوا|", "Empty|خالی|", "Heavy|بھاری|🏋️", "Light|ہلکا|🪶", "Open|کھلا|🔓", "Closed|بند|🔒", "Fast|تیز|🐆", "Slow|آہستہ|🐌", "Up|اوپر|⬆️", "Down|نیچے|⬇️", "Many|زیادہ|", "Few|کم|", "Wet|گیلا|💧", "Dry|سوکھا|🏜️", "Clean|صاف|✨", "Dirty|گندا|")),
    VocabGroup("pos", "Positions", "📍", listOf("In|اندر|", "Out|باہر|", "On|اوپر (پر)|", "Under|نیچے (تلے)|", "Behind|پیچھے|", "In front|آگے|", "Next to|ساتھ|", "Between|درمیان|", "Top|اوپری حصہ|", "Bottom|نچلا حصہ|", "Left|بائیں|", "Right|دائیں|"))
)

private fun slug(en: String) = en.lowercase().replace(Regex("[^a-z0-9]+"), "_").trim('_')

@Composable
fun VocabularyScreen(onBack: () -> Unit) {
    val accent = Color(0xFFFFCC80)
    val ctx = LocalContext.current
    val speaker = rememberSpeaker()
    var g by remember { mutableStateOf(0) }
    var tab by remember { mutableStateOf(0) }
    val group = vocabGroups[g]
    val words = remember(g) {
        group.words.mapNotNull { line ->
            val p = line.split("|")
            val en = p[0]
            val ur = p[1]
            val emoji = p.getOrNull(2).orEmpty()
            val photo = "vo_${group.key}_${slug(en)}"
            val hasPhoto = photoRes(ctx, photo) != 0
            if (hasPhoto) Word(en, ur, photo, emoji) else if (emoji.isNotEmpty()) Word(en, ur, null, emoji) else null
        }
    }

    ScreenScaffold("Vocabulary 📚", accent, onBack) {
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items(vocabGroups.size) { i ->
                val x = vocabGroups[i]
                Card(
                    onClick = { g = i; tab = 0 },
                    colors = CardDefaults.cardColors(containerColor = if (i == g) accent else Color.White),
                    border = BorderStroke(2.dp, accent),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Text("${x.emoji} ${x.title}", fontSize = 14.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp))
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        if (words.size < 3) {
            Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text(group.emoji, fontSize = 70.sp)
                Text("${group.title}: pictures coming soon", fontSize = 18.sp, textAlign = TextAlign.Center)
            }
            return@ScreenScaffold
        }
        TabsBar(listOf("Learn (${words.size})", "Quiz"), tab, accent) { tab = it }
        Spacer(Modifier.height(8.dp))
        if (tab == 0) {
            Text("Tap a word to hear it 🔊", fontSize = 14.sp, color = Color.Gray,
                modifier = Modifier.align(Alignment.CenterHorizontally))
            Spacer(Modifier.height(4.dp))
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(words) { w ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        border = BorderStroke(3.dp, accent),
                        shape = RoundedCornerShape(18.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            if (w.photo != null) PhotoImage(w.photo, Modifier.fillMaxWidth().clickable { speaker.say(w.en) })
                            else EmojiView(w.emoji, 80, Modifier.clickable { speaker.say(w.en) }.padding(8.dp))
                            Text(w.en, fontSize = 20.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth().clickable { speaker.say(w.en) }.padding(top = 6.dp))
                            Text(w.ur, fontSize = 22.sp, textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth().clickable { speaker.say(w.ur, UrduLocale) }.padding(vertical = 4.dp))
                        }
                    }
                }
            }
        } else {
            QuizView(accent, speaker, "Vocabulary") {
                words.shuffled().take(5).map { w ->
                    val (opts, c) = buildChoices(w, words)
                    Question(
                        prompt = "What is this?",
                        big = if (w.photo == null) w.emoji else "",
                        bigSize = 90,
                        options = opts.map { Option(it.en) },
                        correct = c,
                        say = w.en,
                        photo = w.photo
                    )
                }
            }
        }
    }
}
