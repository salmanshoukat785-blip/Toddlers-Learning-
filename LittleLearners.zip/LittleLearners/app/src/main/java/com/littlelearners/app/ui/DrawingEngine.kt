package com.littlelearners.app.ui

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Canvas as GfxCanvas
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.graphics.drawscope.CanvasDrawScope
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.LayoutDirection
import java.io.File

// ---------------- Freehand strokes ----------------

data class DrawnStroke(val points: List<Offset>, val color: Color, val width: Float)

/** Holds everything a freehand canvas needs. Plain class so gesture lambdas never see stale state. */
class StrokeBoard {
    var strokes by mutableStateOf(listOf<DrawnStroke>())
    var color by mutableStateOf(Color(0xFFE53935))
    var width by mutableStateOf(16f)
    var size by mutableStateOf(IntSize.Zero)

    fun undo() {
        if (strokes.isNotEmpty()) strokes = strokes.dropLast(1)
    }

    fun clear() {
        strokes = emptyList()
    }
}

fun DrawScope.drawStrokes(strokes: List<DrawnStroke>) {
    for (s in strokes) {
        if (s.points.size == 1) {
            drawCircle(s.color, radius = s.width / 2f, center = s.points[0])
        } else {
            val path = Path()
            path.moveTo(s.points[0].x, s.points[0].y)
            for (i in 1 until s.points.size) path.lineTo(s.points[i].x, s.points[i].y)
            drawPath(
                path,
                s.color,
                style = Stroke(width = s.width, cap = StrokeCap.Round, join = StrokeJoin.Round)
            )
        }
    }
}

/** Finger-drawing surface. Draws onto whatever is behind it. */
@androidx.compose.runtime.Composable
fun DrawingCanvas(board: StrokeBoard, modifier: Modifier = Modifier) {
    Canvas(
        modifier
            .onSizeChanged { board.size = it }
            .pointerInput(Unit) {
                detectTapGestures(onTap = { p ->
                    board.strokes = board.strokes + DrawnStroke(listOf(p), board.color, board.width)
                })
            }
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { p ->
                        board.strokes = board.strokes + DrawnStroke(listOf(p), board.color, board.width)
                    },
                    onDrag = { change, _ ->
                        change.consume()
                        val last = board.strokes.lastOrNull()
                        if (last != null) {
                            board.strokes = board.strokes.dropLast(1) +
                                last.copy(points = last.points + change.position)
                        }
                    }
                )
            }
    ) {
        drawStrokes(board.strokes)
    }
}

// ---------------- Colorable pictures ----------------

sealed class Shape {
    abstract fun contains(x: Float, y: Float): Boolean
    abstract fun toPath(w: Float, h: Float): Path
}

class Ell(val cx: Float, val cy: Float, val rx: Float, val ry: Float) : Shape() {
    override fun contains(x: Float, y: Float): Boolean {
        val dx = (x - cx) / rx
        val dy = (y - cy) / ry
        return dx * dx + dy * dy <= 1f
    }

    override fun toPath(w: Float, h: Float) = Path().apply {
        addOval(Rect((cx - rx) * w, (cy - ry) * h, (cx + rx) * w, (cy + ry) * h))
    }
}

fun Circ(cx: Float, cy: Float, r: Float) = Ell(cx, cy, r, r)

class Rct(val l: Float, val t: Float, val r: Float, val b: Float) : Shape() {
    override fun contains(x: Float, y: Float) = x in l..r && y in t..b
    override fun toPath(w: Float, h: Float) = Path().apply {
        addRect(Rect(l * w, t * h, r * w, b * h))
    }
}

class Poly(val pts: List<Pair<Float, Float>>) : Shape() {
    override fun contains(x: Float, y: Float): Boolean {
        var inside = false
        var j = pts.size - 1
        for (i in pts.indices) {
            val (xi, yi) = pts[i]
            val (xj, yj) = pts[j]
            if ((yi > y) != (yj > y) && x < (xj - xi) * (y - yi) / (yj - yi) + xi) inside = !inside
            j = i
        }
        return inside
    }

    override fun toPath(w: Float, h: Float) = Path().apply {
        moveTo(pts[0].first * w, pts[0].second * h)
        for (i in 1 until pts.size) lineTo(pts[i].first * w, pts[i].second * h)
        close()
    }
}

class Picture(val emoji: String, val name: String, val shapes: List<Shape>)

private fun petals(cx: Float, cy: Float, dist: Float, r: Float, n: Int): List<Shape> =
    List(n) { i ->
        val a = 2.0 * Math.PI * i / n
        Circ(cx + (dist * Math.cos(a)).toFloat(), cy + (dist * Math.sin(a)).toFloat(), r)
    }

val pictures: List<Picture> = listOf(
    Picture(
        "🏠", "House", listOf(
            Rct(0f, 0.9f, 1f, 1f),                       // ground
            Circ(0.85f, 0.15f, 0.09f),                   // sun
            Rct(0.68f, 0.2f, 0.76f, 0.36f),              // chimney
            Rct(0.2f, 0.45f, 0.8f, 0.9f),                // wall
            Poly(listOf(0.12f to 0.45f, 0.5f to 0.18f, 0.88f to 0.45f)), // roof
            Rct(0.44f, 0.62f, 0.58f, 0.9f),              // door
            Rct(0.26f, 0.55f, 0.38f, 0.67f),             // window
            Rct(0.64f, 0.55f, 0.76f, 0.67f)              // window
        )
    ),
    Picture(
        "🌸", "Flower", listOf(
            Rct(0f, 0.88f, 1f, 1f),                      // ground
            Circ(0.85f, 0.12f, 0.08f),                   // sun
            Rct(0.47f, 0.45f, 0.53f, 0.9f),              // stem
            Ell(0.37f, 0.72f, 0.1f, 0.05f),              // leaf
            Ell(0.63f, 0.65f, 0.1f, 0.05f)               // leaf
        ) + petals(0.5f, 0.3f, 0.15f, 0.09f, 6) + listOf(Circ(0.5f, 0.3f, 0.09f))
    ),
    Picture(
        "🐟", "Fish", listOf(
            Poly(listOf(0.7f to 0.5f, 0.92f to 0.32f, 0.92f to 0.68f)), // tail
            Poly(listOf(0.4f to 0.34f, 0.55f to 0.2f, 0.58f to 0.36f)), // fin
            Ell(0.45f, 0.5f, 0.28f, 0.18f),              // body
            Circ(0.3f, 0.45f, 0.035f),                   // eye
            Circ(0.12f, 0.3f, 0.03f),                    // bubble
            Circ(0.08f, 0.2f, 0.02f)                     // bubble
        )
    ),
    Picture(
        "🌳", "Tree", listOf(
            Rct(0f, 0.9f, 1f, 1f),                       // ground
            Circ(0.85f, 0.12f, 0.08f),                   // sun
            Rct(0.44f, 0.5f, 0.56f, 0.9f),               // trunk
            Circ(0.35f, 0.42f, 0.14f),                   // crown
            Circ(0.65f, 0.42f, 0.14f),                   // crown
            Circ(0.5f, 0.32f, 0.2f),                     // crown
            Circ(0.42f, 0.3f, 0.03f),                    // apple
            Circ(0.6f, 0.36f, 0.03f),                    // apple
            Circ(0.5f, 0.45f, 0.03f)                     // apple
        )
    )
)

fun DrawScope.drawPicture(picture: Picture, fills: Map<Int, Color>) {
    picture.shapes.forEachIndexed { i, shape ->
        val path = shape.toPath(size.width, size.height)
        drawPath(path, fills[i] ?: Color.White)
        drawPath(path, Color(0xFF424242), style = Stroke(width = size.width * 0.008f + 2f, join = StrokeJoin.Round))
    }
}

/** Index of the top-most shape at (x,y) in 0..1 coordinates, or -1. */
fun Picture.hit(x: Float, y: Float): Int {
    for (i in shapes.indices.reversed()) if (shapes[i].contains(x, y)) return i
    return -1
}

// ---------------- Saving ----------------

fun renderToBitmap(w: Int, h: Int, background: Color, block: DrawScope.() -> Unit): Bitmap {
    val image = ImageBitmap(w, h)
    val canvas = GfxCanvas(image)
    CanvasDrawScope().draw(Density(1f), LayoutDirection.Ltr, canvas, Size(w.toFloat(), h.toFloat())) {
        drawRect(background)
        block()
    }
    return image.asAndroidBitmap()
}

/** Saves to Pictures/LittleLearners (Android 10+) or the app's own pictures folder (older). */
fun saveArt(context: Context, bitmap: Bitmap, prefix: String): Boolean {
    val name = "${prefix}_${System.currentTimeMillis()}.png"
    return try {
        if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, name)
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/LittleLearners")
            }
            val uri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: return false
            context.contentResolver.openOutputStream(uri)?.use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
        } else {
            val dir = context.getExternalFilesDir(Environment.DIRECTORY_PICTURES) ?: context.filesDir
            File(dir, name).outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
        }
        true
    } catch (e: Exception) {
        false
    }
}
