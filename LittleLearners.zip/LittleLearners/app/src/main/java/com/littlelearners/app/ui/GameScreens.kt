@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.littlelearners.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.imageResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.littlelearners.app.Category
import com.littlelearners.app.Rewards
import com.littlelearners.app.UrduLocale
import com.littlelearners.app.englishAlphabetFor
import com.littlelearners.app.rememberSpeaker
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** One picture with its English and Urdu name; built from the selected category's ABC data. */
internal data class GameItem(val en: String, val ur: String, val photo: String)

internal fun gameItems(category: Category): List<GameItem> =
    englishAlphabetFor(category).mapNotNull { l ->
        l.photo?.let { GameItem(l.word, l.urdu, it) }
    }

private val gameGreen = Color(0xFF66BB6A)

/** Mini-games hub: Memory, Match and Puzzle for the selected category. [start] picks the first tab. */
@Composable
fun GamesScreen(category: Category, start: Int, onBack: () -> Unit) {
    val accent = Color(0xFFFFD54F)
    val items = remember(category) { gameItems(category) }
    var tab by remember { mutableStateOf(start.coerceIn(0, 2)) }

    ScreenScaffold("Mini-Games ${category.emoji}", accent, onBack) {
        if (items.size < 8) {
            ComingSoon(accent, category)
            return@ScreenScaffold
        }
        TabsBar(listOf("Memory", "Match", "Puzzle"), tab, accent) { tab = it }
        Spacer(Modifier.height(10.dp))
        when (tab) {
            0 -> MemoryGame(items, accent)
            1 -> MatchGame(items, accent)
            else -> PuzzleGame(items, accent)
        }
    }
}

// ======================= MEMORY =======================

private data class MemCard(val pair: Int, val item: GameItem)

@Composable
private fun MemoryGame(pool: List<GameItem>, accent: Color) {
    val ctx = LocalContext.current
    val speaker = rememberSpeaker()
    val scope = rememberCoroutineScope()
    var level by remember { mutableStateOf(0) }
    var round by remember { mutableStateOf(0) }
    val pairCount = listOf(3, 6, 8)[level]

    val cards = remember(level, round, pool) {
        val picked = pool.shuffled().take(pairCount)
        val doubled = picked.mapIndexed { i, g -> MemCard(i, g) }
        (doubled + doubled).shuffled()
    }
    var flipped by remember(level, round) { mutableStateOf(listOf<Int>()) }
    var matched by remember(level, round) { mutableStateOf(setOf<Int>()) }
    var moves by remember(level, round) { mutableStateOf(0) }
    var locked by remember(level, round) { mutableStateOf(false) }
    val won = matched.size == pairCount
    LaunchedEffect(won, level, round) { if (won) Rewards.add(ctx, 3) }

    Column(Modifier.fillMaxSize()) {
        TabsBar(listOf("Easy", "Medium", "Hard"), level, accent) { level = it }
        Spacer(Modifier.height(8.dp))
        Text(
            if (won) "🎉 Well done!  Moves: $moves" else "Find the matching pictures   Moves: $moves",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
        Spacer(Modifier.height(8.dp))
        LazyVerticalGrid(
            columns = GridCells.Fixed(if (cards.size > 12) 4 else 3),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.weight(1f)
        ) {
            items(cards.size) { i ->
                val card = cards[i]
                val isMatched = card.pair in matched
                val faceUp = isMatched || i in flipped
                Card(
                    onClick = {
                        if (locked || faceUp || won) return@Card
                        val now = flipped + i
                        flipped = now
                        if (now.size == 2) {
                            moves++
                            val a = cards[now[0]]
                            val b = cards[now[1]]
                            if (a.pair == b.pair) {
                                matched = matched + a.pair
                                flipped = emptyList()
                                speaker.say(a.item.en)
                            } else {
                                locked = true
                                scope.launch {
                                    delay(900)
                                    flipped = emptyList()
                                    locked = false
                                }
                            }
                        }
                    },
                    colors = CardDefaults.cardColors(containerColor = if (faceUp) Color.White else accent),
                    border = BorderStroke(3.dp, if (isMatched) gameGreen else accent),
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(0.9f)
                ) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        if (faceUp) {
                            PhotoImage(card.item.photo, Modifier.fillMaxWidth(0.9f))
                        } else {
                            Text("?", fontSize = 44.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
                        }
                    }
                }
            }
        }
        if (won) {
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = { round++ },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
            ) { Text("Play again", fontSize = 20.sp) }
        }
    }
}

// ======================= MATCH PICTURE TO NAME =======================

@Composable
private fun MatchGame(items: List<GameItem>, accent: Color) {
    val ctx = LocalContext.current
    val speaker = rememberSpeaker()
    var round by remember { mutableStateOf(0) }
    val pics = remember(round, items) { items.shuffled().take(4) }
    val names = remember(round, items) { pics.shuffled() }
    var selected by remember(round) { mutableStateOf(-1) }
    var done by remember(round) { mutableStateOf(setOf<String>()) }
    var message by remember(round) { mutableStateOf("Tap a picture, then its name") }
    val won = done.size == pics.size
    LaunchedEffect(won, round) { if (won) Rewards.add(ctx, 2) }

    Column(Modifier.fillMaxSize()) {
        Text(
            if (won) "🎉 Well done!" else message,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
        Spacer(Modifier.height(8.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            for (r in 0..1) {
                Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    for (c in 0..1) {
                        val idx = r * 2 + c
                        val g = pics[idx]
                        val isDone = g.photo in done
                        Card(
                            onClick = {
                                if (!isDone) {
                                    selected = idx
                                    speaker.say(g.en)
                                }
                            },
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = BorderStroke(
                                if (selected == idx || isDone) 5.dp else 2.dp,
                                if (isDone) gameGreen else if (selected == idx) Color(0xFFFB8C00) else accent
                            ),
                            shape = RoundedCornerShape(20.dp),
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                                .alpha(if (isDone) 0.45f else 1f)
                        ) {
                            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                PhotoImage(g.photo, Modifier.fillMaxWidth(0.9f))
                            }
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        for (r in 0..1) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                for (c in 0..1) {
                    val g = names[r * 2 + c]
                    val isDone = g.photo in done
                    Card(
                        onClick = {
                            if (isDone || won) return@Card
                            if (selected < 0) {
                                message = "Pick a picture first 🙂"
                            } else if (pics[selected].photo == g.photo) {
                                done = done + g.photo
                                selected = -1
                                message = "🌟 Great!"
                                speaker.say(g.en)
                            } else {
                                message = "Try again 🙂"
                            }
                        },
                        colors = CardDefaults.cardColors(containerColor = if (isDone) Color(0xFFC8E6C9) else Color.White),
                        border = BorderStroke(3.dp, if (isDone) gameGreen else accent),
                        shape = RoundedCornerShape(18.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(72.dp)
                    ) {
                        Column(
                            Modifier.fillMaxSize(),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Text(g.en, fontSize = 18.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, maxLines = 1)
                            Text(g.ur, fontSize = 16.sp, textAlign = TextAlign.Center, maxLines = 1)
                        }
                    }
                }
            }
        }
        if (won) {
            Button(
                onClick = { round++ },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
            ) { Text("Next round", fontSize = 20.sp) }
        }
    }
}

// ======================= PICTURE PUZZLE =======================

@Composable
private fun PuzzleGame(items: List<GameItem>, accent: Color) {
    val ctx = LocalContext.current
    val speaker = rememberSpeaker()
    var level by remember { mutableStateOf(0) }
    var round by remember { mutableStateOf(0) }
    val n = if (level == 0) 2 else 3
    val item = remember(round, items) { items.random() }
    val bitmap: ImageBitmap? = remember(item.photo) {
        val id = photoRes(ctx, item.photo)
        if (id == 0) null else ImageBitmap.imageResource(ctx.resources, id)
    }
    var order by remember(round, level, items) {
        mutableStateOf(shuffledOrder(n * n))
    }
    var selected by remember(round, level) { mutableStateOf(-1) }
    val solved = order.indices.all { order[it] == it }
    LaunchedEffect(solved, round, level) { if (solved) Rewards.add(ctx, if (n == 2) 3 else 5) }

    Column(Modifier.fillMaxSize()) {
        TabsBar(listOf("Easy 2×2", "Hard 3×3"), level, accent) { level = it }
        Spacer(Modifier.height(8.dp))
        Text(
            if (solved) "🎉 ${item.en}!" else "Tap two pieces to swap them",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
        Spacer(Modifier.height(8.dp))
        if (bitmap != null) {
            val ratio = bitmap.width.toFloat() / bitmap.height.toFloat()
            Column(
                Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Column(
                    Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    for (r in 0 until n) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                            for (c in 0 until n) {
                                val pos = r * n + c
                                val tile = if (solved) pos else order[pos]
                                val borderColor = if (selected == pos) Color(0xFFFB8C00) else accent
                                Canvas(
                                    Modifier
                                        .weight(1f)
                                        .aspectRatio(ratio)
                                        .border(if (selected == pos) 4.dp else 1.dp, borderColor)
                                        .clickable {
                                            if (solved) return@clickable
                                            if (selected < 0) {
                                                selected = pos
                                            } else {
                                                if (selected != pos) {
                                                    val list = order.toMutableList()
                                                    val tmp = list[selected]
                                                    list[selected] = list[pos]
                                                    list[pos] = tmp
                                                    order = list
                                                    if (list.indices.all { list[it] == it }) speaker.say(item.en)
                                                }
                                                selected = -1
                                            }
                                        }
                                ) {
                                    val tw = bitmap.width / n
                                    val th = bitmap.height / n
                                    drawImage(
                                        bitmap,
                                        srcOffset = IntOffset((tile % n) * tw, (tile / n) * th),
                                        srcSize = IntSize(tw, th),
                                        dstSize = IntSize(size.width.toInt(), size.height.toInt())
                                    )
                                }
                            }
                        }
                    }
                }
                if (solved) {
                    Spacer(Modifier.height(6.dp))
                    Text(item.ur, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                }
            }
        } else {
            Spacer(Modifier.weight(1f))
        }
        Button(
            onClick = {
                round++
                if (solved) speaker.say("Next")
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
        ) { Text(if (solved) "Next puzzle" else "New picture", fontSize = 20.sp) }
        Spacer(Modifier.height(4.dp))
    }
}

/** A random order of 0 until [count] that is not already solved. */
private fun shuffledOrder(count: Int): List<Int> {
    var list = (0 until count).shuffled()
    while (list.indices.all { list[it] == it }) list = (0 until count).shuffled()
    return list
}


// ======================= QUIZZES =======================

/** Quizzes hub for the selected category: Name, Letter, Urdu and Odd-one-out. */
@Composable
fun QuizzesScreen(category: Category, onBack: () -> Unit) {
    val accent = Color(0xFFDCE775)
    val speaker = rememberSpeaker()
    val items = remember(category) { gameItems(category) }
    var tab by remember { mutableStateOf(0) }

    ScreenScaffold("Quizzes ${category.emoji}", accent, onBack) {
        if (items.size < 8) {
            ComingSoon(accent, category)
            return@ScreenScaffold
        }
        TabsBar(listOf("Name", "Letter", "اردو", "Odd one"), tab, accent) { tab = it }
        Spacer(Modifier.height(10.dp))
        when (tab) {
            0 -> QuizView(accent, speaker) {
                items.shuffled().take(5).map { g ->
                    val (opts, correct) = buildChoices(g, items)
                    Question(
                        prompt = "What is this?",
                        big = "",
                        options = opts.map { Option(it.en) },
                        correct = correct,
                        say = g.en,
                        photo = g.photo
                    )
                }
            }
            1 -> {
                val letters = remember(category) { englishAlphabetFor(category).filter { it.photo != null } }
                QuizView(accent, speaker) {
                    letters.shuffled().take(5).map { l ->
                        val (opts, correct) = buildChoices(l.letter, letters.map { it.letter })
                        Question(
                            prompt = "Which letter does it start with?",
                            big = "",
                            options = opts.map { Option(it.toString()) },
                            correct = correct,
                            say = l.word,
                            photo = l.photo
                        )
                    }
                }
            }
            2 -> {
                val urdu = remember(items) { items.filter { it.ur.isNotBlank() } }
                QuizView(accent, speaker) {
                    urdu.shuffled().take(5).map { g ->
                        val (opts, correct) = buildChoices(g, urdu)
                        Question(
                            prompt = "یہ کیا ہے؟",
                            big = "",
                            options = opts.map { Option(it.ur) },
                            correct = correct,
                            say = g.ur,
                            sayLocale = UrduLocale,
                            photo = g.photo
                        )
                    }
                }
            }
            else -> OddOneOutGame(accent)
        }
    }
}

// ======================= ODD ONE OUT =======================

private data class OddRound(val pics: List<GameItem>, val oddIndex: Int)

/** Two pictures from one category and one from another: tap the one that does not belong. */
@Composable
private fun OddOneOutGame(accent: Color) {
    val ctx = LocalContext.current
    val speaker = rememberSpeaker()
    val scope = rememberCoroutineScope()
    val pools = remember {
        Category.entries.map { gameItems(it) }.filter { it.size >= 8 }
    }
    var round by remember { mutableStateOf(0) }
    var index by remember(round) { mutableStateOf(0) }
    var score by remember(round) { mutableStateOf(0) }
    val rounds = remember(round) {
        List(5) {
            val two = pools.shuffled().take(2)
            val same = two[0].shuffled().take(2)
            val odd = two[1].random()
            val all = (same + odd).shuffled()
            OddRound(all, all.indexOf(odd))
        }
    }
    var missed by remember(round, index) { mutableStateOf(false) }
    var message by remember(round, index) { mutableStateOf("") }
    var locked by remember(round, index) { mutableStateOf(false) }

    if (index >= rounds.size) {
        LaunchedEffect(round) { Rewards.add(ctx, score) }
        Column(
            Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("🎉", fontSize = 80.sp)
            Text("Well done!", fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Text("$score / ${rounds.size}  ⭐", fontSize = 32.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(20.dp))
            Button(
                onClick = { round++ },
                modifier = Modifier
                    .fillMaxWidth(0.7f)
                    .height(64.dp)
            ) { Text("Play again", fontSize = 20.sp) }
        }
        return
    }

    val r = rounds[index]
    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Question ${index + 1} / ${rounds.size}", fontSize = 14.sp, color = Color.Gray)
        Spacer(Modifier.height(6.dp))
        Text("Which one is different?", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            r.pics.forEachIndexed { i, g ->
                Card(
                    onClick = {
                        if (locked) return@Card
                        speaker.say(g.en)
                        if (i == r.oddIndex) {
                            locked = true
                            if (!missed) score++
                            message = "🌟 Great!"
                            scope.launch {
                                delay(900)
                                index++
                            }
                        } else {
                            missed = true
                            message = "Try again 🙂"
                        }
                    },
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(3.dp, accent),
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        PhotoImage(g.photo, Modifier.fillMaxWidth(0.6f))
                    }
                }
            }
        }
        Text(message, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.height(40.dp))
    }
}
