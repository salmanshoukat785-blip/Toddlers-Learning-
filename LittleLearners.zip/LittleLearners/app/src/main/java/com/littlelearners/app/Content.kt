package com.littlelearners.app

import androidx.compose.ui.graphics.Color

/** Emojis used for counting, per category. */
val Category.items: List<String>
    get() = when (this) {
        Category.ANIMALS -> listOf("🐶", "🐱", "🐰", "🐸", "🐘")
        Category.VEGETABLES -> listOf("🥕", "🌽", "🍅", "🥦")
        Category.FRUITS -> listOf("🍎", "🍌", "🍇", "🍓", "🍊")
        Category.THINGS -> listOf("⚽", "🧸", "🎈", "🚗")
        Category.NATURE -> listOf("🌳", "🌸", "⭐", "🌻")
        Category.COLORS -> listOf("🔴", "🟢", "🔵", "🟡")
    }

// ---------- Numbers ----------

val numberWordsEn = listOf(
    "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten",
    "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen",
    "Eighteen", "Nineteen", "Twenty"
)

val numberWordsUr = listOf(
    "", "ایک", "دو", "تین", "چار", "پانچ", "چھ", "سات", "آٹھ", "نو", "دس",
    "گیارہ", "بارہ", "تیرہ", "چودہ", "پندرہ", "سولہ", "سترہ", "اٹھارہ", "انیس", "بیس"
)

fun Int.toUrduDigits(): String =
    toString().map { if (it in '0'..'9') '۰' + (it - '0') else it }.joinToString("")

/** Objects per row and emoji size (sp) so counted objects stay BIG for any amount. */
fun countLayout(n: Int): Pair<Int, Int> = when {
    n == 1 -> 1 to 170
    n == 2 -> 2 to 120
    n == 3 -> 3 to 80
    n <= 6 -> 3 to 76
    n <= 10 -> 4 to 54
    n <= 15 -> 5 to 42
    else -> 5 to 36
}

// ---------- English alphabet ----------

data class LetterItem(
    val letter: Char,
    val word: String,
    val emoji: String,
    val urdu: String = "",
    val photo: String? = null,      // drawable name of the full flashcard
    val quizPhoto: String? = null   // same card with the letter and name hidden
)

val englishAlphabet = listOf(
    LetterItem('A', "Apple", "🍎"), LetterItem('B', "Ball", "⚽"),
    LetterItem('C', "Cat", "🐱"), LetterItem('D', "Dog", "🐶"),
    LetterItem('E', "Elephant", "🐘"), LetterItem('F', "Fish", "🐟"),
    LetterItem('G', "Grapes", "🍇"), LetterItem('H', "Hat", "👒"),
    LetterItem('I', "Ice cream", "🍦"), LetterItem('J', "Juice", "🍹"),
    LetterItem('K', "Key", "🔑"), LetterItem('L', "Lion", "🦁"),
    LetterItem('M', "Moon", "🌙"), LetterItem('N', "Nose", "👃"),
    LetterItem('O', "Orange", "🍊"), LetterItem('P', "Pig", "🐷"),
    LetterItem('Q', "Queen", "👑"), LetterItem('R', "Rabbit", "🐰"),
    LetterItem('S', "Sun", "☀️"), LetterItem('T', "Tree", "🌳"),
    LetterItem('U', "Umbrella", "☂️"), LetterItem('V', "Van", "🚐"),
    LetterItem('W', "Watch", "⌚"), LetterItem('X', "Xylophone", "🎹"),
    LetterItem('Y', "Yacht", "⛵"), LetterItem('Z', "Zebra", "🦓")
)

// ---------- Urdu alphabet ----------

data class UrduLetter(
    val letter: String,
    val name: String,
    val word: String,
    val meaning: String,
    val emoji: String,
    val photo: String? = null       // drawable name of the animal photo
) {
    /** The card exists in the book but the letter has no common animal. */
    val none: Boolean get() = meaning == "No common animal"
}

/** All 40 Urdu letters with their names (words come from the category data). */
val urduAlphabet = listOf(
    UrduLetter("ا", "الف", "", "", ""),
    UrduLetter("آ", "آ", "", "", ""),
    UrduLetter("ب", "بے", "", "", ""),
    UrduLetter("پ", "پے", "", "", ""),
    UrduLetter("ت", "تے", "", "", ""),
    UrduLetter("ٹ", "ٹے", "", "", ""),
    UrduLetter("ث", "ثے", "", "", ""),
    UrduLetter("ج", "جیم", "", "", ""),
    UrduLetter("چ", "چے", "", "", ""),
    UrduLetter("ح", "بڑی حے", "", "", ""),
    UrduLetter("خ", "خے", "", "", ""),
    UrduLetter("د", "دال", "", "", ""),
    UrduLetter("ڈ", "ڈال", "", "", ""),
    UrduLetter("ذ", "ذال", "", "", ""),
    UrduLetter("ر", "رے", "", "", ""),
    UrduLetter("ڑ", "ڑے", "", "", ""),
    UrduLetter("ز", "زے", "", "", ""),
    UrduLetter("ژ", "ژے", "", "", ""),
    UrduLetter("س", "سین", "", "", ""),
    UrduLetter("ش", "شین", "", "", ""),
    UrduLetter("ص", "صاد", "", "", ""),
    UrduLetter("ض", "ضاد", "", "", ""),
    UrduLetter("ط", "طوئے", "", "", ""),
    UrduLetter("ظ", "ظوئے", "", "", ""),
    UrduLetter("ع", "عین", "", "", ""),
    UrduLetter("غ", "غین", "", "", ""),
    UrduLetter("ف", "فے", "", "", ""),
    UrduLetter("ق", "قاف", "", "", ""),
    UrduLetter("ک", "کاف", "", "", ""),
    UrduLetter("گ", "گاف", "", "", ""),
    UrduLetter("ل", "لام", "", "", ""),
    UrduLetter("م", "میم", "", "", ""),
    UrduLetter("ن", "نون", "", "", ""),
    UrduLetter("ں", "نون غنہ", "", "", ""),
    UrduLetter("و", "واؤ", "", "", ""),
    UrduLetter("ہ", "ہے", "", "", ""),
    UrduLetter("ھ", "دو چشمی ہے", "", "", ""),
    UrduLetter("ء", "ہمزہ", "", "", ""),
    UrduLetter("ی", "چھوٹی یے", "", "", ""),
    UrduLetter("ے", "بڑی یے", "", "", "")
)

// ---------- Colors ----------

data class NamedColor(val en: String, val ur: String, val color: Color, val emoji: String = "")

val RedC = NamedColor("Red", "لال", Color(0xFFE53935), "🍎")
val BlueC = NamedColor("Blue", "نیلا", Color(0xFF1E88E5), "🐳")
val YellowC = NamedColor("Yellow", "پیلا", Color(0xFFFDD835), "🍌")
val GreenC = NamedColor("Green", "ہرا", Color(0xFF43A047), "🐸")
val OrangeC = NamedColor("Orange", "نارنجی", Color(0xFFFB8C00), "🍊")
val PurpleC = NamedColor("Purple", "جامنی", Color(0xFF8E24AA), "🍇")
val PinkC = NamedColor("Pink", "گلابی", Color(0xFFF48FB1), "🌸")
val BlackC = NamedColor("Black", "کالا", Color(0xFF212121), "🎩")
val WhiteC = NamedColor("White", "سفید", Color(0xFFFFFFFF), "☁️")
val BrownC = NamedColor("Brown", "بھورا", Color(0xFF795548), "🐻")
val LightBlueC = NamedColor("Light Blue", "ہلکا نیلا", Color(0xFF90CAF9))
val GreyC = NamedColor("Grey", "سلیٹی", Color(0xFF9E9E9E))

val learnColors = listOf(RedC, BlueC, YellowC, GreenC, OrangeC, PurpleC, PinkC, BlackC, WhiteC, BrownC)

val mixPalette = listOf(RedC, BlueC, YellowC, WhiteC, BlackC)

/** Key is the two colors' English names, sorted. */
val mixResults: Map<Set<String>, NamedColor> = mapOf(
    setOf("Red", "Yellow") to OrangeC,
    setOf("Blue", "Yellow") to GreenC,
    setOf("Red", "Blue") to PurpleC,
    setOf("Red", "White") to PinkC,
    setOf("Blue", "White") to LightBlueC,
    setOf("Black", "White") to GreyC
)

// ---------- Category-specific alphabets ----------
// Letter|Word|Emoji. Letters a category has no good word for fall back to the general list.

private fun parseEnglish(lines: List<String>): Map<Char, Pair<String, String>> =
    lines.associate { line ->
        val p = line.split("|")
        p[0][0] to (p[1] to p[2])
    }

private val englishOverrides: Map<Category, Map<Char, Pair<String, String>>> = mapOf(
    Category.ANIMALS to parseEnglish(listOf(
        "A|Ant|🐜", "B|Bear|🐻", "C|Cat|🐱", "D|Dog|🐶", "E|Elephant|🐘", "F|Fish|🐟",
        "G|Giraffe|🦒", "H|Horse|🐴", "I|Iguana|🦎", "J|Jaguar|🐆", "K|Kangaroo|🦘",
        "L|Lion|🦁", "M|Monkey|🐒", "N|Nightingale|🐦", "O|Owl|🦉", "P|Panda|🐼",
        "Q|Quail|🐦", "R|Rabbit|🐰", "S|Snake|🐍", "T|Tiger|🐯", "U|Unicorn|🦄",
        "V|Vulture|🦅", "W|Whale|🐳", "X|X-ray fish|🐠", "Y|Yak|🐂", "Z|Zebra|🦓"
    )),
    Category.FRUITS to parseEnglish(listOf(
        "A|Apple|🍎", "B|Banana|🍌", "C|Cherry|🍒", "G|Grapes|🍇", "H|Honeydew melon|🍈",
        "K|Kiwi|🥝", "L|Lemon|🍋", "M|Mango|🥭", "N|Nectarine|🍑", "O|Orange|🍊",
        "P|Pineapple|🍍", "R|Raspberry|🍓", "S|Strawberry|🍓", "T|Tangerine|🍊", "W|Watermelon|🍉"
    )),
    Category.VEGETABLES to parseEnglish(listOf(
        "A|Avocado|🥑", "B|Broccoli|🥦", "C|Carrot|🥕", "E|Eggplant|🍆", "G|Garlic|🧄",
        "H|Hot pepper|🌶️", "J|Jalapeno|🌶️", "K|Kale|🥬", "L|Lettuce|🥬", "M|Mushroom|🍄",
        "O|Onion|🧅", "P|Potato|🥔", "S|Sweet potato|🍠", "T|Tomato|🍅", "Y|Yam|🍠", "Z|Zucchini|🥒"
    )),
    Category.THINGS to parseEnglish(listOf(
        "A|Airplane|✈️", "B|Balloon|🎈", "C|Car|🚗", "D|Drum|🥁", "E|Envelope|✉️", "F|Flag|🚩",
        "G|Guitar|🎸", "H|House|🏠", "J|Jeep|🚙", "K|Key|🔑", "L|Lamp|💡", "M|Magnet|🧲",
        "N|Notebook|📓", "P|Phone|📱", "R|Robot|🤖", "S|Shoe|👟", "T|Train|🚂",
        "U|Umbrella|☂️", "V|Van|🚐", "W|Watch|⌚"
    )),
    Category.NATURE to parseEnglish(listOf(
        "A|Autumn leaf|🍂", "B|Bee|🐝", "C|Cloud|☁️", "D|Desert|🏜️", "E|Earth|🌍", "F|Flower|🌸",
        "G|Grass|🌿", "H|Hill|⛰️", "I|Ice|🧊", "L|Leaf|🍃", "M|Moon|🌙", "N|Night|🌃",
        "O|Ocean|🌊", "P|Palm tree|🌴", "R|Rainbow|🌈", "S|Sun|☀️", "T|Tree|🌳",
        "V|Volcano|🌋", "W|Water|💧"
    )),
    Category.COLORS to parseEnglish(listOf(
        "B|Blue|🔵", "G|Green|🟢", "O|Orange|🟠", "P|Purple|🟣", "R|Red|🔴", "W|White|⚪", "Y|Yellow|🟡"
    ))
)

fun englishAlphabetFor(category: Category): List<LetterItem> {
    if (category == Category.ANIMALS) return animalLetters
    // Other categories: only letters that have a word in THIS category (nothing borrowed from elsewhere).
    val o = englishOverrides[category].orEmpty()
    return englishAlphabet.mapNotNull { base ->
        o[base.letter]?.let { LetterItem(base.letter, it.first, it.second) }
    }
}

// Urdu: Letter|Word|English meaning|Emoji
private fun parseUrdu(lines: List<String>): Map<String, Triple<String, String, String>> =
    lines.associate { line ->
        val p = line.split("|")
        p[0] to Triple(p[1], p[2], p[3])
    }

private val urduOverrides: Map<Category, Map<String, Triple<String, String, String>>> = mapOf(
    Category.ANIMALS to parseUrdu(listOf(
        "ا|اونٹ|Camel|🐪", "ب|بطخ|Duck|🦆", "پ|پانڈا|Panda|🐼", "ت|تتلی|Butterfly|🦋",
        "ٹ|ٹڈا|Grasshopper|🦗", "چ|چوہا|Mouse|🐭", "ح|حلزون|Snail|🐌", "خ|خرگوش|Rabbit|🐰",
        "د|دلفین|Dolphin|🐬", "ڈ|ڈائنوسار|Dinosaur|🦖", "ر|ریچھ|Bear|🐻", "ز|زرافہ|Giraffe|🦒",
        "س|سانپ|Snake|🐍", "ش|شیر|Lion|🦁", "ض|ضفدع|Frog|🐸", "ط|طوطا|Parrot|🦜",
        "ع|عقاب|Eagle|🦅", "ف|فیل|Elephant|🐘", "ک|کتا|Dog|🐶", "گ|گائے|Cow|🐄",
        "ل|لومڑی|Fox|🦊", "م|مچھلی|Fish|🐟", "ن|نہنگ|Whale|🐋", "ہ|ہرن|Deer|🦌", "ی|یاک|Yak|🐂"
    )),
    Category.FRUITS to parseUrdu(listOf(
        "ا|انگور|Grapes|🍇", "پ|پائن ایپل|Pineapple|🍍", "ت|تربوز|Watermelon|🍉",
        "چ|چیری|Cherry|🍒", "خ|خربوزہ|Melon|🍈", "س|سیب|Apple|🍎", "ک|کیلا|Banana|🍌",
        "ل|لیموں|Lemon|🍋", "م|مالٹا|Orange|🍊", "ن|ناشپاتی|Pear|🍐"
    )),
    Category.VEGETABLES to parseUrdu(listOf(
        "پ|پیاز|Onion|🧅", "ٹ|ٹماٹر|Tomato|🍅", "گ|گاجر|Carrot|🥕", "م|مکئی|Corn|🌽",
        "ب|بینگن|Eggplant|🍆", "ل|لہسن|Garlic|🧄", "ش|شملہ مرچ|Bell pepper|🫑",
        "ک|کھیرا|Cucumber|🥒", "س|سلاد|Lettuce|🥬", "ہ|ہری مرچ|Green chili|🌶️"
    )),
    Category.THINGS to parseUrdu(listOf(
        "ا|انگوٹھی|Ring|💍", "ب|بلب|Bulb|💡", "ٹ|ٹرین|Train|🚂", "پ|پنسل|Pencil|✏️",
        "ت|تالا|Lock|🔒", "ج|جوتا|Shoe|👟", "چ|چابی|Key|🔑", "خ|خیمہ|Tent|⛺",
        "د|دروازہ|Door|🚪", "ڈ|ڈرم|Drum|🥁", "ر|روبوٹ|Robot|🤖", "س|سائیکل|Bicycle|🚲",
        "ع|عینک|Glasses|👓", "غ|غبارہ|Balloon|🎈", "ف|فون|Phone|📱", "ق|قلم|Pen|🖊️",
        "ک|کتاب|Book|📖", "گ|گھڑی|Watch|⌚", "ل|لیپ ٹاپ|Laptop|💻", "م|موم بتی|Candle|🕯️",
        "ن|نقشہ|Map|🗺️", "و|ویگن|Van|🚐", "ہ|ہتھوڑا|Hammer|🔨"
    )),
    Category.NATURE to parseUrdu(listOf(
        "ب|بادل|Cloud|☁️", "پ|پھول|Flower|🌸", "ت|تارا|Star|⭐", "ج|جنگل|Forest|🌲",
        "چ|چاند|Moon|🌙", "د|درخت|Tree|🌳", "ر|رات|Night|🌃", "ز|زمین|Earth|🌍",
        "س|سورج|Sun|☀️", "ش|شبنم|Dew|💧", "ص|صحرا|Desert|🏜️", "ط|طوفان|Tornado|🌪️",
        "ق|قوس قزح|Rainbow|🌈", "گ|گھاس|Grass|🌿", "ک|کوہ|Mountain|🏔️", "ہ|ہوا|Wind|💨"
    )),
    Category.COLORS to parseUrdu(listOf(
        "ل|لال|Red|🔴", "ن|نیلا|Blue|🔵", "پ|پیلا|Yellow|🟡", "ہ|ہرا|Green|🟢",
        "ک|کالا|Black|⚫", "س|سفید|White|⚪", "ج|جامنی|Purple|🟣", "ب|بھورا|Brown|🟤",
        "گ|گلابی|Pink|🌸"
    ))
)

fun urduAlphabetFor(category: Category): List<UrduLetter> {
    if (category == Category.ANIMALS) return animalUrdu
    val o = urduOverrides[category].orEmpty()
    return urduAlphabet.mapNotNull { base ->
        o[base.letter]?.let { UrduLetter(base.letter, base.name, it.first, it.second, it.third) }
    }
}

// ---------- ANIMALS: data taken from the supplied PDFs ----------

/** "A to Z Animals" flashcards. */
val animalLetters: List<LetterItem> = listOf(
    "A|Alligator|ایلیگیٹر", "B|Bear|ریچھ", "C|Camel|اونٹ", "D|Donkey|گدھا", "E|Elephant|ہاتھی",
    "F|Fox|لومڑی", "G|Giraffe|زرافہ", "H|Horse|گھوڑا", "I|Iguana|اگوانا", "J|Jaguar|جگوار",
    "K|Kangaroo|کینگرو", "L|Lion|شیر", "M|Monkey|بندر", "N|Narwhal|ناروال", "O|Owl|الو",
    "P|Panda|پانڈا", "Q|Quail|بٹیر", "R|Raccoon|راکون", "S|Squirrel|گلہری", "T|Tiger|ببر",
    "U|Unicorn|یونیکورن", "V|Vulture|گدھ", "W|Wolf|بھیڑیا", "X|Xerus|زیرس", "Y|Yak|یاک", "Z|Zebra|زیبرا"
).map { line ->
    val p = line.split("|")
    val l = p[0][0]
    LetterItem(l, p[1], "", p[2], "abc_${l.lowercaseChar()}", "abcq_${l.lowercaseChar()}")
}

/** "Urdu Animals: Alif to Ye" cards. Fields: letter|name|word|English|photo|emoji (used only when no photo exists). */
val animalUrdu: List<UrduLetter> = listOf(
    "ا|الف|اژدہا|Dragon|ur_01|", "آ|آ|آکٹوپس|Octopus||🐙", "ب|بے|بکری|Goat|ur_03|",
    "پ|پے|پانڈا|Panda|ur_04|", "ت|تے|تیتر|Partridge|ur_05|", "ٹ|ٹے|ٹٹو|Pony|ur_06|",
    "ث|ثے||No common animal||", "ج|جیم|جگوار|Jaguar|ur_08|", "چ|چے|چیتا|Cheetah|ur_09|",
    "ح|بڑی حے|حشرات|Insects||🐛", "خ|خے|خرگوش|Rabbit|ur_11|", "د|دال|دنبہ|Ram||🐏",
    "ڈ|ڈال|ڈولفن|Dolphin||🐬", "ذ|ذال||No common animal||", "ر|رے|ریچھ|Bear|ur_15|",
    "ڑ|ڑے||No common animal||", "ز|زے|زیبرا|Zebra|ur_17|", "ژ|ژے||No common animal||",
    "س|سین|سانپ|Snake|ur_19|", "ش|شین|شیر|Lion|ur_20|", "ص|صاد|صدف|Shellfish||🐚",
    "ض|ضاد||No common animal||", "ط|طوئے|طوطا|Parrot||🦜", "ظ|ظوئے||No common animal||",
    "ع|عین|عقاب|Eagle|ur_25|", "غ|غین|غزال|Gazelle||", "ف|فے|فاختہ|Dove||🕊️",
    "ق|قاف|قاقم|Ermine||", "ک|کاف|کبوتر|Pigeon||", "گ|گاف|گدھا|Donkey|ur_30|",
    "ل|لام|لومڑی|Fox|ur_31|", "م|میم|مور|Peacock|ur_32|", "ن|نون|نیولا|Mongoose||",
    "ں|نون غنہ||No common animal||", "و|واؤ|وہیل|Whale||🐋", "ہ|ہے|ہاتھی|Elephant|ur_36|",
    "ھ|دو چشمی ہے||No common animal||", "ء|ہمزہ||No common animal||", "ی|چھوٹی یے|یاک|Yak||🐂",
    "ے|بڑی یے||No common animal||"
).map { line ->
    val p = line.split("|")
    UrduLetter(p[0], p[1], p[2], p[3], p[5], p[4].ifBlank { null })
}

/** "Animals Flashcards: Numbers 1-20": number N is shown with the Nth animal. */
class NumberAnimal(val en: String, val ur: String, val photo: String)

val animalNumbers: List<NumberAnimal> = listOf(
    "Lion|شیر", "Tiger|باگھ", "Elephant|ہاتھی", "Leopard|چیتا", "Zebra|زیبرا",
    "Giraffe|زرافہ", "Cow|گائے", "Buffalo|بھینس", "Goat|بکری", "Sheep|بھیڑ",
    "Horse|گھوڑا", "Donkey|گدھا", "Camel|اونٹ", "Kangaroo|کینگرو", "Panda|پانڈا",
    "Bear|ریچھ", "Wolf|بھیڑیا", "Fox|لومڑی", "Squirrel|گلہری", "Raccoon|راکون"
).mapIndexed { i, line ->
    val p = line.split("|")
    NumberAnimal(p[0], p[1], "num_%02d".format(i + 1))
}
