package com.littlelearners.app

import androidx.compose.ui.graphics.Color

/** Emojis used for counting, per category. */
val Category.items: List<String>
    get() = when (this) {
        Category.ANIMALS -> listOf("🐶", "🐱", "🐰", "🐸", "🐘")
        Category.VEGETABLES -> listOf("🥕", "🌽", "🍅", "🥦")
        Category.FRUITS -> listOf("🍎", "🍌", "🍇", "🍓", "🍊")
        Category.THINGS -> listOf("⚽", "🧸", "🎈", "🚗")
        Category.NATURE -> listOf("🌳", "🌸", "⭐", "🌻")
        Category.COLORS -> listOf("🔴", "🟢", "🔵", "🟡")
    }

// ---------- Numbers ----------

val numberWordsEn = listOf(
    "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten",
    "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen",
    "Eighteen", "Nineteen", "Twenty"
)

val numberWordsUr = listOf(
    "", "ایک", "دو", "تین", "چار", "پانچ", "چھ", "سات", "آٹھ", "نو", "دس",
    "گیارہ", "بارہ", "تیرہ", "چودہ", "پندرہ", "سولہ", "سترہ", "اٹھارہ", "انیس", "بیس"
)

fun Int.toUrduDigits(): String =
    toString().map { if (it in '0'..'9') '۰' + (it - '0') else it }.joinToString("")

/** Objects per row and emoji size (sp) so counted objects stay BIG for any amount. */
fun countLayout(n: Int): Pair<Int, Int> = when {
    n == 1 -> 1 to 170
    n == 2 -> 2 to 120
    n == 3 -> 3 to 80
    n <= 6 -> 3 to 76
    n <= 10 -> 4 to 54
    n <= 15 -> 5 to 42
    else -> 5 to 36
}

// ---------- English alphabet ----------

data class LetterItem(val letter: Char, val word: String, val emoji: String)

val englishAlphabet = listOf(
    LetterItem('A', "Apple", "🍎"), LetterItem('B', "Ball", "⚽"),
    LetterItem('C', "Cat", "🐱"), LetterItem('D', "Dog", "🐶"),
    LetterItem('E', "Elephant", "🐘"), LetterItem('F', "Fish", "🐟"),
    LetterItem('G', "Grapes", "🍇"), LetterItem('H', "Hat", "👒"),
    LetterItem('I', "Ice cream", "🍦"), LetterItem('J', "Juice", "🍹"),
    LetterItem('K', "Key", "🔑"), LetterItem('L', "Lion", "🦁"),
    LetterItem('M', "Moon", "🌙"), LetterItem('N', "Nose", "👃"),
    LetterItem('O', "Orange", "🍊"), LetterItem('P', "Pig", "🐷"),
    LetterItem('Q', "Queen", "👑"), LetterItem('R', "Rabbit", "🐰"),
    LetterItem('S', "Sun", "☀️"), LetterItem('T', "Tree", "🌳"),
    LetterItem('U', "Umbrella", "☂️"), LetterItem('V', "Van", "🚐"),
    LetterItem('W', "Watch", "⌚"), LetterItem('X', "Xylophone", "🎹"),
    LetterItem('Y', "Yacht", "⛵"), LetterItem('Z', "Zebra", "🦓")
)

// ---------- Urdu alphabet ----------

data class UrduLetter(
    val letter: String,
    val name: String,
    val word: String,
    val meaning: String,
    val emoji: String
)

val urduAlphabet = listOf(
    UrduLetter("ا", "الف", "انار", "Pomegranate", ""),
    UrduLetter("ب", "بے", "بطخ", "Duck", "🦆"),
    UrduLetter("پ", "پے", "پتنگ", "Kite", "🎏"),
    UrduLetter("ت", "تے", "تتلی", "Butterfly", "🦋"),
    UrduLetter("ٹ", "ٹے", "ٹوپی", "Cap", "👒"),
    UrduLetter("ث", "ثے", "ثمر", "Fruit", "🍎"),
    UrduLetter("ج", "جیم", "جہاز", "Airplane", "✈️"),
    UrduLetter("چ", "چے", "چڑیا", "Sparrow", "🐦"),
    UrduLetter("ح", "حے", "حلوہ", "Halwa", "🍮"),
    UrduLetter("خ", "خے", "خرگوش", "Rabbit", "🐰"),
    UrduLetter("د", "دال", "دوات", "Inkpot", ""),
    UrduLetter("ڈ", "ڈال", "ڈبہ", "Box", "📦"),
    UrduLetter("ذ", "ذال", "ذرہ", "Tiny particle", ""),
    UrduLetter("ر", "رے", "روٹی", "Bread", "🍞"),
    UrduLetter("ڑ", "ڑے", "پہاڑ", "Mountain", "⛰️"),
    UrduLetter("ز", "زے", "زیبرا", "Zebra", "🦓"),
    UrduLetter("ژ", "ژے", "ژالہ", "Hail", "🌨️"),
    UrduLetter("س", "سین", "سیب", "Apple", "🍎"),
    UrduLetter("ش", "شین", "شیر", "Lion", "🦁"),
    UrduLetter("ص", "صاد", "صابن", "Soap", "🛁"),
    UrduLetter("ض", "ضاد", "ضرب", "Multiply", ""),
    UrduLetter("ط", "طوئے", "طوطا", "Parrot", "🦜"),
    UrduLetter("ظ", "ظوئے", "ظرف", "Vessel", ""),
    UrduLetter("ع", "عین", "عینک", "Glasses", "👓"),
    UrduLetter("غ", "غین", "غبارہ", "Balloon", "🎈"),
    UrduLetter("ف", "فے", "فیل", "Elephant", "🐘"),
    UrduLetter("ق", "قاف", "قلم", "Pen", "🖊️"),
    UrduLetter("ک", "کاف", "کتا", "Dog", "🐶"),
    UrduLetter("گ", "گاف", "گائے", "Cow", "🐄"),
    UrduLetter("ل", "لام", "لڈو", "Laddu", ""),
    UrduLetter("م", "میم", "مچھلی", "Fish", "🐟"),
    UrduLetter("ن", "نون", "ناک", "Nose", "👃"),
    UrduLetter("و", "واؤ", "وزن", "Weight", "⚖️"),
    UrduLetter("ہ", "ہے", "ہاتھ", "Hand", "✋"),
    UrduLetter("ی", "یے", "یاقوت", "Ruby", "💎")
)

// ---------- Colors ----------

data class NamedColor(val en: String, val ur: String, val color: Color, val emoji: String = "")

val RedC = NamedColor("Red", "لال", Color(0xFFE53935), "🍎")
val BlueC = NamedColor("Blue", "نیلا", Color(0xFF1E88E5), "🐳")
val YellowC = NamedColor("Yellow", "پیلا", Color(0xFFFDD835), "🍌")
val GreenC = NamedColor("Green", "ہرا", Color(0xFF43A047), "🐸")
val OrangeC = NamedColor("Orange", "نارنجی", Color(0xFFFB8C00), "🍊")
val PurpleC = NamedColor("Purple", "جامنی", Color(0xFF8E24AA), "🍇")
val PinkC = NamedColor("Pink", "گلابی", Color(0xFFF48FB1), "🌸")
val BlackC = NamedColor("Black", "کالا", Color(0xFF212121), "🎩")
val WhiteC = NamedColor("White", "سفید", Color(0xFFFFFFFF), "☁️")
val BrownC = NamedColor("Brown", "بھورا", Color(0xFF795548), "🐻")
val LightBlueC = NamedColor("Light Blue", "ہلکا نیلا", Color(0xFF90CAF9))
val GreyC = NamedColor("Grey", "سلیٹی", Color(0xFF9E9E9E))

val learnColors = listOf(RedC, BlueC, YellowC, GreenC, OrangeC, PurpleC, PinkC, BlackC, WhiteC, BrownC)

val mixPalette = listOf(RedC, BlueC, YellowC, WhiteC, BlackC)

/** Key is the two colors' English names, sorted. */
val mixResults: Map<Set<String>, NamedColor> = mapOf(
    setOf("Red", "Yellow") to OrangeC,
    setOf("Blue", "Yellow") to GreenC,
    setOf("Red", "Blue") to PurpleC,
    setOf("Red", "White") to PinkC,
    setOf("Blue", "White") to LightBlueC,
    setOf("Black", "White") to GreyC
)
