package com.littlelearners.app

import androidx.compose.ui.graphics.Color

/** Emojis used for counting, per category. */
val Category.items: List<String>
    get() = when (this) {
        Category.ANIMALS -> listOf("🐶", "🐱", "🐰", "🐸", "🐘")
        Category.VEGETABLES -> listOf("🥕", "🌽", "🍅", "🥦")
        Category.FRUITS -> listOf("🍎", "🍌", "🍇", "🍓", "🍊")
        Category.INSECTS -> listOf("🐞", "🐝", "🦋", "🐜")
        Category.SEA -> listOf("🐠", "🐙", "🐬", "🦀")
        Category.BIRDS -> listOf("🐦", "🦜", "🦆", "🦉")
        Category.VEHICLES -> listOf("🚗", "🚌", "🚂", "✈️")
        Category.BODY -> listOf("👁️", "👂", "👃", "✋")
        Category.SHAPES -> listOf("🔴", "🟦", "🔺", "⭐")
        Category.WEATHER -> listOf("☀️", "🌧️", "❄️", "🌈")
        Category.THINGS -> listOf("⚽", "🧸", "🎈", "🚗")
        Category.NATURE -> listOf("🌳", "🌸", "⭐", "🌻")
        Category.COLORS -> listOf("🔴", "🟢", "🔵", "🟡")
    }

// ---------- Numbers ----------

val numberWordsEn = listOf(
    "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten",
    "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen",
    "Eighteen", "Nineteen", "Twenty"
)

val numberWordsUr = listOf(
    "", "ایک", "دو", "تین", "چار", "پانچ", "چھ", "سات", "آٹھ", "نو", "دس",
    "گیارہ", "بارہ", "تیرہ", "چودہ", "پندرہ", "سولہ", "سترہ", "اٹھارہ", "انیس", "بیس"
)

fun Int.toUrduDigits(): String =
    toString().map { if (it in '0'..'9') '۰' + (it - '0') else it }.joinToString("")

/** Objects per row and emoji size (sp) so counted objects stay BIG for any amount. */
fun countLayout(n: Int): Pair<Int, Int> = when {
    n == 1 -> 1 to 170
    n == 2 -> 2 to 120
    n == 3 -> 3 to 80
    n <= 6 -> 3 to 76
    n <= 10 -> 4 to 54
    n <= 15 -> 5 to 42
    else -> 5 to 36
}

// ---------- English alphabet ----------

data class LetterItem(
    val letter: Char,
    val word: String,
    val emoji: String,
    val urdu: String = "",
    val photo: String? = null,      // drawable name of the full flashcard
    val quizPhoto: String? = null,  // card with the letter/name hidden (or the plain photo)
    val plain: Boolean = false      // photo is a plain picture; the app draws the letter and names
)

val englishAlphabet = listOf(
    LetterItem('A', "Apple", "🍎"), LetterItem('B', "Ball", "⚽"),
    LetterItem('C', "Cat", "🐱"), LetterItem('D', "Dog", "🐶"),
    LetterItem('E', "Elephant", "🐘"), LetterItem('F', "Fish", "🐟"),
    LetterItem('G', "Grapes", "🍇"), LetterItem('H', "Hat", "👒"),
    LetterItem('I', "Ice cream", "🍦"), LetterItem('J', "Juice", "🍹"),
    LetterItem('K', "Key", "🔑"), LetterItem('L', "Lion", "🦁"),
    LetterItem('M', "Moon", "🌙"), LetterItem('N', "Nose", "👃"),
    LetterItem('O', "Orange", "🍊"), LetterItem('P', "Pig", "🐷"),
    LetterItem('Q', "Queen", "👑"), LetterItem('R', "Rabbit", "🐰"),
    LetterItem('S', "Sun", "☀️"), LetterItem('T', "Tree", "🌳"),
    LetterItem('U', "Umbrella", "☂️"), LetterItem('V', "Van", "🚐"),
    LetterItem('W', "Watch", "⌚"), LetterItem('X', "Xylophone", "🎹"),
    LetterItem('Y', "Yacht", "⛵"), LetterItem('Z', "Zebra", "🦓")
)

// ---------- Urdu alphabet ----------

data class UrduLetter(
    val letter: String,
    val name: String,
    val word: String,
    val meaning: String,
    val emoji: String,
    val photo: String? = null       // drawable name of the animal photo
) {
    /** The letter exists but has no common animal/fruit/... in this category. */
    val none: Boolean get() = meaning.startsWith("No common")
}

/** All 40 Urdu letters with their names (words come from the category data). */
val urduAlphabet = listOf(
    UrduLetter("ا", "الف", "", "", ""),
    UrduLetter("آ", "آ", "", "", ""),
    UrduLetter("ب", "بے", "", "", ""),
    UrduLetter("پ", "پے", "", "", ""),
    UrduLetter("ت", "تے", "", "", ""),
    UrduLetter("ٹ", "ٹے", "", "", ""),
    UrduLetter("ث", "ثے", "", "", ""),
    UrduLetter("ج", "جیم", "", "", ""),
    UrduLetter("چ", "چے", "", "", ""),
    UrduLetter("ح", "بڑی حے", "", "", ""),
    UrduLetter("خ", "خے", "", "", ""),
    UrduLetter("د", "دال", "", "", ""),
    UrduLetter("ڈ", "ڈال", "", "", ""),
    UrduLetter("ذ", "ذال", "", "", ""),
    UrduLetter("ر", "رے", "", "", ""),
    UrduLetter("ڑ", "ڑے", "", "", ""),
    UrduLetter("ز", "زے", "", "", ""),
    UrduLetter("ژ", "ژے", "", "", ""),
    UrduLetter("س", "سین", "", "", ""),
    UrduLetter("ش", "شین", "", "", ""),
    UrduLetter("ص", "صاد", "", "", ""),
    UrduLetter("ض", "ضاد", "", "", ""),
    UrduLetter("ط", "طوئے", "", "", ""),
    UrduLetter("ظ", "ظوئے", "", "", ""),
    UrduLetter("ع", "عین", "", "", ""),
    UrduLetter("غ", "غین", "", "", ""),
    UrduLetter("ف", "فے", "", "", ""),
    UrduLetter("ق", "قاف", "", "", ""),
    UrduLetter("ک", "کاف", "", "", ""),
    UrduLetter("گ", "گاف", "", "", ""),
    UrduLetter("ل", "لام", "", "", ""),
    UrduLetter("م", "میم", "", "", ""),
    UrduLetter("ن", "نون", "", "", ""),
    UrduLetter("ں", "نون غنہ", "", "", ""),
    UrduLetter("و", "واؤ", "", "", ""),
    UrduLetter("ہ", "ہے", "", "", ""),
    UrduLetter("ھ", "دو چشمی ہے", "", "", ""),
    UrduLetter("ء", "ہمزہ", "", "", ""),
    UrduLetter("ی", "چھوٹی یے", "", "", ""),
    UrduLetter("ے", "بڑی یے", "", "", "")
)

// ---------- Colors ----------

data class NamedColor(val en: String, val ur: String, val color: Color, val emoji: String = "")

val RedC = NamedColor("Red", "لال", Color(0xFFE53935), "🍎")
val BlueC = NamedColor("Blue", "نیلا", Color(0xFF1E88E5), "🐳")
val YellowC = NamedColor("Yellow", "پیلا", Color(0xFFFDD835), "🍌")
val GreenC = NamedColor("Green", "ہرا", Color(0xFF43A047), "🐸")
val OrangeC = NamedColor("Orange", "نارنجی", Color(0xFFFB8C00), "🍊")
val PurpleC = NamedColor("Purple", "جامنی", Color(0xFF8E24AA), "🍇")
val PinkC = NamedColor("Pink", "گلابی", Color(0xFFF48FB1), "🌸")
val BlackC = NamedColor("Black", "کالا", Color(0xFF212121), "🎩")
val WhiteC = NamedColor("White", "سفید", Color(0xFFFFFFFF), "☁️")
val BrownC = NamedColor("Brown", "بھورا", Color(0xFF795548), "🐻")
val LightBlueC = NamedColor("Light Blue", "ہلکا نیلا", Color(0xFF90CAF9))
val GreyC = NamedColor("Grey", "سلیٹی", Color(0xFF9E9E9E))

val learnColors = listOf(RedC, BlueC, YellowC, GreenC, OrangeC, PurpleC, PinkC, BlackC, WhiteC, BrownC)

val mixPalette = listOf(RedC, BlueC, YellowC, WhiteC, BlackC)

/** Key is the two colors' English names, sorted. */
val mixResults: Map<Set<String>, NamedColor> = mapOf(
    setOf("Red", "Yellow") to OrangeC,
    setOf("Blue", "Yellow") to GreenC,
    setOf("Red", "Blue") to PurpleC,
    setOf("Red", "White") to PinkC,
    setOf("Blue", "White") to LightBlueC,
    setOf("Black", "White") to GreyC
)

// ---------- Category alphabets ----------
// Only the Animals category has content so far (from the supplied PDFs).
// Other categories stay empty ("coming soon") until their pictures are added: nothing is borrowed.

fun englishAlphabetFor(category: Category): List<LetterItem> = when (category) {
    Category.ANIMALS -> animalLetters
    Category.FRUITS -> fruitLetters
    Category.VEGETABLES -> vegLetters
    Category.THINGS -> thingLetters
    Category.NATURE -> natureLetters
    Category.INSECTS -> insectLetters
    Category.SEA -> seaLetters
    Category.BIRDS -> birdLetters
    Category.VEHICLES -> vehicleLetters
    Category.BODY -> bodyLetters
    Category.SHAPES -> shapeLetters
    Category.WEATHER -> weatherLetters
    Category.COLORS -> colorLetters
    else -> emptyList()
}

fun urduAlphabetFor(category: Category): List<UrduLetter> = when (category) {
    Category.ANIMALS -> animalUrdu
    Category.FRUITS -> fruitUrdu
    Category.VEGETABLES -> vegUrdu
    Category.THINGS -> thingUrdu
    Category.NATURE -> natureUrdu
    Category.INSECTS -> insectUrdu
    Category.SEA -> seaUrdu
    Category.BIRDS -> birdUrdu
    Category.VEHICLES -> vehicleUrdu
    Category.BODY -> bodyUrdu
    Category.SHAPES -> shapeUrdu
    Category.WEATHER -> weatherUrdu
    Category.COLORS -> colorUrdu
    else -> emptyList()
}

/** Numbers 1-20 pictures for a category, or null while that category has no pictures yet. */
fun numberItemsFor(category: Category): List<NumberItem>? = when (category) {
    Category.ANIMALS -> animalNumbers
    Category.FRUITS -> fruitNumbers
    Category.VEGETABLES -> vegNumbers
    Category.THINGS -> thingNumbers
    Category.NATURE -> natureNumbers
    Category.INSECTS -> insectNumbers
    Category.SEA -> seaNumbers
    Category.BIRDS -> birdNumbers
    Category.VEHICLES -> vehicleNumbers
    Category.BODY -> bodyNumbers
    Category.SHAPES -> shapeNumbers
    Category.WEATHER -> weatherNumbers
    Category.COLORS -> colorNumbers
    else -> null
}

/** Urdu text shown for a letter that has nothing in the category. */
val Category.noneUrdu: String
    get() = when (this) {
        Category.ANIMALS -> "اس حرف سے عام جانور نہیں"
        Category.FRUITS -> "اس حرف سے عام پھل نہیں"
        Category.VEGETABLES -> "اس حرف سے عام سبزی نہیں"
        Category.THINGS -> "اس حرف سے کوئی عام چیز نہیں"
        Category.NATURE -> "اس حرف سے قدرت کی کوئی عام چیز نہیں"
        Category.INSECTS -> "اس حرف سے کوئی عام کیڑا نہیں"
        Category.SEA -> "اس حرف سے کوئی عام سمندری جاندار نہیں"
        Category.BIRDS -> "اس حرف سے کوئی عام پرندہ نہیں"
        Category.VEHICLES -> "اس حرف سے کوئی عام گاڑی نہیں"
        Category.BODY -> "اس حرف سے جسم کا کوئی عام حصہ نہیں"
        Category.SHAPES -> "اس حرف سے کوئی عام شکل نہیں"
        Category.WEATHER -> "اس حرف سے موسم کی کوئی عام چیز نہیں"
        Category.COLORS -> "اس حرف سے کوئی عام رنگ نہیں"
        else -> "اس حرف سے کچھ نہیں"
    }

// ---------- ANIMALS: data taken from the supplied PDFs ----------

/** "A to Z Animals" flashcards. */
val animalLetters: List<LetterItem> = listOf(
    "A|Alligator|ایلیگیٹر|alligator", "B|Bear|ریچھ|bear", "C|Camel|اونٹ|camel", "D|Donkey|گدھا|donkey",
    "E|Elephant|ہاتھی|elephant", "F|Fox|لومڑی|fox", "G|Giraffe|زرافہ|giraffe", "H|Horse|گھوڑا|horse",
    "I|Iguana|اگوانا|iguana", "J|Jaguar|جگوار|jaguar", "K|Kangaroo|کینگرو|kangaroo", "L|Lion|شیر|lion",
    "M|Monkey|بندر|monkey", "N|Narwhal|ناروال|narwhal", "O|Owl|الو|owl", "P|Panda|پانڈا|panda",
    "Q|Quail|بٹیر|quail", "R|Raccoon|راکون|raccoon", "S|Squirrel|گلہری|squirrel", "T|Tiger|ببر|tiger",
    "U|Uakari monkey|اوکاری بندر|uakari", "V|Vulture|گدھ|vulture", "W|Wolf|بھیڑیا|wolf",
    "X|Xerus|زیرس|xerus", "Y|Yak|یاک|yak", "Z|Zebra|زیبرا|zebra"
).map { line ->
    val p = line.split("|")
    LetterItem(p[0][0], p[1], "", p[2], "an_${p[3]}", "an_${p[3]}", plain = true)
}

/** "Urdu Animals: Alif to Ye" cards. Fields: letter|name|word|English|photo|emoji (used only when no photo exists). */
val animalUrdu: List<UrduLetter> = listOf(
    "ا|الف|اژدہا|Komodo dragon|an_komodo|", "آ|آ|آکٹوپس|Octopus|an_octopus|", "ب|بے|بکری|Goat|an_goat|",
    "پ|پے|پانڈا|Panda|an_panda|", "ت|تے|تیتر|Partridge|an_partridge|", "ٹ|ٹے|ٹٹو|Pony|an_pony|",
    "ث|ثے||No common animal||", "ج|جیم|جگوار|Jaguar|an_jaguar|", "چ|چے|چیتا|Cheetah|an_cheetah|",
    "ح|بڑی حے|حشرات|Beetle (insect)|an_beetle|", "خ|خے|خرگوش|Rabbit|an_rabbit|", "د|دال|دنبہ|Ram|an_ram|",
    "ڈ|ڈال|ڈولفن|Dolphin|an_dolphin|", "ذ|ذال||No common animal||", "ر|رے|ریچھ|Bear|an_bear|",
    "ڑ|ڑے||No common animal||", "ز|زے|زیبرا|Zebra|an_zebra|", "ژ|ژے||No common animal||",
    "س|سین|سانپ|Snake|an_snake|", "ش|شین|شیر|Lion|an_lion|", "ص|صاد|صدف|Oyster|an_oyster|",
    "ض|ضاد||No common animal||", "ط|طوئے|طوطا|Parrot|an_parrot|", "ظ|ظوئے||No common animal||",
    "ع|عین|عقاب|Eagle|an_eagle|", "غ|غین|غزال|Gazelle|an_gazelle|", "ف|فے|فاختہ|Dove|an_dove|",
    "ق|قاف|قاقم|Ermine|an_ermine|", "ک|کاف|کبوتر|Pigeon|an_pigeon|", "گ|گاف|گدھا|Donkey|an_donkey|",
    "ل|لام|لومڑی|Fox|an_fox|", "م|میم|مور|Peacock|an_peacock|", "ن|نون|نیولا|Mongoose|an_mongoose|",
    "ں|نون غنہ||No common animal||", "و|واؤ|وہیل|Whale|an_whale|", "ہ|ہے|ہاتھی|Elephant|an_elephant|",
    "ھ|دو چشمی ہے||No common animal||", "ء|ہمزہ||No common animal||", "ی|چھوٹی یے|یاک|Yak|an_yak|",
    "ے|بڑی یے||No common animal||"
).map { line ->
    val p = line.split("|")
    UrduLetter(p[0], p[1], p[2], p[3], p[5], p[4].ifBlank { null })
}

/** "Animals Flashcards: Numbers 1-20": number N is shown with the Nth animal. */
class NumberItem(val en: String, val ur: String, val photo: String)

val animalNumbers: List<NumberItem> = listOf(
    "Lion|شیر|lion", "Tiger|باگھ|tiger", "Elephant|ہاتھی|elephant", "Leopard|چیتا|leopard", "Zebra|زیبرا|zebra",
    "Giraffe|زرافہ|giraffe", "Cow|گائے|cow", "Buffalo|بھینس|buffalo", "Goat|بکری|goat", "Sheep|بھیڑ|sheep",
    "Horse|گھوڑا|horse", "Donkey|گدھا|donkey", "Camel|اونٹ|camel", "Kangaroo|کینگرو|kangaroo", "Panda|پانڈا|panda",
    "Bear|ریچھ|bear", "Wolf|بھیڑیا|wolf", "Fox|لومڑی|fox", "Squirrel|گلہری|squirrel", "Raccoon|راکون|raccoon"
).mapIndexed { i, line ->
    val p = line.split("|")
    NumberItem(p[0], p[1], "an_${p[2]}")
}


// ---------- FRUITS: from the supplied fruit photo sheets ----------

/** Letter|Fruit|Urdu name|photo */
val fruitLetters: List<LetterItem> = listOf(
    "A|Apple|سیب|apple", "B|Banana|کیلا|banana", "C|Cherry|چیری|cherry", "D|Dates|کھجور|dates",
    "E|Elderberry|ایلڈر بیری|elderberry", "F|Fig|انجیر|fig", "G|Grapes|انگور|grapes",
    "H|Honeydew melon|ہنی ڈیو خربوزہ|honeydew", "I|Indian gooseberry|آملہ|amla",
    "J|Jackfruit|کٹھل|jackfruit", "K|Kiwi|کیوی|kiwi", "L|Lemon|لیموں|lemon", "M|Mango|آم|mango",
    "N|Nectarine|نیکٹرین|nectarine", "O|Orange|مالٹا|orange", "P|Pineapple|انناس|pineapple",
    "Q|Quince|بہی|quince", "R|Raspberry|رس بھری|raspberry", "S|Strawberry|سٹرابیری|strawberry",
    "T|Tangerine|ٹینجرین|tangerine", "U|Ugli fruit|اگلی فروٹ|ugli", "V|Velvet apple|مخملی سیب|velvetapple",
    "W|Watermelon|تربوز|watermelon", "X|Ximenia|زائمینیا|ximenia", "Y|Yuzu|یوزو|yuzu",
    "Z|Ziziphus (Ber)|بیر|ber"
).map { line ->
    val p = line.split("|")
    LetterItem(p[0][0], p[1], "", p[2], "fr_${p[3]}", "fr_${p[3]}", plain = true)
}

/** Urdu letter -> (word, English, photo). Letters not listed show "no common fruit". */
private val fruitUrduWords: Map<String, Triple<String, String, String>> = mapOf(
    "آ" to Triple("آم", "Mango", "fr_mango"),
    "ا" to Triple("انار", "Pomegranate", "fr_pomegranate"),
    "ب" to Triple("بیر", "Ber (Jujube)", "fr_ber"),
    "پ" to Triple("پپیتا", "Papaya", "fr_papaya"),
    "ت" to Triple("تربوز", "Watermelon", "fr_watermelon"),
    "ٹ" to Triple("ٹینجرین", "Tangerine", "fr_tangerine"),
    "ج" to Triple("جامن", "Jamun", "fr_jamun"),
    "چ" to Triple("چیکو", "Chikoo", "fr_chikoo"),
    "خ" to Triple("خوبانی", "Apricot", "fr_apricot"),
    "ڈ" to Triple("ڈریگن فروٹ", "Dragon fruit", "fr_dragonfruit"),
    "ر" to Triple("رس بھری", "Raspberry", "fr_raspberry"),
    "ز" to Triple("زیتون", "Olive", "fr_olive"),
    "س" to Triple("سیب", "Apple", "fr_apple"),
    "ش" to Triple("شہتوت", "Mulberry", "fr_mulberry"),
    "ف" to Triple("فالسہ", "Falsa", "fr_falsa"),
    "ک" to Triple("کیلا", "Banana", "fr_banana"),
    "گ" to Triple("گریپ فروٹ", "Grapefruit", "fr_grapefruit"),
    "ل" to Triple("لیموں", "Lemon", "fr_lemon"),
    "م" to Triple("مالٹا", "Orange", "fr_orange"),
    "ن" to Triple("ناشپاتی", "Pear", "fr_pear"),
    "ی" to Triple("یوسف افندی", "Mandarin", "fr_tangerine")
)

val fruitUrdu: List<UrduLetter> = urduAlphabet.map { base ->
    val w = fruitUrduWords[base.letter]
    if (w != null) UrduLetter(base.letter, base.name, w.first, w.second, "", w.third)
    else UrduLetter(base.letter, base.name, "", "No common fruit", "", null)
}

val fruitNumbers: List<NumberItem> = listOf(
    "Apple|سیب|apple", "Banana|کیلا|banana", "Orange|مالٹا|orange", "Mango|آم|mango",
    "Grapes|انگور|grapes", "Strawberry|سٹرابیری|strawberry", "Watermelon|تربوز|watermelon",
    "Pineapple|انناس|pineapple", "Cherry|چیری|cherry", "Pear|ناشپاتی|pear", "Peach|آڑو|peach",
    "Lemon|لیموں|lemon", "Kiwi|کیوی|kiwi", "Pomegranate|انار|pomegranate", "Papaya|پپیتا|papaya",
    "Coconut|ناریل|coconut", "Plum|آلو بخارا|plum", "Apricot|خوبانی|apricot", "Melon|خربوزہ|melon",
    "Guava|امرود|guava"
).map { line ->
    val p = line.split("|")
    NumberItem(p[0], p[1], "fr_${p[2]}")
}


// ---------- VEGETABLES: from the supplied vegetable photo sheets ----------

/** Letter|Vegetable|Urdu name|photo */
val vegLetters: List<LetterItem> = listOf(
    "A|Asparagus|ایسپیرگس|asparagus", "B|Broccoli|بروکلی|broccoli", "C|Carrot|گاجر|carrot",
    "D|Daikon (white radish)|مولی|daikon", "E|Eggplant|بینگن|eggplant", "F|French beans|پھلیاں|frenchbeans",
    "G|Garlic|لہسن|garlic", "H|Hot chili|لال مرچ|redchili", "I|Iceberg lettuce|سلاد پتا|iceberg",
    "J|Jalapeno|ہالاپینو|jalapeno", "K|Kale|کیل|kale", "L|Leek|لیک|leek", "M|Mushroom|کھمبی|mushroom",
    "N|Napa cabbage|چائنیز گوبھی|napa", "O|Onion|پیاز|onion", "P|Potato|آلو|potato",
    "Q|Queensland blue pumpkin|نیلا کدو|queensland", "R|Radish|مولی|radish", "S|Spinach|پالک|spinach",
    "T|Tomato|ٹماٹر|tomato", "U|Ube (purple yam)|جامنی شکرقندی|ube", "V|Vegetable marrow|گھیا کدو|marrow",
    "W|Watercress|واٹر کریس|watercress", "X|Xanthosoma (cocoyam)|اروی|xanthosoma", "Y|Yam|زمین قند|yam",
    "Z|Zucchini|زوکینی|zucchini"
).map { line ->
    val p = line.split("|")
    LetterItem(p[0][0], p[1], "", p[2], "vg_${p[3]}", "vg_${p[3]}", plain = true)
}

private val vegUrduWords: Map<String, Triple<String, String, String>> = mapOf(
    "آ" to Triple("آلو", "Potato", "vg_potato"),
    "ا" to Triple("ادرک", "Ginger", "vg_ginger"),
    "ب" to Triple("بھنڈی", "Okra", "vg_okra"),
    "پ" to Triple("پیاز", "Onion", "vg_onion"),
    "ت" to Triple("توری", "Ridge gourd", "vg_tori"),
    "ٹ" to Triple("ٹماٹر", "Tomato", "vg_tomato"),
    "چ" to Triple("چقندر", "Beetroot", "vg_beetroot"),
    "خ" to Triple("خیار", "Cucumber", "vg_cucumber"),
    "د" to Triple("دھنیا", "Coriander", "vg_coriander"),
    "ز" to Triple("زوکینی", "Zucchini", "vg_zucchini"),
    "س" to Triple("سلاد", "Lettuce", "vg_iceberg"),
    "ش" to Triple("شلجم", "Turnip", "vg_turnip"),
    "گ" to Triple("گاجر", "Carrot", "vg_carrot"),
    "ک" to Triple("کدو", "Pumpkin", "vg_pumpkin"),
    "ل" to Triple("لہسن", "Garlic", "vg_garlic"),
    "م" to Triple("مولی", "Radish", "vg_daikon"),
    "ہ" to Triple("ہری مرچ", "Green chili", "vg_greenchili")
)

val vegUrdu: List<UrduLetter> = urduAlphabet.map { base ->
    val w = vegUrduWords[base.letter]
    if (w != null) UrduLetter(base.letter, base.name, w.first, w.second, "", w.third)
    else UrduLetter(base.letter, base.name, "", "No common vegetable", "", null)
}

val vegNumbers: List<NumberItem> = listOf(
    "Potato|آلو|potato", "Onion|پیاز|onion", "Tomato|ٹماٹر|tomato", "Carrot|گاجر|carrot",
    "Cucumber|کھیرا|cucumber", "Peas|مٹر|peas", "Cauliflower|پھول گوبھی|cauliflower",
    "Cabbage|بند گوبھی|cabbage", "Spinach|پالک|spinach", "Okra|بھنڈی|okra",
    "Green chili|ہری مرچ|greenchili", "Pumpkin|کدو|pumpkin", "Eggplant|بینگن|eggplant",
    "Radish|مولی|daikon", "Garlic|لہسن|garlic", "Ginger|ادرک|ginger", "Corn|مکئی|corn",
    "Capsicum|شملہ مرچ|capsicum", "Broccoli|بروکلی|broccoli", "Beetroot|چقندر|beetroot"
).map { line ->
    val p = line.split("|")
    NumberItem(p[0], p[1], "vg_${p[2]}")
}


// ---------- THINGS: from the supplied object photo sheets ----------

val thingLetters: List<LetterItem> = listOf(
    "A|Airplane|ہوائی جہاز|airplane", "B|Ball|گیند|ball", "C|Car|کار|car", "D|Door|دروازہ|door",
    "E|Envelope|لفافہ|envelope", "F|Fan|پنکھا|fan", "G|Guitar|گٹار|guitar", "H|Hat|ہیٹ|hat",
    "I|Iron|استری|iron", "J|Jug|جگ|jug", "K|Key|چابی|key", "L|Lamp|لیمپ|lamp",
    "M|Mobile phone|موبائل فون|phone", "N|Notebook|کاپی|notebook", "O|Oven|اوون|oven",
    "P|Pencil|پنسل|pencil", "Q|Quilt|رضائی|quilt", "R|Radio|ریڈیو|radio", "S|Shoes|جوتے|shoes",
    "T|Table|میز|table", "U|Umbrella|چھتری|umbrella", "V|Violin|وائلن|violin", "W|Watch|گھڑی|watch",
    "X|Xylophone|زائلوفون|xylophone", "Y|Yo-yo|یو یو|yoyo", "Z|Zipper|زپ|zipper"
).map { line ->
    val p = line.split("|")
    LetterItem(p[0][0], p[1], "", p[2], "th_${p[3]}", "th_${p[3]}", plain = true)
}

private val thingUrduWords: Map<String, Triple<String, String, String>> = mapOf(
    "آ" to Triple("آئینہ", "Mirror", "th_mirror"),
    "ا" to Triple("انگوٹھی", "Ring", "th_ring"),
    "ب" to Triple("بلب", "Bulb", "th_bulb"),
    "پ" to Triple("پنکھا", "Fan", "th_fan"),
    "ت" to Triple("تالا", "Lock", "th_lock"),
    "ٹ" to Triple("ٹوپی", "Cap", "th_cap"),
    "ج" to Triple("جوتا", "Shoe", "th_shoes"),
    "چ" to Triple("چابی", "Key", "th_key"),
    "خ" to Triple("خط", "Letter", "th_letter"),
    "د" to Triple("دروازہ", "Door", "th_door"),
    "ڈ" to Triple("ڈبہ", "Box", "th_box"),
    "ر" to Triple("رسی", "Rope", "th_rope"),
    "ز" to Triple("زنجیر", "Chain", "th_chain"),
    "س" to Triple("سائیکل", "Bicycle", "th_bicycle"),
    "ش" to Triple("شمع", "Candle", "th_candle"),
    "ص" to Triple("صندوق", "Chest", "th_chest"),
    "ط" to Triple("طبلہ", "Tabla", "th_tabla"),
    "ع" to Triple("عینک", "Glasses", "th_glasses"),
    "غ" to Triple("غبارہ", "Balloon", "th_balloon"),
    "ف" to Triple("فون", "Phone", "th_phone"),
    "ق" to Triple("قلم", "Pen", "th_pen"),
    "ک" to Triple("کتاب", "Book", "th_book"),
    "گ" to Triple("گھڑی", "Clock", "th_clock"),
    "ل" to Triple("لالٹین", "Lantern", "th_lantern"),
    "م" to Triple("میز", "Table", "th_table"),
    "ن" to Triple("نل", "Tap", "th_tap"),
    "ہ" to Triple("ہتھوڑا", "Hammer", "th_hammer")
)

val thingUrdu: List<UrduLetter> = urduAlphabet.map { base ->
    val w = thingUrduWords[base.letter]
    if (w != null) UrduLetter(base.letter, base.name, w.first, w.second, "", w.third)
    else UrduLetter(base.letter, base.name, "", "No common thing", "", null)
}

val thingNumbers: List<NumberItem> = listOf(
    "Ball|گیند|ball", "Car|کار|car", "Book|کتاب|book", "Chair|کرسی|chair", "Clock|گھڑی|clock",
    "Key|چابی|key", "Cup|کپ|cup", "Shoes|جوتے|shoes", "Hat|ہیٹ|hat", "Bag|بستہ|bag",
    "Pencil|پنسل|pencil", "Bicycle|سائیکل|bicycle", "Umbrella|چھتری|umbrella", "Lamp|لیمپ|lamp",
    "Mobile phone|موبائل فون|phone", "Teddy bear|ٹیڈی بیئر|teddy", "Scissors|قینچی|scissors",
    "Spoon|چمچ|spoon", "Glasses|عینک|glasses", "Toothbrush|ٹوتھ برش|toothbrush"
).map { line ->
    val p = line.split("|")
    NumberItem(p[0], p[1], "th_${p[2]}")
}


// ---------- NATURE: from the supplied nature photo sheets ----------

val natureLetters: List<LetterItem> = listOf(
    "A|Autumn leaves|خزاں کے پتے|autumnleaves", "B|Beach|ساحل|beach", "C|Cloud|بادل|cloud", "D|Desert|صحرا|desert",
    "E|Earth|زمین|earth", "F|Flower|پھول|flower", "G|Grass|گھاس|grass", "H|Hill|پہاڑی|hill",
    "I|Iceberg|برف کا تودہ|iceberg", "J|Jungle|جنگل|jungle", "K|Kelp forest|سمندری گھاس|kelp",
    "L|Lake|جھیل|lake", "M|Mountain|پہاڑ|mountain", "N|Nest|گھونسلا|nest", "O|Ocean wave|سمندری لہر|ocean",
    "P|Pond|تالاب|pond", "Q|Quartz crystal|بلور|quartz", "R|Rainbow|قوس قزح|rainbow", "S|Sun|سورج|sun",
    "T|Tree|درخت|tree", "U|Uluru rock|اُلورو چٹان|uluru", "V|Volcano|آتش فشاں|volcano",
    "W|Waterfall|آبشار|waterfall", "X|Xerophyte (cactus)|ناگ پھنی|cactus", "Y|Yucca|یوکا|yucca",
    "Z|Zinnia|زینیا|zinnia"
).map { line ->
    val p = line.split("|")
    LetterItem(p[0][0], p[1], "", p[2], "na_${p[3]}", "na_${p[3]}", plain = true)
}

private val natureUrduWords: Map<String, Triple<String, String, String>> = mapOf(
    "آ" to Triple("آسمان", "Sky", "na_sky"),
    "ا" to Triple("ابر", "Cloud", "na_cloud"),
    "ب" to Triple("بارش", "Rain", "na_rain"),
    "پ" to Triple("پھول", "Flower", "na_flower"),
    "ت" to Triple("تالاب", "Pond", "na_pond"),
    "ٹ" to Triple("ٹیلہ", "Sand dune", "na_dune"),
    "ج" to Triple("جنگل", "Forest", "na_forest"),
    "چ" to Triple("چاند", "Moon", "na_moon"),
    "د" to Triple("درخت", "Tree", "na_tree"),
    "ر" to Triple("ریت", "Sand", "na_sand"),
    "ز" to Triple("زمین", "Earth", "na_earth"),
    "س" to Triple("سورج", "Sun", "na_sun"),
    "ش" to Triple("شبنم", "Dew", "na_dew"),
    "ص" to Triple("صحرا", "Desert", "na_desert"),
    "ط" to Triple("طوفان", "Storm", "na_storm"),
    "غ" to Triple("غار", "Cave", "na_cave"),
    "ق" to Triple("قوس قزح", "Rainbow", "na_rainbow"),
    "ک" to Triple("کنول", "Lotus", "na_lotus"),
    "گ" to Triple("گھاس", "Grass", "na_grass"),
    "ل" to Triple("لہر", "Wave", "na_ocean"),
    "م" to Triple("مٹی", "Soil", "na_soil"),
    "ن" to Triple("ندی", "Stream", "na_stream"),
    "و" to Triple("وادی", "Valley", "na_valley")
)

val natureUrdu: List<UrduLetter> = urduAlphabet.map { base ->
    val w = natureUrduWords[base.letter]
    if (w != null) UrduLetter(base.letter, base.name, w.first, w.second, "", w.third)
    else UrduLetter(base.letter, base.name, "", "No common nature item", "", null)
}

val natureNumbers: List<NumberItem> = listOf(
    "Sun|سورج|sun", "Moon|چاند|moon", "Stars|ستارے|stars", "Cloud|بادل|cloud", "Rainbow|قوس قزح|rainbow",
    "Flower|پھول|flower", "Tree|درخت|tree", "Leaf|پتا|leaf", "Mountain|پہاڑ|mountain",
    "Waterfall|آبشار|waterfall", "Lake|جھیل|lake", "Ocean wave|لہر|ocean", "Rose|گلاب|rose",
    "Sunflower|سورج مکھی|sunflower", "Cactus|ناگ پھنی|cactus", "Seashell|سیپ|seashell",
    "Pinecone|صنوبر کا پھل|pinecone", "Feather|پنکھ|feather", "Snowflake|برف کا گالا|snowflake",
    "Pebbles|کنکر|pebbles"
).map { line ->
    val p = line.split("|")
    NumberItem(p[0], p[1], "na_${p[2]}")
}


// ---------- COLORS: from the supplied colour photo sheets ----------

val colorLetters: List<LetterItem> = listOf(
    "A|Amber|عنبر|amber", "B|Blue|نیلا|balloon", "C|Coral|مرجان|coral", "D|Denim|ڈینم|denim",
    "E|Emerald|زمرد|emerald", "F|Fuchsia|فیوشیا|fuchsia", "G|Green|ہرا|greenapple", "H|Honey|شہد|honey",
    "I|Indigo|نیل|indigo", "J|Jade|یشم|jade", "K|Khaki|خاکی|khaki", "L|Lavender|لیوینڈر|lavender",
    "M|Maroon|عنابی|maroon", "N|Navy|گہرا نیلا|navy", "O|Orange|نارنجی|orange", "P|Pink|گلابی|pink",
    "Q|Quartz (rose)|گلابی قوارٹز|quartz", "R|Red|لال|red", "S|Silver|چاندی|silver", "T|Teal|ٹیل|teal",
    "U|Ultramarine|لاجورد|lapis", "V|Violet|بنفشی|violet", "W|White|سفید|white", "X|Xanthic (yellow)|زرد|duck",
    "Y|Yellow|پیلا|banana", "Z|Zinc (grey)|جست|zinc"
).map { line ->
    val p = line.split("|")
    LetterItem(p[0][0], p[1], "", p[2], "co_${p[3]}", "co_${p[3]}", plain = true)
}

private val colorUrduWords: Map<String, Triple<String, String, String>> = mapOf(
    "آ" to Triple("آسمانی", "Sky blue", "co_sky"),
    "ا" to Triple("ارغوانی", "Magenta", "co_magenta"),
    "ب" to Triple("بھورا", "Brown", "co_brown"),
    "پ" to Triple("پیلا", "Yellow", "co_banana"),
    "ج" to Triple("جامنی", "Purple", "co_purple"),
    "چ" to Triple("چاندی", "Silver", "co_silver"),
    "خ" to Triple("خاکی", "Khaki", "co_khaki"),
    "ز" to Triple("زیتونی", "Olive green", "co_olives"),
    "س" to Triple("سفید", "White", "co_white"),
    "ع" to Triple("عنابی", "Maroon", "co_maroon"),
    "ف" to Triple("فیروزی", "Turquoise", "co_turquoise"),
    "گ" to Triple("گلابی", "Pink", "co_pink"),
    "ک" to Triple("کالا", "Black", "co_black"),
    "ل" to Triple("لال", "Red", "co_red"),
    "م" to Triple("مالٹائی", "Orange", "co_orange"),
    "ن" to Triple("نیلا", "Blue", "co_balloon"),
    "ہ" to Triple("ہرا", "Green", "co_green")
)

val colorUrdu: List<UrduLetter> = urduAlphabet.map { base ->
    val w = colorUrduWords[base.letter]
    if (w != null) UrduLetter(base.letter, base.name, w.first, w.second, "", w.third)
    else UrduLetter(base.letter, base.name, "", "No common colour", "", null)
}

val colorNumbers: List<NumberItem> = listOf(
    "Red apple|لال سیب|red", "Orange|نارنجی مالٹا|orange", "Yellow banana|پیلا کیلا|banana",
    "Green leaf|ہرا پتا|green", "Blue balloon|نیلا غبارہ|balloon", "Purple grapes|جامنی انگور|purple",
    "Pink piggy bank|گلابی گلک|pink", "Brown teddy|بھورا ٹیڈی|brown", "Black coal|کالا کوئلہ|black",
    "White daisy|سفید گل اقحوان|white", "Grey stone|سلیٹی پتھر|grey", "Gold coins|سنہری سکے|gold",
    "Silver coins|چاندی کے سکے|silver", "Maroon bag|عنابی بیگ|maroon", "Navy shoes|گہرے نیلے جوتے|navy",
    "Teal mug|فیروزی مگ|teal", "Turquoise gem|فیروزہ|turquoise", "Lavender|لیوینڈر|lavender",
    "Coral|مرجان|coral", "Olives|زیتون|olives"
).map { line ->
    val p = line.split("|")
    NumberItem(p[0], p[1], "co_${p[2]}")
}


// ---------- INSECTS: from the supplied photo sheets ----------

val insectLetters: List<LetterItem> = listOf(
    "A|Ant|چیونٹی|ant",
    "B|Bee|مکھی|bee",
    "C|Caterpillar|سنڈی|caterpillar",
    "D|Dragonfly|ڈریگن فلائی|dragonfly",
    "E|Earwig|ایئروگ|earwig",
    "F|Firefly|جگنو|firefly",
    "G|Grasshopper|ٹڈا|grasshopper",
    "H|Honey bee|شہد کی مکھی|honeybee",
    "I|Inchworm|ناپنے والا کیڑا|inchworm",
    "J|Jewel beetle|چمکدار بھونرا|jewelbeetle",
    "K|Katydid|ٹڈی|katydid",
    "L|Leaf beetle|پتے کا بھونرا|beetle",
    "M|Mosquito|مچھر|mosquito",
    "N|Nut weevil|گھن|weevil",
    "O|Orchid mantis|آرکڈ مینٹس|orchidmantis",
    "P|Paper wasp|کاغذی بھڑ|paperwasp",
    "Q|Queen bee|ملکہ مکھی|queenbee",
    "R|Rhinoceros beetle|گینڈا بھونرا|rhino",
    "S|Stick insect|ڈنڈی کیڑا|stick",
    "T|Termite|دیمک|termite",
    "U|Underwing moth|پتنگا|underwing",
    "V|Velvet ant|مخملی چیونٹی|velvetant",
    "W|Water strider|پانی کا کیڑا|strider",
    "X|Xylocopa carpenter bee|بڑھئی مکھی|xylocopa",
    "Y|Yellowjacket|زرد بھڑ|yellowjacket",
    "Z|Zebra butterfly|زیبرا تتلی|zebra"
).map { line ->
    val p = line.split("|")
    LetterItem(p[0][0], p[1], "", p[2], "in_${p[3]}", "in_${p[3]}", plain = true)
}

private val insectUrduWords: Map<String, Triple<String, String, String>> = mapOf(
    "پ" to Triple("پتنگا", "Moth", "in_moth"),
    "ت" to Triple("تتلی", "Butterfly", "in_butterfly"),
    "ٹ" to Triple("ٹڈا", "Grasshopper", "in_grasshopper"),
    "ج" to Triple("جگنو", "Firefly", "in_firefly"),
    "چ" to Triple("چیونٹی", "Ant", "in_ant"),
    "د" to Triple("دیمک", "Termite", "in_termite"),
    "ڈ" to Triple("ڈریگن فلائی", "Dragonfly", "in_dragonfly"),
    "ز" to Triple("زنبور", "Wasp", "in_wasp"),
    "س" to Triple("سنڈی", "Caterpillar", "in_caterpillar"),
    "ش" to Triple("شہد کی مکھی", "Honey bee", "in_honeybee"),
    "ع" to Triple("عنکبوت", "Spider", "in_spider"),
    "ب" to Triple("بھونرا", "Beetle", "in_beetle"),
    "م" to Triple("مچھر", "Mosquito", "in_mosquito")
)

val insectUrdu: List<UrduLetter> = urduAlphabet.map { base ->
    val w = insectUrduWords[base.letter]
    if (w != null) UrduLetter(base.letter, base.name, w.first, w.second, "", w.third)
    else UrduLetter(base.letter, base.name, "", "No common insect", "", null)
}

val insectNumbers: List<NumberItem> = listOf(
    "Ant|چیونٹی|ant",
    "Bee|مکھی|bee",
    "Butterfly|تتلی|butterfly",
    "Zebra butterfly|زیبرا تتلی|zebra",
    "Dragonfly|ڈریگن فلائی|dragonfly",
    "Grasshopper|ٹڈا|grasshopper",
    "Firefly|جگنو|firefly",
    "Katydid|جھینگر|katydid",
    "Moth|پتنگا|moth",
    "Beetle|بھونرا|beetle",
    "Caterpillar|سنڈی|caterpillar",
    "Praying mantis|مینٹس|mantis",
    "Wasp|زنبور|wasp",
    "Mosquito|مچھر|mosquito",
    "Yellowjacket|زرد بھڑ|yellowjacket",
    "Termite|دیمک|termite",
    "Stick insect|ڈنڈی کیڑا|stick",
    "Rhinoceros beetle|گینڈا بھونرا|rhino",
    "Spider|عنکبوت|spider",
    "Cicada|سیکاڈا|cicada"
).map { line ->
    val p = line.split("|")
    NumberItem(p[0], p[1], "in_${p[2]}")
}


// ---------- SEA CREATURES: from the supplied photo sheets ----------

val seaLetters: List<LetterItem> = listOf(
    "A|Angelfish|اینجل فش|angelfish",
    "B|Blue whale|نیلی وہیل|whale",
    "C|Clownfish|کلاؤن فش|clownfish",
    "D|Dolphin|ڈولفن|dolphin",
    "E|Eel|بام مچھلی|eel",
    "F|Flounder|چپٹی مچھلی|flounder",
    "G|Great white shark|سفید شارک|greatwhite",
    "H|Hammerhead shark|ہتھوڑا شارک|hammerhead",
    "I|Ice fish|برفانی مچھلی|icefish",
    "J|Jellyfish|جیلی فش|jellyfish",
    "K|King crab|کیکڑا|kingcrab",
    "L|Lobster|لابسٹر|lobster",
    "M|Manta ray|مینٹا رے|manta",
    "N|Narwhal|ناروال|narwhal",
    "O|Octopus|آکٹوپس|octopus",
    "P|Pufferfish|پفر فش|puffer",
    "Q|Queen conch|گھونگا|conch",
    "R|Regal tang|ٹینگ مچھلی|tang",
    "S|Starfish|ستارہ مچھلی|starfish",
    "T|Turtle|کچھوا|turtle",
    "U|Urchin (sea urchin)|سمندری خارپشت|urchin",
    "V|Vase sponge|اسفنج|sponge",
    "W|Walrus|والرس|walrus",
    "X|Xiphias swordfish|تلوار مچھلی|swordfish",
    "Y|Yellowfin tuna|ٹونا|tuna",
    "Z|Zebra shark|زیبرا شارک|zebrashark"
).map { line ->
    val p = line.split("|")
    LetterItem(p[0][0], p[1], "", p[2], "se_${p[3]}", "se_${p[3]}", plain = true)
}

private val seaUrduWords: Map<String, Triple<String, String, String>> = mapOf(
    "ا" to Triple("اسٹار فش", "Starfish", "se_starfish"),
    "آ" to Triple("آکٹوپس", "Octopus", "se_octopus"),
    "ب" to Triple("بام مچھلی", "Eel", "se_eel"),
    "پ" to Triple("پینگوئن", "Penguin", "se_penguin"),
    "ٹ" to Triple("ٹونا", "Tuna", "se_tuna"),
    "ج" to Triple("جیلی فش", "Jellyfish", "se_jellyfish"),
    "ڈ" to Triple("ڈولفن", "Dolphin", "se_dolphin"),
    "س" to Triple("سمندری گھوڑا", "Seahorse", "se_seahorse"),
    "ش" to Triple("شارک", "Shark", "se_greatwhite"),
    "ص" to Triple("صدف", "Oyster", "se_oyster"),
    "ک" to Triple("کچھوا", "Turtle", "se_turtle"),
    "گ" to Triple("گھونگا", "Conch shell", "se_conch"),
    "ل" to Triple("لابسٹر", "Lobster", "se_lobster"),
    "م" to Triple("مچھلی", "Fish", "se_clownfish"),
    "و" to Triple("وہیل", "Whale", "se_whale")
)

val seaUrdu: List<UrduLetter> = urduAlphabet.map { base ->
    val w = seaUrduWords[base.letter]
    if (w != null) UrduLetter(base.letter, base.name, w.first, w.second, "", w.third)
    else UrduLetter(base.letter, base.name, "", "No common sea creature", "", null)
}

val seaNumbers: List<NumberItem> = listOf(
    "Clownfish|مچھلی|clownfish",
    "Dolphin|ڈولفن|dolphin",
    "Blue whale|وہیل|whale",
    "Great white shark|شارک|greatwhite",
    "Turtle|کچھوا|turtle",
    "King crab|کیکڑا|kingcrab",
    "Octopus|آکٹوپس|octopus",
    "Jellyfish|جیلی فش|jellyfish",
    "Starfish|اسٹار فش|starfish",
    "Seahorse|سمندری گھوڑا|seahorse",
    "Lobster|لابسٹر|lobster",
    "Penguin|پینگوئن|penguin",
    "Pufferfish|پفر فش|puffer",
    "Manta ray|مینٹا رے|manta",
    "Walrus|والرس|walrus",
    "Eel|بام مچھلی|eel",
    "Swordfish|تلوار مچھلی|swordfish",
    "Angelfish|اینجل فش|angelfish",
    "Sea urchin|سمندری خارپشت|urchin",
    "Seal|سیل|seal"
).map { line ->
    val p = line.split("|")
    NumberItem(p[0], p[1], "se_${p[2]}")
}


// ---------- BIRDS: from the supplied photo sheets ----------

val birdLetters: List<LetterItem> = listOf(
    "A|Albatross|البیٹروس|albatross",
    "B|Blue jay|نیلا جے|bluejay",
    "C|Crow|کوا|crow",
    "D|Duck|بطخ|duck",
    "E|Eagle|عقاب|eagle",
    "F|Flamingo|راج ہنس|flamingo",
    "G|Goose|قاز|goose",
    "H|Hen|مرغی|hen",
    "I|Ibis|ابس|ibis",
    "J|Jackdaw|ڈھوک کوا|jackdaw",
    "K|Kingfisher|ماہی خور|kingfisher",
    "L|Lovebird|لو برڈ|lovebird",
    "M|Magpie|میگ پائی|magpie",
    "N|Nightingale|بلبل|nightingale",
    "O|Owl|الو|owl",
    "P|Parrot|طوطا|parrot",
    "Q|Quail|بٹیر|quail",
    "R|Robin|رابن|robin",
    "S|Sparrow|چڑیا|sparrow",
    "T|Toucan|ٹوکن|toucan",
    "U|Umbrellabird|امبریلا برڈ|umbrellabird",
    "V|Vulture|گدھ|vulture",
    "W|Woodpecker|کٹھ پھوڑا|woodpecker",
    "X|Xantus hummingbird|ہمنگ برڈ|hummingbird",
    "Y|Yellow warbler|پیلی چڑیا|warbler",
    "Z|Zebra finch|زیبرا فنچ|zebrafinch"
).map { line ->
    val p = line.split("|")
    LetterItem(p[0][0], p[1], "", p[2], "bi_${p[3]}", "bi_${p[3]}", plain = true)
}

private val birdUrduWords: Map<String, Triple<String, String, String>> = mapOf(
    "ا" to Triple("ابابیل", "Swallow", "bi_swallow"),
    "ب" to Triple("بطخ", "Duck", "bi_duck"),
    "ت" to Triple("تیتر", "Partridge", "bi_partridge"),
    "ٹ" to Triple("ٹرکی", "Turkey", "bi_turkey"),
    "چ" to Triple("چڑیا", "Sparrow", "bi_sparrow"),
    "ط" to Triple("طوطا", "Parrot", "bi_parrot"),
    "ع" to Triple("عقاب", "Eagle", "bi_eagle"),
    "ف" to Triple("فاختہ", "Dove", "bi_dove"),
    "ق" to Triple("قاز", "Goose", "bi_goose"),
    "ک" to Triple("کبوتر", "Pigeon", "bi_pigeon"),
    "گ" to Triple("گدھ", "Vulture", "bi_vulture"),
    "ل" to Triple("لق لق", "Stork", "bi_stork"),
    "م" to Triple("مور", "Peacock", "bi_peacock"),
    "ہ" to Triple("ہد ہد", "Hoopoe", "bi_hoopoe"),
    "ش" to Triple("شاہین", "Falcon", "bi_falcon")
)

val birdUrdu: List<UrduLetter> = urduAlphabet.map { base ->
    val w = birdUrduWords[base.letter]
    if (w != null) UrduLetter(base.letter, base.name, w.first, w.second, "", w.third)
    else UrduLetter(base.letter, base.name, "", "No common bird", "", null)
}

val birdNumbers: List<NumberItem> = listOf(
    "Sparrow|چڑیا|sparrow",
    "Parrot|طوطا|parrot",
    "Crow|کوا|crow",
    "Pigeon|کبوتر|pigeon",
    "Duck|بطخ|duck",
    "Hen|مرغی|hen",
    "Rooster|مرغا|rooster",
    "Peacock|مور|peacock",
    "Owl|الو|owl",
    "Eagle|عقاب|eagle",
    "Swan|ہنس|swan",
    "Flamingo|راج ہنس|flamingo",
    "Penguin|پینگوئن|penguin",
    "Ostrich|شتر مرغ|ostrich",
    "Turkey|ٹرکی|turkey",
    "Kingfisher|ماہی خور|kingfisher",
    "Woodpecker|کٹھ پھوڑا|woodpecker",
    "Toucan|ٹوکن|toucan",
    "Stork|لق لق|stork",
    "Dove|فاختہ|dove"
).map { line ->
    val p = line.split("|")
    NumberItem(p[0], p[1], "bi_${p[2]}")
}


// ---------- VEHICLES: from the supplied photo sheets ----------

val vehicleLetters: List<LetterItem> = listOf(
    "A|Ambulance|ایمبولینس|ambulance",
    "B|Bus|بس|bus",
    "C|Car|کار|car",
    "D|Dump truck|ڈمپر ٹرک|dumptruck",
    "E|Excavator|کھدائی مشین|excavator",
    "F|Fire truck|فائر بریگیڈ|firetruck",
    "G|Garbage truck|کچرا گاڑی|garbagetruck",
    "H|Helicopter|ہیلی کاپٹر|helicopter",
    "I|Ice cream truck|آئس کریم وین|icecream",
    "J|Jeep|جیپ|jeep",
    "K|Kick scooter|کک اسکوٹر|kickscooter",
    "L|Lorry|لاری|lorry",
    "M|Motorcycle|موٹر سائیکل|motorcycle",
    "N|Narrow boat|لمبی کشتی|narrowboat",
    "O|Ox cart|بیل گاڑی|oxcart",
    "P|Police car|پولیس کار|police",
    "Q|Quad bike|کواڈ بائیک|quadbike",
    "R|Rickshaw|رکشہ|rickshaw",
    "S|School bus|اسکول بس|schoolbus",
    "T|Tractor|ٹریکٹر|tractor",
    "U|Unicycle|ایک پہیہ سائیکل|unicycle",
    "V|Van|وین|van",
    "W|Wagon|ٹرالی|wagon",
    "X|Xtreme monster truck|مونسٹر ٹرک|monstertruck",
    "Y|Yacht|یاٹ|yacht",
    "Z|Zeppelin|غبارہ جہاز|zeppelin"
).map { line ->
    val p = line.split("|")
    LetterItem(p[0][0], p[1], "", p[2], "ve_${p[3]}", "ve_${p[3]}", plain = true)
}

private val vehicleUrduWords: Map<String, Triple<String, String, String>> = mapOf(
    "ا" to Triple("ایمبولینس", "Ambulance", "ve_ambulance"),
    "آ" to Triple("آبدوز", "Submarine", "ve_submarine"),
    "ب" to Triple("بس", "Bus", "ve_bus"),
    "پ" to Triple("پولیس", "Police car", "ve_police"),
    "ٹ" to Triple("ٹرین", "Train", "ve_train"),
    "ج" to Triple("جہاز", "Ship", "ve_ship"),
    "ڈ" to Triple("ڈمپر", "Dump truck", "ve_dumptruck"),
    "ر" to Triple("رکشہ", "Rickshaw", "ve_rickshaw"),
    "س" to Triple("سائیکل", "Bicycle", "ve_bicycle"),
    "ف" to Triple("فائر بریگیڈ", "Fire truck", "ve_firetruck"),
    "ک" to Triple("کار", "Car", "ve_car"),
    "ل" to Triple("لاری", "Lorry", "ve_lorry"),
    "م" to Triple("موٹر سائیکل", "Motorcycle", "ve_motorcycle"),
    "ن" to Triple("ناؤ", "Boat", "ve_boat"),
    "و" to Triple("وین", "Van", "ve_van"),
    "ہ" to Triple("ہوائی جہاز", "Airplane", "ve_airplane")
)

val vehicleUrdu: List<UrduLetter> = urduAlphabet.map { base ->
    val w = vehicleUrduWords[base.letter]
    if (w != null) UrduLetter(base.letter, base.name, w.first, w.second, "", w.third)
    else UrduLetter(base.letter, base.name, "", "No common vehicle", "", null)
}

val vehicleNumbers: List<NumberItem> = listOf(
    "Car|کار|car",
    "Bus|بس|bus",
    "Train|ٹرین|train",
    "Airplane|ہوائی جہاز|airplane",
    "Boat|ناؤ|boat",
    "Bicycle|سائیکل|bicycle",
    "Motorcycle|موٹر سائیکل|motorcycle",
    "Truck|ٹرک|truck",
    "Tractor|ٹریکٹر|tractor",
    "Helicopter|ہیلی کاپٹر|helicopter",
    "Rickshaw|رکشہ|rickshaw",
    "Ambulance|ایمبولینس|ambulance",
    "Fire truck|فائر بریگیڈ|firetruck",
    "Police car|پولیس کار|police",
    "Ship|جہاز|ship",
    "Submarine|آبدوز|submarine",
    "Scooter|اسکوٹر|scooter",
    "Taxi|ٹیکسی|taxi",
    "School bus|اسکول بس|schoolbus",
    "Rocket|راکٹ|rocket"
).map { line ->
    val p = line.split("|")
    NumberItem(p[0], p[1], "ve_${p[2]}")
}


// ---------- BODY PARTS: from the supplied photo sheets ----------

val bodyLetters: List<LetterItem> = listOf(
    "A|Arm|بازو|arm",
    "B|Back|پیٹھ|back",
    "C|Chin|ٹھوڑی|chin",
    "D|Dimples|گال کا گڑھا|dimples",
    "E|Ear|کان|ear",
    "F|Foot|پاؤں|foot",
    "G|Grin|مسکراہٹ|grin",
    "H|Hand|ہاتھ|hand",
    "I|Index finger|شہادت کی انگلی|index",
    "J|Jaw|جبڑا|jaw",
    "K|Knuckles|انگلیوں کے جوڑ|knuckles",
    "L|Leg|ٹانگ|leg",
    "M|Mouth|منہ|mouth",
    "N|Nose|ناک|nose",
    "O|Open palm|کھلی ہتھیلی|palm",
    "P|Pinky finger|چھنگلی|pinky",
    "Q|Quiff (hair)|بال|head",
    "R|Ring finger|انگوٹھی کی انگلی|ring",
    "S|Shoulder|کندھا|shoulder",
    "T|Thumb|انگوٹھا|thumb",
    "U|Underfoot (sole)|تلوا|sole",
    "V|V-sign fingers|وکٹری|vsign",
    "W|Wrist|کلائی|wrist",
    "X|X-ray hand|ایکس رے ہاتھ|xray",
    "Y|Yawning mouth|جمائی|yawn",
    "Z|Zipped lips|بند ہونٹ|zipped"
).map { line ->
    val p = line.split("|")
    LetterItem(p[0][0], p[1], "", p[2], "bo_${p[3]}", "bo_${p[3]}", plain = true)
}

private val bodyUrduWords: Map<String, Triple<String, String, String>> = mapOf(
    "آ" to Triple("آنکھ", "Eye", "bo_eye"),
    "ا" to Triple("انگلی", "Finger", "bo_finger"),
    "ب" to Triple("بازو", "Arm", "bo_arm"),
    "پ" to Triple("پاؤں", "Foot", "bo_foot"),
    "د" to Triple("دانت", "Teeth", "bo_teeth"),
    "ر" to Triple("رخسار", "Cheek", "bo_cheek"),
    "ز" to Triple("زبان", "Tongue", "bo_tongue"),
    "س" to Triple("سر", "Head", "bo_head"),
    "ٹ" to Triple("ٹانگ", "Leg", "bo_leg"),
    "ک" to Triple("کان", "Ear", "bo_ear"),
    "گ" to Triple("گردن", "Neck", "bo_neck"),
    "م" to Triple("منہ", "Mouth", "bo_mouth"),
    "ن" to Triple("ناک", "Nose", "bo_nose"),
    "ہ" to Triple("ہاتھ", "Hand", "bo_hand")
)

val bodyUrdu: List<UrduLetter> = urduAlphabet.map { base ->
    val w = bodyUrduWords[base.letter]
    if (w != null) UrduLetter(base.letter, base.name, w.first, w.second, "", w.third)
    else UrduLetter(base.letter, base.name, "", "No common body part", "", null)
}

val bodyNumbers: List<NumberItem> = listOf(
    "Nose|ناک|nose",
    "Eye|آنکھ|eye",
    "Ear|کان|ear",
    "Hand|ہاتھ|hand",
    "Foot|پاؤں|foot",
    "Mouth|منہ|mouth",
    "Teeth|دانت|teeth",
    "Tongue|زبان|tongue",
    "Finger|انگلی|finger",
    "Thumb|انگوٹھا|thumb",
    "Cheek|رخسار|cheek",
    "Elbow|کہنی|elbow",
    "Leg|ٹانگ|leg",
    "Arm|بازو|arm",
    "Head|سر|head",
    "Hair|بال|hairback",
    "Neck|گردن|neck",
    "Shoulder|کندھا|shoulder",
    "Belly|پیٹ|belly",
    "Toes|پاؤں کی انگلیاں|toes"
).map { line ->
    val p = line.split("|")
    NumberItem(p[0], p[1], "bo_${p[2]}")
}


// ---------- SHAPES: from the supplied photo sheets ----------

val shapeLetters: List<LetterItem> = listOf(
    "A|Arrow|تیر|arrow",
    "B|Box (cube)|ڈبہ|box",
    "C|Circle|دائرہ|circle",
    "D|Diamond|ہیرا|diamond",
    "E|Ellipse|بیضہ|ellipse",
    "F|Flower shape|پھول|flower",
    "G|Gear|گراری|gear",
    "H|Heart|دل|heart",
    "I|Inverted triangle|الٹا تکون|invtriangle",
    "J|Jigsaw piece|پزل ٹکڑا|jigsaw",
    "K|Kite|پتنگ|kite",
    "L|L-shape|ایل شکل|lshape",
    "M|Moon|چاند|moon",
    "N|Nonagon|نو کونہ|nonagon",
    "O|Octagon|آٹھ کونہ|octagon",
    "P|Pentagon|پنج کونہ|pentagon",
    "Q|Quatrefoil|چار پتی|quatrefoil",
    "R|Rectangle|مستطیل|rectangle",
    "S|Square|مربع|square",
    "T|Triangle|تکون|triangle",
    "U|U-shape|یو شکل|ushape",
    "V|V-shape|وی شکل|vshape",
    "W|Wedge|پچر|wedge",
    "X|X cross|کراس|xcross",
    "Y|Y-shape|وائی شکل|yshape",
    "Z|Zigzag (Z)|زگ زیگ|zigzag"
).map { line ->
    val p = line.split("|")
    LetterItem(p[0][0], p[1], "", p[2], "sh_${p[3]}", "sh_${p[3]}", plain = true)
}

private val shapeUrduWords: Map<String, Triple<String, String, String>> = mapOf(
    "د" to Triple("دائرہ", "Circle", "sh_circle"),
    "م" to Triple("مربع", "Square", "sh_square"),
    "ت" to Triple("تکون", "Triangle", "sh_triangle"),
    "س" to Triple("ستارہ", "Star", "sh_star"),
    "ہ" to Triple("ہیرا", "Diamond", "sh_diamond"),
    "ب" to Triple("بیضوی", "Oval", "sh_oval"),
    "چ" to Triple("چاند", "Crescent moon", "sh_crescent"),
    "پ" to Triple("پنج کونہ", "Pentagon", "sh_pentagon"),
    "ک" to Triple("کراس", "Cross", "sh_cross"),
    "ش" to Triple("شش کونہ", "Hexagon", "sh_hexagon"),
    "ن" to Triple("نصف دائرہ", "Half circle", "sh_halfcircle"),
    "ز" to Triple("زگ زیگ", "Zigzag", "sh_zigzag")
)

val shapeUrdu: List<UrduLetter> = urduAlphabet.map { base ->
    val w = shapeUrduWords[base.letter]
    if (w != null) UrduLetter(base.letter, base.name, w.first, w.second, "", w.third)
    else UrduLetter(base.letter, base.name, "", "No common shape", "", null)
}

val shapeNumbers: List<NumberItem> = listOf(
    "Circle|دائرہ|circle",
    "Square|مربع|square",
    "Triangle|تکون|triangle",
    "Rectangle|مستطیل|rectangle",
    "Star|ستارہ|star",
    "Heart|دل|heart",
    "Diamond|ہیرا|diamond",
    "Oval|بیضوی|oval",
    "Pentagon|پنج کونہ|pentagon",
    "Hexagon|شش کونہ|hexagon",
    "Octagon|آٹھ کونہ|octagon",
    "Crescent moon|ہلال|crescent",
    "Cross|کراس|cross",
    "Arrow|تیر|arrow",
    "Kite|پتنگ|kite",
    "Flower|پھول|flower",
    "Gear|گراری|gear",
    "Cube|مکعب|cube",
    "Sphere|کرہ|sphere",
    "Cylinder|بیلن|cylinder"
).map { line ->
    val p = line.split("|")
    NumberItem(p[0], p[1], "sh_${p[2]}")
}


// ---------- WEATHER: from the supplied photo sheets ----------

val weatherLetters: List<LetterItem> = listOf(
    "A|Autumn leaves|خزاں کے پتے|autumn",
    "B|Blizzard|برفانی طوفان|blizzard",
    "C|Cloud|بادل|cloud",
    "D|Dew drops|شبنم|dew",
    "E|Evening sunset|غروب آفتاب|sunset",
    "F|Fog|دھند|fog",
    "G|Gale|تیز ہوا|gale",
    "H|Hail|اولے|hail",
    "I|Ice|برف کی ڈلی|ice",
    "J|Jumping in puddles|چھپ چھپ|jump",
    "K|Kite flying|پتنگ بازی|kite",
    "L|Lightning|بجلی|lightning",
    "M|Mist|دھند|mist",
    "N|Northern lights|قطبی روشنی|aurora",
    "O|Overcast sky|ابر آلود|overcast",
    "P|Puddle|پانی کا گڑھا|puddle",
    "Q|Quiet snowfall|برف باری|snowfall",
    "R|Rain|بارش|rain",
    "S|Snow|برف|snow",
    "T|Thunderstorm|گرج چمک|storm",
    "U|Umbrella in rain|بارش میں چھتری|umbrella",
    "V|Vivid rainbow|قوس قزح|rainbow",
    "W|Wind|ہوا|wind",
    "X|Xmas snow (winter)|سردی کی برف|xmas",
    "Y|Yellow sun|سورج|sun",
    "Z|Zero degrees frost|پالا|frost"
).map { line ->
    val p = line.split("|")
    LetterItem(p[0][0], p[1], "", p[2], "we_${p[3]}", "we_${p[3]}", plain = true)
}

private val weatherUrduWords: Map<String, Triple<String, String, String>> = mapOf(
    "ب" to Triple("بارش", "Rain", "we_rain"),
    "ہ" to Triple("ہوا", "Wind", "we_wind"),
    "د" to Triple("دھوپ", "Sun", "we_sun"),
    "ا" to Triple("ابر", "Cloud", "we_cloud"),
    "ک" to Triple("کہر", "Fog", "we_fog"),
    "ق" to Triple("قوس قزح", "Rainbow", "we_rainbow"),
    "ط" to Triple("طوفان", "Storm", "we_storm"),
    "ژ" to Triple("ژالہ باری", "Hail", "we_hail"),
    "خ" to Triple("خزاں", "Autumn", "we_autumn"),
    "ش" to Triple("شبنم", "Dew", "we_dew"),
    "س" to Triple("سردی", "Winter", "we_xmas"),
    "گ" to Triple("گرمی", "Summer", "we_summer"),
    "ی" to Triple("یخ", "Ice", "we_ice")
)

val weatherUrdu: List<UrduLetter> = urduAlphabet.map { base ->
    val w = weatherUrduWords[base.letter]
    if (w != null) UrduLetter(base.letter, base.name, w.first, w.second, "", w.third)
    else UrduLetter(base.letter, base.name, "", "No common weather item", "", null)
}

val weatherNumbers: List<NumberItem> = listOf(
    "Sun|سورج|sun",
    "Cloud|بادل|cloud",
    "Rain|بارش|rain",
    "Snow|برف|snow",
    "Wind|ہوا|wind",
    "Rainbow|قوس قزح|rainbow",
    "Lightning|بجلی|lightning",
    "Thunderstorm|طوفان|storm",
    "Fog|دھند|fog",
    "Hail|اولے|hail",
    "Spring|بہار|spring",
    "Summer|گرمی|summer",
    "Autumn|خزاں|autumn",
    "Winter|سردی|xmas",
    "Puddle|پانی کا گڑھا|puddle",
    "Umbrella|چھتری|umbrella",
    "Frost|پالا|frost",
    "Ice|برف کی ڈلی|ice",
    "Dew|شبنم|dew",
    "Sunset|غروب آفتاب|sunset"
).map { line ->
    val p = line.split("|")
    NumberItem(p[0], p[1], "we_${p[2]}")
}
