package com.littlelearners.app

import androidx.compose.ui.graphics.Color

/** Emojis used for counting, per category. */
val Category.items: List<String>
    get() = when (this) {
        Category.ANIMALS -> listOf("🐶", "🐱", "🐰", "🐸", "🐘")
        Category.VEGETABLES -> listOf("🥕", "🌽", "🍅", "🥦")
        Category.FRUITS -> listOf("🍎", "🍌", "🍇", "🍓", "🍊")
        Category.THINGS -> listOf("⚽", "🧸", "🎈", "🚗")
        Category.NATURE -> listOf("🌳", "🌸", "⭐", "🌻")
        Category.COLORS -> listOf("🔴", "🟢", "🔵", "🟡")
    }

// ---------- Numbers ----------

val numberWordsEn = listOf(
    "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten",
    "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen",
    "Eighteen", "Nineteen", "Twenty"
)

val numberWordsUr = listOf(
    "", "ایک", "دو", "تین", "چار", "پانچ", "چھ", "سات", "آٹھ", "نو", "دس",
    "گیارہ", "بارہ", "تیرہ", "چودہ", "پندرہ", "سولہ", "سترہ", "اٹھارہ", "انیس", "بیس"
)

fun Int.toUrduDigits(): String =
    toString().map { if (it in '0'..'9') '۰' + (it - '0') else it }.joinToString("")

/** Objects per row and emoji size (sp) so counted objects stay BIG for any amount. */
fun countLayout(n: Int): Pair<Int, Int> = when {
    n == 1 -> 1 to 170
    n == 2 -> 2 to 120
    n == 3 -> 3 to 80
    n <= 6 -> 3 to 76
    n <= 10 -> 4 to 54
    n <= 15 -> 5 to 42
    else -> 5 to 36
}

// ---------- English alphabet ----------

data class LetterItem(
    val letter: Char,
    val word: String,
    val emoji: String,
    val urdu: String = "",
    val photo: String? = null,      // drawable name of the full flashcard
    val quizPhoto: String? = null,  // card with the letter/name hidden (or the plain photo)
    val plain: Boolean = false      // photo is a plain picture; the app draws the letter and names
)

val englishAlphabet = listOf(
    LetterItem('A', "Apple", "🍎"), LetterItem('B', "Ball", "⚽"),
    LetterItem('C', "Cat", "🐱"), LetterItem('D', "Dog", "🐶"),
    LetterItem('E', "Elephant", "🐘"), LetterItem('F', "Fish", "🐟"),
    LetterItem('G', "Grapes", "🍇"), LetterItem('H', "Hat", "👒"),
    LetterItem('I', "Ice cream", "🍦"), LetterItem('J', "Juice", "🍹"),
    LetterItem('K', "Key", "🔑"), LetterItem('L', "Lion", "🦁"),
    LetterItem('M', "Moon", "🌙"), LetterItem('N', "Nose", "👃"),
    LetterItem('O', "Orange", "🍊"), LetterItem('P', "Pig", "🐷"),
    LetterItem('Q', "Queen", "👑"), LetterItem('R', "Rabbit", "🐰"),
    LetterItem('S', "Sun", "☀️"), LetterItem('T', "Tree", "🌳"),
    LetterItem('U', "Umbrella", "☂️"), LetterItem('V', "Van", "🚐"),
    LetterItem('W', "Watch", "⌚"), LetterItem('X', "Xylophone", "🎹"),
    LetterItem('Y', "Yacht", "⛵"), LetterItem('Z', "Zebra", "🦓")
)

// ---------- Urdu alphabet ----------

data class UrduLetter(
    val letter: String,
    val name: String,
    val word: String,
    val meaning: String,
    val emoji: String,
    val photo: String? = null       // drawable name of the animal photo
) {
    /** The letter exists but has no common animal/fruit/... in this category. */
    val none: Boolean get() = meaning.startsWith("No common")
}

/** All 40 Urdu letters with their names (words come from the category data). */
val urduAlphabet = listOf(
    UrduLetter("ا", "الف", "", "", ""),
    UrduLetter("آ", "آ", "", "", ""),
    UrduLetter("ب", "بے", "", "", ""),
    UrduLetter("پ", "پے", "", "", ""),
    UrduLetter("ت", "تے", "", "", ""),
    UrduLetter("ٹ", "ٹے", "", "", ""),
    UrduLetter("ث", "ثے", "", "", ""),
    UrduLetter("ج", "جیم", "", "", ""),
    UrduLetter("چ", "چے", "", "", ""),
    UrduLetter("ح", "بڑی حے", "", "", ""),
    UrduLetter("خ", "خے", "", "", ""),
    UrduLetter("د", "دال", "", "", ""),
    UrduLetter("ڈ", "ڈال", "", "", ""),
    UrduLetter("ذ", "ذال", "", "", ""),
    UrduLetter("ر", "رے", "", "", ""),
    UrduLetter("ڑ", "ڑے", "", "", ""),
    UrduLetter("ز", "زے", "", "", ""),
    UrduLetter("ژ", "ژے", "", "", ""),
    UrduLetter("س", "سین", "", "", ""),
    UrduLetter("ش", "شین", "", "", ""),
    UrduLetter("ص", "صاد", "", "", ""),
    UrduLetter("ض", "ضاد", "", "", ""),
    UrduLetter("ط", "طوئے", "", "", ""),
    UrduLetter("ظ", "ظوئے", "", "", ""),
    UrduLetter("ع", "عین", "", "", ""),
    UrduLetter("غ", "غین", "", "", ""),
    UrduLetter("ف", "فے", "", "", ""),
    UrduLetter("ق", "قاف", "", "", ""),
    UrduLetter("ک", "کاف", "", "", ""),
    UrduLetter("گ", "گاف", "", "", ""),
    UrduLetter("ل", "لام", "", "", ""),
    UrduLetter("م", "میم", "", "", ""),
    UrduLetter("ن", "نون", "", "", ""),
    UrduLetter("ں", "نون غنہ", "", "", ""),
    UrduLetter("و", "واؤ", "", "", ""),
    UrduLetter("ہ", "ہے", "", "", ""),
    UrduLetter("ھ", "دو چشمی ہے", "", "", ""),
    UrduLetter("ء", "ہمزہ", "", "", ""),
    UrduLetter("ی", "چھوٹی یے", "", "", ""),
    UrduLetter("ے", "بڑی یے", "", "", "")
)

// ---------- Colors ----------

data class NamedColor(val en: String, val ur: String, val color: Color, val emoji: String = "")

val RedC = NamedColor("Red", "لال", Color(0xFFE53935), "🍎")
val BlueC = NamedColor("Blue", "نیلا", Color(0xFF1E88E5), "🐳")
val YellowC = NamedColor("Yellow", "پیلا", Color(0xFFFDD835), "🍌")
val GreenC = NamedColor("Green", "ہرا", Color(0xFF43A047), "🐸")
val OrangeC = NamedColor("Orange", "نارنجی", Color(0xFFFB8C00), "🍊")
val PurpleC = NamedColor("Purple", "جامنی", Color(0xFF8E24AA), "🍇")
val PinkC = NamedColor("Pink", "گلابی", Color(0xFFF48FB1), "🌸")
val BlackC = NamedColor("Black", "کالا", Color(0xFF212121), "🎩")
val WhiteC = NamedColor("White", "سفید", Color(0xFFFFFFFF), "☁️")
val BrownC = NamedColor("Brown", "بھورا", Color(0xFF795548), "🐻")
val LightBlueC = NamedColor("Light Blue", "ہلکا نیلا", Color(0xFF90CAF9))
val GreyC = NamedColor("Grey", "سلیٹی", Color(0xFF9E9E9E))

val learnColors = listOf(RedC, BlueC, YellowC, GreenC, OrangeC, PurpleC, PinkC, BlackC, WhiteC, BrownC)

val mixPalette = listOf(RedC, BlueC, YellowC, WhiteC, BlackC)

/** Key is the two colors' English names, sorted. */
val mixResults: Map<Set<String>, NamedColor> = mapOf(
    setOf("Red", "Yellow") to OrangeC,
    setOf("Blue", "Yellow") to GreenC,
    setOf("Red", "Blue") to PurpleC,
    setOf("Red", "White") to PinkC,
    setOf("Blue", "White") to LightBlueC,
    setOf("Black", "White") to GreyC
)

// ---------- Category alphabets ----------
// Only the Animals category has content so far (from the supplied PDFs).
// Other categories stay empty ("coming soon") until their pictures are added: nothing is borrowed.

fun englishAlphabetFor(category: Category): List<LetterItem> = when (category) {
    Category.ANIMALS -> animalLetters
    Category.FRUITS -> fruitLetters
    else -> emptyList()
}

fun urduAlphabetFor(category: Category): List<UrduLetter> = when (category) {
    Category.ANIMALS -> animalUrdu
    Category.FRUITS -> fruitUrdu
    else -> emptyList()
}

/** Numbers 1-20 pictures for a category, or null while that category has no pictures yet. */
fun numberItemsFor(category: Category): List<NumberItem>? = when (category) {
    Category.ANIMALS -> animalNumbers
    Category.FRUITS -> fruitNumbers
    else -> null
}

/** Urdu text shown for a letter that has nothing in the category. */
val Category.noneUrdu: String
    get() = when (this) {
        Category.ANIMALS -> "اس حرف سے عام جانور نہیں"
        Category.FRUITS -> "اس حرف سے عام پھل نہیں"
        else -> "اس حرف سے کچھ نہیں"
    }

// ---------- ANIMALS: data taken from the supplied PDFs ----------

/** "A to Z Animals" flashcards. */
val animalLetters: List<LetterItem> = listOf(
    "A|Alligator|ایلیگیٹر", "B|Bear|ریچھ", "C|Camel|اونٹ", "D|Donkey|گدھا", "E|Elephant|ہاتھی",
    "F|Fox|لومڑی", "G|Giraffe|زرافہ", "H|Horse|گھوڑا", "I|Iguana|اگوانا", "J|Jaguar|جگوار",
    "K|Kangaroo|کینگرو", "L|Lion|شیر", "M|Monkey|بندر", "N|Narwhal|ناروال", "O|Owl|الو",
    "P|Panda|پانڈا", "Q|Quail|بٹیر", "R|Raccoon|راکون", "S|Squirrel|گلہری", "T|Tiger|ببر",
    "U|Unicorn|یونیکورن", "V|Vulture|گدھ", "W|Wolf|بھیڑیا", "X|Xerus|زیرس", "Y|Yak|یاک", "Z|Zebra|زیبرا"
).map { line ->
    val p = line.split("|")
    val l = p[0][0]
    LetterItem(l, p[1], "", p[2], "abc_${l.lowercaseChar()}", "abcq_${l.lowercaseChar()}")
}

/** "Urdu Animals: Alif to Ye" cards. Fields: letter|name|word|English|photo|emoji (used only when no photo exists). */
val animalUrdu: List<UrduLetter> = listOf(
    "ا|الف|اژدہا|Dragon|ur_01|", "آ|آ|آکٹوپس|Octopus||", "ب|بے|بکری|Goat|ur_03|",
    "پ|پے|پانڈا|Panda|ur_04|", "ت|تے|تیتر|Partridge|ur_05|", "ٹ|ٹے|ٹٹو|Pony|ur_06|",
    "ث|ثے||No common animal||", "ج|جیم|جگوار|Jaguar|ur_08|", "چ|چے|چیتا|Cheetah|ur_09|",
    "ح|بڑی حے|حشرات|Insects||", "خ|خے|خرگوش|Rabbit|ur_11|", "د|دال|دنبہ|Ram||",
    "ڈ|ڈال|ڈولفن|Dolphin||", "ذ|ذال||No common animal||", "ر|رے|ریچھ|Bear|ur_15|",
    "ڑ|ڑے||No common animal||", "ز|زے|زیبرا|Zebra|ur_17|", "ژ|ژے||No common animal||",
    "س|سین|سانپ|Snake|ur_19|", "ش|شین|شیر|Lion|ur_20|", "ص|صاد|صدف|Shellfish||",
    "ض|ضاد||No common animal||", "ط|طوئے|طوطا|Parrot||", "ظ|ظوئے||No common animal||",
    "ع|عین|عقاب|Eagle|ur_25|", "غ|غین|غزال|Gazelle||", "ف|فے|فاختہ|Dove||",
    "ق|قاف|قاقم|Ermine||", "ک|کاف|کبوتر|Pigeon||", "گ|گاف|گدھا|Donkey|ur_30|",
    "ل|لام|لومڑی|Fox|ur_31|", "م|میم|مور|Peacock|ur_32|", "ن|نون|نیولا|Mongoose||",
    "ں|نون غنہ||No common animal||", "و|واؤ|وہیل|Whale||", "ہ|ہے|ہاتھی|Elephant|ur_36|",
    "ھ|دو چشمی ہے||No common animal||", "ء|ہمزہ||No common animal||", "ی|چھوٹی یے|یاک|Yak||",
    "ے|بڑی یے||No common animal||"
).map { line ->
    val p = line.split("|")
    UrduLetter(p[0], p[1], p[2], p[3], p[5], p[4].ifBlank { null })
}

/** "Animals Flashcards: Numbers 1-20": number N is shown with the Nth animal. */
class NumberItem(val en: String, val ur: String, val photo: String)

val animalNumbers: List<NumberItem> = listOf(
    "Lion|شیر", "Tiger|باگھ", "Elephant|ہاتھی", "Leopard|چیتا", "Zebra|زیبرا",
    "Giraffe|زرافہ", "Cow|گائے", "Buffalo|بھینس", "Goat|بکری", "Sheep|بھیڑ",
    "Horse|گھوڑا", "Donkey|گدھا", "Camel|اونٹ", "Kangaroo|کینگرو", "Panda|پانڈا",
    "Bear|ریچھ", "Wolf|بھیڑیا", "Fox|لومڑی", "Squirrel|گلہری", "Raccoon|راکون"
).mapIndexed { i, line ->
    val p = line.split("|")
    NumberItem(p[0], p[1], "num_%02d".format(i + 1))
}


// ---------- FRUITS: from the supplied fruit photo sheets ----------

/** Letter|Fruit|Urdu name|photo */
val fruitLetters: List<LetterItem> = listOf(
    "A|Apple|سیب|apple", "B|Banana|کیلا|banana", "C|Cherry|چیری|cherry", "D|Dates|کھجور|dates",
    "E|Elderberry|ایلڈر بیری|elderberry", "F|Fig|انجیر|fig", "G|Grapes|انگور|grapes",
    "H|Honeydew melon|ہنی ڈیو خربوزہ|honeydew", "I|Indian gooseberry|آملہ|amla",
    "J|Jackfruit|کٹھل|jackfruit", "K|Kiwi|کیوی|kiwi", "L|Lemon|لیموں|lemon", "M|Mango|آم|mango",
    "N|Nectarine|نیکٹرین|nectarine", "O|Orange|مالٹا|orange", "P|Pineapple|انناس|pineapple",
    "Q|Quince|بہی|quince", "R|Raspberry|رس بھری|raspberry", "S|Strawberry|سٹرابیری|strawberry",
    "T|Tangerine|ٹینجرین|tangerine", "U|Ugli fruit|اگلی فروٹ|ugli", "V|Velvet apple|مخملی سیب|velvetapple",
    "W|Watermelon|تربوز|watermelon", "X|Ximenia|زائمینیا|ximenia", "Y|Yuzu|یوزو|yuzu",
    "Z|Ziziphus (Ber)|بیر|ber"
).map { line ->
    val p = line.split("|")
    LetterItem(p[0][0], p[1], "", p[2], "fr_${p[3]}", "fr_${p[3]}", plain = true)
}

/** Urdu letter -> (word, English, photo). Letters not listed show "no common fruit". */
private val fruitUrduWords: Map<String, Triple<String, String, String>> = mapOf(
    "آ" to Triple("آم", "Mango", "fr_mango"),
    "ا" to Triple("انار", "Pomegranate", "fr_pomegranate"),
    "ب" to Triple("بیر", "Ber (Jujube)", "fr_ber"),
    "پ" to Triple("پپیتا", "Papaya", "fr_papaya"),
    "ت" to Triple("تربوز", "Watermelon", "fr_watermelon"),
    "ٹ" to Triple("ٹینجرین", "Tangerine", "fr_tangerine"),
    "ج" to Triple("جامن", "Jamun", "fr_jamun"),
    "چ" to Triple("چیکو", "Chikoo", "fr_chikoo"),
    "خ" to Triple("خوبانی", "Apricot", "fr_apricot"),
    "ڈ" to Triple("ڈریگن فروٹ", "Dragon fruit", "fr_dragonfruit"),
    "ر" to Triple("رس بھری", "Raspberry", "fr_raspberry"),
    "ز" to Triple("زیتون", "Olive", "fr_olive"),
    "س" to Triple("سیب", "Apple", "fr_apple"),
    "ش" to Triple("شہتوت", "Mulberry", "fr_mulberry"),
    "ف" to Triple("فالسہ", "Falsa", "fr_falsa"),
    "ک" to Triple("کیلا", "Banana", "fr_banana"),
    "گ" to Triple("گریپ فروٹ", "Grapefruit", "fr_grapefruit"),
    "ل" to Triple("لیموں", "Lemon", "fr_lemon"),
    "م" to Triple("مالٹا", "Orange", "fr_orange"),
    "ن" to Triple("ناشپاتی", "Pear", "fr_pear"),
    "ی" to Triple("یوسف افندی", "Mandarin", "fr_tangerine")
)

val fruitUrdu: List<UrduLetter> = urduAlphabet.map { base ->
    val w = fruitUrduWords[base.letter]
    if (w != null) UrduLetter(base.letter, base.name, w.first, w.second, "", w.third)
    else UrduLetter(base.letter, base.name, "", "No common fruit", "", null)
}

val fruitNumbers: List<NumberItem> = listOf(
    "Apple|سیب|apple", "Banana|کیلا|banana", "Orange|مالٹا|orange", "Mango|آم|mango",
    "Grapes|انگور|grapes", "Strawberry|سٹرابیری|strawberry", "Watermelon|تربوز|watermelon",
    "Pineapple|انناس|pineapple", "Cherry|چیری|cherry", "Pear|ناشپاتی|pear", "Peach|آڑو|peach",
    "Lemon|لیموں|lemon", "Kiwi|کیوی|kiwi", "Pomegranate|انار|pomegranate", "Papaya|پپیتا|papaya",
    "Coconut|ناریل|coconut", "Plum|آلو بخارا|plum", "Apricot|خوبانی|apricot", "Melon|خربوزہ|melon",
    "Guava|امرود|guava"
).map { line ->
    val p = line.split("|")
    NumberItem(p[0], p[1], "fr_${p[2]}")
}
