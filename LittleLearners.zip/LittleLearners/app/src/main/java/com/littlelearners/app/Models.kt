package com.littlelearners.app

import androidx.compose.ui.graphics.Color

/** The six learning categories. Content in later phases is keyed off this. */
enum class Category(val label: String, val emoji: String, val color: Color) {
    ANIMALS("Animals", "🐾", Color(0xFFFFB74D)),
    BIRDS("Birds", "🐦", Color(0xFF90CAF9)),
    INSECTS("Insects", "🐞", Color(0xFFFFF176)),
    SEA("Sea Creatures", "🐠", Color(0xFF4FC3F7)),
    VEGETABLES("Vegetables", "🥕", Color(0xFF81C784)),
    FRUITS("Fruits", "🍎", Color(0xFFE57373)),
    THINGS("Things", "🧸", Color(0xFFBCAAA4)),
    VEHICLES("Vehicles", "🚗", Color(0xFFEF9A9A)),
    BODY("Body Parts", "🖐️", Color(0xFFFFCCBC)),
    SHAPES("Shapes", "🔷", Color(0xFF9FA8DA)),
    NATURE("Nature", "🌳", Color(0xFF66BB6A)),
    WEATHER("Weather", "⛅", Color(0xFF80DEEA)),
    COLORS("Colors", "🌈", Color(0xFFBA68C8));

    companion object {
        val default = ANIMALS
        fun fromName(name: String?): Category =
            entries.firstOrNull { it.name == name } ?: default
    }
}

/** Home screen tiles. `phase` says which development phase implements the module. */
enum class LearningModule(
    val title: String,
    val subtitle: String,
    val emoji: String,
    val color: Color,
    val phase: Int
) {
    NUMBERS("Numbers 123", "Learn, Count, Trace & Quiz", "🔢", Color(0xFFFFCDD2), 2),
    FUN_GAMES("Fun Games", "Sort, Find, Pop & Join", "🎈", Color(0xFFFFCCBC), 5),
    MATH("Math", "Count, Add & Compare", "➕", Color(0xFFFFE0B2), 5),
    ENGLISH_ABC("English ABC", "Letters, Words & Tracing", "🔤", Color(0xFFBBDEFB), 2),
    URDU("Urdu Alphabet", "حروف اور تلفظ", "ا ب پ", Color(0xFFC8E6C9), 2),
    LEARNING_LIST("Learning List", "All words, tap to hear", "📋", Color(0xFFB2DFDB), 2),
    TRACING("Tracing Center", "Trace Numbers, Letters & Urdu", "✍️", Color(0xFFD1C4E9), 3),
    DRAWING("Drawing Studio", "Draw Freely", "🖍️", Color(0xFFF8BBD0), 3),
    COLORING("Coloring Book", "Color & Save", "🎨", Color(0xFFDCEDC8), 3),
    COLORS_LEARNING("Colors Learning", "Learn, Match & Mix", "🔴", Color(0xFFE1BEE7), 2),
    MINI_GAMES("Mini-Games", "Memory, Puzzle, Quiz & More", "🧩", Color(0xFFFFF59D), 4),
    WORLDS("Interactive Worlds", "Explore Animal, Fruit & More", "🦒", Color(0xFFFFCC80), 5),
    STORIES("Stories", "Read & Listen", "📖", Color(0xFFB3E5FC), 5),
    WORD_BUILD("Make Words", "Build words from letters", "🔠", Color(0xFFB3E5FC), 5),
    CALENDAR("Days & Months", "Week, months & today", "📅", Color(0xFFFFE0B2), 5),
    CLOCK("Learn the Clock", "Hours, half hours & quiz", "⏰", Color(0xFFC5CAE9), 5),
    MONEY("Rupees", "Coins, notes & shop", "💰", Color(0xFFC8E6C9), 5),
    SPOT_DIFF("Spot the Difference", "Find 3 differences", "🔍", Color(0xFFF8BBD0), 5),
    SEQUENCE("What Comes Next?", "Put it in order", "➡️", Color(0xFFB2DFDB), 5),
    STORY_MAKER("Make a Story", "Pick 3 pictures", "✍️", Color(0xFFE1BEE7), 5),
    VOCAB("Vocabulary", "Family, Home, Food & more", "📚", Color(0xFFFFE0B2), 5),
    HABITS("Habits & Sounds", "Daily routines, guess the sound", "🧼", Color(0xFFB2EBF2), 5),
    ISLAMIC("Islamic Learning", "Duas, Names & Basics", "🕌", Color(0xFFC8E6C9), 5),
    RHYMES("Rhymes & Lullabies", "Sing along & sleep", "🎶", Color(0xFFD1C4E9), 5),
    MUSIC("Music & Movement", "Dance & Enjoy", "🎵", Color(0xFFFFE0B2), 5),
    STICKERS("Sticker Book", "Collect Stickers", "⭐", Color(0xFFE8EAF6), 5),
    ANIMAL_SOUNDS("Animal Sounds", "Hear & Learn", "🐘", Color(0xFFC5E1A5), 5),
    PUZZLES("Puzzles", "Complete the Puzzle", "🦁", Color(0xFFF48FB1), 4),
    MATCHING("Matching Games", "Match & Learn", "🐄", Color(0xFF81D4FA), 4),
    QUIZZES("Quizzes", "Choose the Correct Answer", "❓", Color(0xFFE6EE9C), 4),
    COLOR_MIXING("Color Mixing", "Mix Colors", "🧪", Color(0xFFF8BBD0), 2),
    ANIMAL_CARE("Animal Care", "Take Care of Animals", "🐶", Color(0xFFFFE082), 4);
}
