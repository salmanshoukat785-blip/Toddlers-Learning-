package com.littlelearners.app.ui

import android.content.Context
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val idCache = HashMap<String, Int>()

/** Drawable id of the 3D picture for one emoji (res/drawable-nodpi/e_<hex>.png), or 0. */
private fun emojiRes(ctx: Context, hex: String): Int =
    idCache.getOrPut(hex) { ctx.resources.getIdentifier("e_$hex", "drawable", ctx.packageName) }

/** Splits e.g. "🐶🐶\n🐶" into rows of drawable ids. Null if any piece has no 3D picture. */
private fun emojiRows(ctx: Context, text: String): List<List<Int>>? {
    val rows = mutableListOf<MutableList<Int>>(mutableListOf())
    var i = 0
    while (i < text.length) {
        val cp = text.codePointAt(i)
        i += Character.charCount(cp)
        when (cp) {
            0xFE0F -> Unit
            '\n'.code -> rows.add(mutableListOf())
            else -> {
                val id = emojiRes(ctx, Integer.toHexString(cp))
                if (id == 0) return null
                rows.last().add(id)
            }
        }
    }
    val out = rows.filter { it.isNotEmpty() }
    return if (out.isEmpty()) null else out
}

/**
 * Shows emoji as big 3D pictures when they were downloaded at build time,
 * otherwise as ordinary (shadowed) text emoji. [sizeSp] is the picture size.
 */
@Composable
fun EmojiView(text: String, sizeSp: Int, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val rows = remember(text) { emojiRows(ctx, text) }
    if (rows == null) {
        Text(
            text,
            style = EmojiShadow,
            fontSize = sizeSp.sp,
            lineHeight = (sizeSp * 1.25f).sp,
            textAlign = TextAlign.Center,
            modifier = modifier
        )
    } else {
        Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
            rows.forEach { row ->
                Row {
                    row.forEach { id ->
                        Image(
                            painter = painterResource(id),
                            contentDescription = null,
                            modifier = Modifier.size((sizeSp * 1.1f).dp)
                        )
                    }
                }
            }
        }
    }
}
