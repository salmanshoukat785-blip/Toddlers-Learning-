@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.littlelearners.app.ui

import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.littlelearners.app.Category
import com.littlelearners.app.rememberSpeaker

private val mathEmoji = listOf("🍎", "⭐", "🐟", "🎈", "🍓", "🚗", "🐥", "🌸")

private fun dots(n: Int, e: String) = e.repeat(n)

/** Three number choices: the right one plus two different wrong ones inside lo..hi. Returns options and index of the right one. */
private fun numberChoices(correct: Int, lo: Int, hi: Int): Pair<List<Option>, Int> {
    val wrong = (lo..hi).filter { it != correct }.shuffled().take(2)
    val all = (wrong + correct).shuffled()
    return all.map { Option("$it") } to all.indexOf(correct)
}

/** Math for toddlers: counting, adding, subtracting, more/less and number order. Uses photos already in the app. */
@Composable
fun MathScreen(onBack: () -> Unit) {
    val accent = Color(0xFFFFB74D)
    val speaker = rememberSpeaker()
    var tab by remember { mutableStateOf(0) }
    val pool = remember {
        listOf(Category.FRUITS, Category.ANIMALS, Category.VEHICLES, Category.BIRDS)
            .flatMap { gameItems(it) }
    }

    ScreenScaffold("Math 🔢", accent, onBack) {
        TabsBar(listOf("Count", "Add", "Take away", "More?", "Order"), tab, accent) { tab = it }
        Spacer(Modifier.height(10.dp))
        when (tab) {
            0 -> QuizView(accent, speaker, "Math") {
                List(5) {
                    val n = (1..10).random()
                    val item = pool.random()
                    val (opts, c) = numberChoices(n, 1, 10)
                    Question(
                        prompt = "How many?",
                        big = "",
                        options = opts,
                        correct = c,
                        say = "How many ${item.en}?",
                        photo = item.photo,
                        photoCount = n
                    )
                }
            }
            1 -> QuizView(accent, speaker, "Math") {
                List(5) {
                    val a = (1..5).random()
                    val b = (1..5).random()
                    val e = mathEmoji.random()
                    val (opts, c) = numberChoices(a + b, 2, 10)
                    Question(
                        prompt = "$a + $b = ?",
                        big = "${dots(a, e)}\n+\n${dots(b, e)}",
                        bigSize = 30,
                        options = opts,
                        correct = c,
                        say = "$a plus $b equals?"
                    )
                }
            }
            2 -> QuizView(accent, speaker, "Math") {
                List(5) {
                    val a = (2..9).random()
                    val b = (1 until a).random()
                    val e = mathEmoji.random()
                    val (opts, c) = numberChoices(a - b, 0, 9)
                    Question(
                        prompt = "$a - $b = ?",
                        big = "${dots(a, e)}\n− $b",
                        bigSize = 30,
                        options = opts,
                        correct = c,
                        say = "$a take away $b equals?"
                    )
                }
            }
            3 -> QuizView(accent, speaker, "Math") {
                List(5) {
                    val more = (0..1).random() == 0
                    val x = (1..9).random()
                    var y = (1..9).random()
                    while (y == x) y = (1..9).random()
                    val e = mathEmoji.random()
                    val opts = listOf(Option(dots(x, e)), Option(dots(y, e)))
                    val correct = if (more) (if (x > y) 0 else 1) else (if (x < y) 0 else 1)
                    Question(
                        prompt = if (more) "Which has MORE?" else "Which has LESS?",
                        big = "👆",
                        options = opts,
                        correct = correct,
                        say = if (more) "Which has more?" else "Which has less?"
                    )
                }
            }
            else -> QuizView(accent, speaker, "Math") {
                List(5) {
                    when ((0..2).random()) {
                        0 -> {
                            val n = (1..9).random()
                            val (opts, c) = numberChoices(n + 1, 2, 10)
                            Question("What comes after $n?", "$n , ?", opts, c, say = "What comes after $n?")
                        }
                        1 -> {
                            val n = (2..10).random()
                            val (opts, c) = numberChoices(n - 1, 1, 9)
                            Question("What comes before $n?", "? , $n", opts, c, say = "What comes before $n?")
                        }
                        else -> {
                            val n = (2..9).random()
                            val (opts, c) = numberChoices(n, 1, 10)
                            Question("Which number is missing?", "${n - 1} , ? , ${n + 1}", opts, c, say = "Which number is missing?")
                        }
                    }
                }
            }
        }
    }
}
