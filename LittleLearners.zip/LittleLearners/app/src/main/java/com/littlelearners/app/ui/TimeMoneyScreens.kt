@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.littlelearners.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.littlelearners.app.ParentStore
import com.littlelearners.app.Rewards
import com.littlelearners.app.Speaker
import com.littlelearners.app.UrduLocale
import com.littlelearners.app.rememberSpeaker
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

// ------------------------------------------------------------------ shared: a quiz whose question is drawn

private class VQ(val prompt: String, val say: String, val options: List<String>, val correct: Int, val draw: @Composable () -> Unit)

/** Like QuizView, but each question draws its own picture (a clock, a pile of money ...). */
@Composable
private fun VisualQuiz(accent: Color, speaker: Speaker, area: String, newRound: () -> List<VQ>) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var round by remember { mutableStateOf(0) }
    val qs = remember(round) { newRound() }
    var index by remember(round) { mutableStateOf(0) }
    var score by remember(round) { mutableStateOf(0) }
    var missed by remember(round, index) { mutableStateOf(false) }
    var locked by remember(round, index) { mutableStateOf(false) }
    var msg by remember(round, index) { mutableStateOf("") }

    if (index >= qs.size) {
        LaunchedEffect(round) { Rewards.add(ctx, score) }
        Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text("🎉", fontSize = 70.sp)
            Text("Score: $score / ${qs.size}  ⭐ +$score", fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(16.dp))
            Button(onClick = { round++ }) { Text("Play again 🔁") }
        }
        return
    }
    val q = qs[index]
    LaunchedEffect(round, index) { speaker.say(q.say) }
    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Question ${index + 1} / ${qs.size}", fontSize = 14.sp, color = Color.Gray)
        Text(q.prompt, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center)
        Spacer(Modifier.height(10.dp))
        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) { q.draw() }
        Text(msg, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.height(28.dp))
        Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            q.options.forEachIndexed { i, label ->
                Card(
                    onClick = {
                        if (locked) return@Card
                        if (i == q.correct) {
                            locked = true
                            if (!missed) { score++; ParentStore.recordAnswer(ctx, area, true) }
                            msg = "🌟 Great!"
                            scope.launch { delay(800); index++ }
                        } else {
                            if (!missed) ParentStore.recordAnswer(ctx, area, false)
                            missed = true
                            msg = "Try again 🙂"
                        }
                    },
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(3.dp, accent),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.weight(1f).height(84.dp)
                ) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(label, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center)
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ Clock

@Composable
private fun AnalogClock(hour: Int, minute: Int, dp: Dp) {
    Canvas(Modifier.size(dp)) {
        val r = minOf(size.width, size.height) / 2f
        val c = Offset(size.width / 2f, size.height / 2f)
        drawCircle(Color.White, radius = r)
        drawCircle(Color(0xFF5C6BC0), radius = r - 5f, style = Stroke(width = 10f))
        drawIntoCanvas { canvas ->
            val p = android.graphics.Paint().apply {
                isAntiAlias = true
                textAlign = android.graphics.Paint.Align.CENTER
                textSize = r * 0.22f
                color = 0xFF333333.toInt()
                isFakeBoldText = true
            }
            for (n in 1..12) {
                val a = n * 30 * PI / 180
                val x = c.x + (sin(a) * r * 0.78).toFloat()
                val y = c.y - (cos(a) * r * 0.78).toFloat() + p.textSize / 3f
                canvas.nativeCanvas.drawText("$n", x, y, p)
            }
        }
        val ma = (minute * 6) * PI / 180
        val ha = ((hour % 12) * 30 + minute * 0.5) * PI / 180
        drawLine(Color(0xFF212121), c, Offset(c.x + (sin(ha) * r * 0.5).toFloat(), c.y - (cos(ha) * r * 0.5).toFloat()),
            strokeWidth = 16f, cap = StrokeCap.Round)
        drawLine(Color(0xFFE53935), c, Offset(c.x + (sin(ma) * r * 0.72).toFloat(), c.y - (cos(ma) * r * 0.72).toFloat()),
            strokeWidth = 10f, cap = StrokeCap.Round)
        drawCircle(Color(0xFF212121), radius = 10f, center = c)
    }
}

private fun timePhrase(h: Int, m: Int): String = when (m) {
    0 -> "$h o'clock"
    15 -> "quarter past $h"
    30 -> "half past $h"
    45 -> "quarter to ${h % 12 + 1}"
    else -> "$h:${m.toString().padStart(2, '0')}"
}

private fun digital(h: Int, m: Int) = "$h:${m.toString().padStart(2, '0')}"

@Composable
fun ClockScreen(onBack: () -> Unit) {
    val accent = Color(0xFF9FA8DA)
    val speaker = rememberSpeaker()
    var tab by remember { mutableStateOf(0) }
    var hour by remember { mutableStateOf(3) }
    var minute by remember { mutableStateOf(0) }

    ScreenScaffold("Learn the Clock ⏰", accent, onBack) {
        TabsBar(listOf("Learn", "Quiz"), tab, accent) { tab = it }
        Spacer(Modifier.height(8.dp))
        if (tab == 0) {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), horizontalAlignment = Alignment.CenterHorizontally) {
                AnalogClock(hour, minute, 250.dp)
                Spacer(Modifier.height(8.dp))
                Text(digital(hour, minute), fontSize = 44.sp, fontWeight = FontWeight.ExtraBold)
                Text("It is ${timePhrase(hour, minute)}", fontSize = 20.sp, textAlign = TextAlign.Center)
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedButton(onClick = { hour = if (hour == 1) 12 else hour - 1; speaker.say("It is ${timePhrase(hour, minute)}") }) { Text("◀ Hour") }
                    OutlinedButton(onClick = { hour = if (hour == 12) 1 else hour + 1; speaker.say("It is ${timePhrase(hour, minute)}") }) { Text("Hour ▶") }
                }
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(0, 15, 30, 45).forEach { m ->
                        if (m == minute) Button(onClick = {}) { Text(":${m.toString().padStart(2, '0')}") }
                        else OutlinedButton(onClick = { minute = m; speaker.say("It is ${timePhrase(hour, minute)}") }) { Text(":${m.toString().padStart(2, '0')}") }
                    }
                }
                Spacer(Modifier.height(6.dp))
                OutlinedButton(onClick = { speaker.say("It is ${timePhrase(hour, minute)}") }) { Text("🔊 Say the time") }
            }
        } else {
            VisualQuiz(accent, speaker, "Clock") {
                List(5) {
                    val h = (1..12).random()
                    val m = listOf(0, 30).random()
                    val right = digital(h, m)
                    val wrong = mutableSetOf<String>()
                    while (wrong.size < 2) {
                        val s = digital((1..12).random(), listOf(0, 30).random())
                        if (s != right) wrong.add(s)
                    }
                    val opts = (wrong.toList() + right).shuffled()
                    VQ("What time is it?", "What time is it?", opts, opts.indexOf(right)) { AnalogClock(h, m, 220.dp) }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ Rupees

private class Denom(val value: Int, val en: String, val ur: String)

private val denoms = listOf(
    Denom(1, "One rupee", "ایک روپیہ"), Denom(2, "Two rupees", "دو روپے"), Denom(5, "Five rupees", "پانچ روپے"),
    Denom(10, "Ten rupees", "دس روپے"), Denom(20, "Twenty rupees", "بیس روپے"), Denom(50, "Fifty rupees", "پچاس روپے"),
    Denom(100, "One hundred rupees", "سو روپے"), Denom(500, "Five hundred rupees", "پانچ سو روپے"),
    Denom(1000, "One thousand rupees", "ایک ہزار روپے")
)

private fun moneyColor(v: Int): Color = when (v) {
    1 -> Color(0xFFB0BEC5); 2 -> Color(0xFFCFD8DC); 5 -> Color(0xFFFFD54F)
    10 -> Color(0xFFA5D6A7); 20 -> Color(0xFFFFCC80); 50 -> Color(0xFFCE93D8)
    100 -> Color(0xFFEF9A9A); 500 -> Color(0xFF90CAF9); else -> Color(0xFFB39DDB)
}

/** Simple toy money (coins up to 5, notes from 10). It is only a drawing, not a copy of real currency. */
@Composable
private fun Money(value: Int, scale: Float = 1f) {
    if (value <= 5) {
        Box(
            Modifier.size((54 * scale).dp).clip(CircleShape).background(moneyColor(value)),
            contentAlignment = Alignment.Center
        ) { Text("$value", fontSize = (22 * scale).sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF424242)) }
    } else {
        Box(
            Modifier.size(width = (92 * scale).dp, height = (52 * scale).dp).clip(RoundedCornerShape(8.dp)).background(moneyColor(value)),
            contentAlignment = Alignment.Center
        ) { Text("Rs $value", fontSize = (18 * scale).sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF424242)) }
    }
}

private class ShopItem(val emoji: String, val name: String, val price: Int)

private val shopItems = listOf(
    ShopItem("🍬", "Candy", 5), ShopItem("🍪", "Biscuit", 10), ShopItem("✏️", "Pencil", 10), ShopItem("🎈", "Balloon", 15),
    ShopItem("🍎", "Apple", 20), ShopItem("🍦", "Ice cream", 30), ShopItem("🥛", "Milk", 50), ShopItem("🧸", "Toy", 100)
)

@Composable
fun MoneyScreen(onBack: () -> Unit) {
    val accent = Color(0xFFA5D6A7)
    val ctx = LocalContext.current
    val speaker = rememberSpeaker()
    var tab by remember { mutableStateOf(0) }

    ScreenScaffold("Rupees 💰", accent, onBack) {
        TabsBar(listOf("Learn", "Count", "Shop"), tab, accent) { tab = it }
        Spacer(Modifier.height(8.dp))
        when (tab) {
            0 -> {
                Text("Tap to hear 🔊", fontSize = 14.sp, color = Color.Gray, modifier = Modifier.align(Alignment.CenterHorizontally))
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(denoms) { d ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = BorderStroke(2.dp, accent),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Box(Modifier.clickable { speaker.say(d.en) }.padding(6.dp)) { Money(d.value, 1.2f) }
                                Text(d.en, fontSize = 15.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center,
                                    modifier = Modifier.clickable { speaker.say(d.en) }.padding(4.dp))
                                Text(d.ur, fontSize = 18.sp, modifier = Modifier.clickable { speaker.say(d.ur, UrduLocale) }.padding(4.dp))
                            }
                        }
                    }
                }
            }
            1 -> VisualQuiz(accent, speaker, "Money") {
                List(5) {
                    val pieces = List((2..4).random()) { listOf(1, 2, 5, 10, 20, 50).random() }
                    val total = pieces.sum()
                    val wrong = mutableSetOf<Int>()
                    while (wrong.size < 2) {
                        val w = (total + listOf(-10, -5, -2, -1, 1, 2, 5, 10).random()).coerceAtLeast(1)
                        if (w != total) wrong.add(w)
                    }
                    val opts = (wrong.toList() + total).shuffled()
                    VQ("How much money is this?", "How much money is this?", opts.map { "Rs $it" }, opts.indexOf(total)) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            pieces.chunked(2).forEach { row ->
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                    row.forEach { Money(it, 1.2f) }
                                }
                            }
                        }
                    }
                }
            }
            else -> ShopGame(accent, speaker) { Rewards.add(ctx, 2) }
        }
    }
}

@Composable
private fun ShopGame(accent: Color, speaker: Speaker, onWin: () -> Unit) {
    var round by remember { mutableStateOf(0) }
    val item = remember(round) { shopItems.random() }
    var paid by remember(round) { mutableStateOf(0) }
    var msg by remember(round) { mutableStateOf("Pay the exact price") }
    val done = paid == item.price
    LaunchedEffect(done, round) { if (done) { onWin(); speaker.say("Thank you!") } }

    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(item.emoji, fontSize = 80.sp)
        Text("${item.name}: Rs ${item.price}", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
        Text("You paid: Rs $paid", fontSize = 20.sp)
        Spacer(Modifier.height(4.dp))
        Text(if (done) "🎉 Thank you! +2 ⭐" else msg, fontSize = 18.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        Spacer(Modifier.height(12.dp))
        if (!done) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(listOf(1, 2, 5), listOf(10, 20, 50)).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        row.forEach { v ->
                            Box(Modifier.clickable {
                                paid += v
                                speaker.say("$v")
                                if (paid > item.price) { msg = "Too much! Let us try again"; paid = 0 }
                                else msg = "Keep going"
                            }) { Money(v, 1.2f) }
                        }
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            OutlinedButton(onClick = { paid = 0; msg = "Pay the exact price" }) { Text("↩ Start again") }
        } else {
            Button(onClick = { round++ }) { Text("Next item ▶") }
        }
    }
}
