@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.littlelearners.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.littlelearners.app.ParentStore
import com.littlelearners.app.Rewards
import com.littlelearners.app.rememberSpeaker

private class Pair2(val aEmoji: String, val aName: String, val bEmoji: String, val bName: String)

private val goTogether = listOf(
    Pair2("🔑", "Key", "🔒", "Lock"),
    Pair2("👟", "Shoe", "🧦", "Sock"),
    Pair2("🪥", "Toothbrush", "🦷", "Tooth"),
    Pair2("🐝", "Bee", "🌸", "Flower"),
    Pair2("🐰", "Rabbit", "🥕", "Carrot"),
    Pair2("🐒", "Monkey", "🍌", "Banana"),
    Pair2("🐶", "Dog", "🦴", "Bone"),
    Pair2("🐭", "Mouse", "🧀", "Cheese"),
    Pair2("☂️", "Umbrella", "🌧️", "Rain"),
    Pair2("🌙", "Moon", "⭐", "Star"),
    Pair2("🐄", "Cow", "🥛", "Milk"),
    Pair2("🐔", "Hen", "🥚", "Egg"),
    Pair2("🐟", "Fish", "🎣", "Fishing rod"),
    Pair2("✏️", "Pencil", "📓", "Notebook"),
    Pair2("🍞", "Bread", "🧈", "Butter"),
    Pair2("🚗", "Car", "🛣️", "Road")
)

/** Things That Go Together: tap a picture on the left, then the one that belongs with it on the right. */
@Composable
fun PairsScreen(onBack: () -> Unit) {
    val accent = Color(0xFFFFCC80)
    val ctx = LocalContext.current
    val speaker = rememberSpeaker()
    val count = if (ParentStore.easy(ctx)) 3 else 4
    var round by remember { mutableStateOf(0) }
    val pairs = remember(round, count) { goTogether.shuffled().take(count) }
    val leftOrder = remember(round, count) { pairs.indices.shuffled() }
    val rightOrder = remember(round, count) { pairs.indices.shuffled() }
    var selected by remember(round) { mutableStateOf(-1) }
    var done by remember(round) { mutableStateOf(setOf<Int>()) }
    var msg by remember(round) { mutableStateOf("Tap a picture on the left, then what goes with it") }
    val won = done.size == count
    LaunchedEffect(won, round) { if (won) { Rewards.add(ctx, 2); speaker.say("Well done!") } }

    ScreenScaffold("Go Together 🔑", accent, onBack) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(if (won) "🎉 All matched! +2 ⭐" else msg, fontSize = 18.sp, fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    leftOrder.forEach { i ->
                        val p = pairs[i]
                        val isDone = i in done
                        Card(
                            onClick = { if (!isDone) { selected = i; speaker.say(p.aName); msg = "${p.aName} goes with ...?" } },
                            colors = CardDefaults.cardColors(containerColor = when { isDone -> Color(0xFFC8E6C9); selected == i -> Color(0xFFFFF59D); else -> Color.White }),
                            border = BorderStroke(3.dp, accent),
                            shape = RoundedCornerShape(18.dp),
                            modifier = Modifier.fillMaxWidth().height(110.dp)
                        ) {
                            Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                                EmojiView(p.aEmoji, 48)
                                Text(p.aName, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    rightOrder.forEach { j ->
                        val p = pairs[j]
                        val isDone = j in done
                        Card(
                            onClick = {
                                if (!isDone) {
                                    if (selected < 0) msg = "Tap a picture on the left first"
                                    else if (selected == j) {
                                        done = done + j; selected = -1
                                        msg = "Yes! ${p.aName} goes with ${p.bName}"
                                        speaker.say("${p.aName} goes with ${p.bName}")
                                    } else { msg = "Not that one. Try again 🙂"; speaker.say(p.bName) }
                                }
                            },
                            colors = CardDefaults.cardColors(containerColor = if (isDone) Color(0xFFC8E6C9) else Color.White),
                            border = BorderStroke(3.dp, accent),
                            shape = RoundedCornerShape(18.dp),
                            modifier = Modifier.fillMaxWidth().height(110.dp)
                        ) {
                            Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                                EmojiView(p.bEmoji, 48)
                                Text(p.bName, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
            if (won) {
                Spacer(Modifier.height(16.dp))
                Button(onClick = { round++ }) { Text("Next ▶") }
            }
        }
    }
}
