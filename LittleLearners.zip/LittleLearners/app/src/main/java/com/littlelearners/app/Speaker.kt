package com.littlelearners.app

import android.content.Context
import android.speech.tts.TextToSpeech
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import java.util.Locale

/**
 * Wraps the phone's built-in text-to-speech (works offline when the voice is installed).
 * If a language voice is missing (e.g. Urdu), it silently does nothing.
 */
class Speaker(context: Context) {
    private val appCtx = context.applicationContext
    private var tts: TextToSpeech? = null
    private var ready = false

    init {
        tts = TextToSpeech(context) { status ->
            ready = status == TextToSpeech.SUCCESS
        }
    }

    fun say(text: String, locale: Locale = Locale.US, rate: Float = 0.85f) {
        val engine = tts ?: return
        if (!ready || text.isBlank()) return
        val result = engine.setLanguage(locale)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) return
        pickVoice(engine, locale)
        engine.setSpeechRate(rate)
        engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "ll")
    }

    /** Applies the parent's choice: Auto = engine default, Offline = installed voices only, Online = prefer network voices. */
    private fun pickVoice(engine: TextToSpeech, locale: Locale) {
        val mode = ParentStore.voiceMode(appCtx, locale.language)
        if (mode == ParentStore.VOICE_AUTO) return
        try {
            val all = engine.voices?.filter { it.locale.language == locale.language } ?: return
            val wantNetwork = mode == ParentStore.VOICE_ONLINE
            val matching = all.filter { it.isNetworkConnectionRequired == wantNetwork }
            val pool = if (matching.isNotEmpty()) matching else all
            val best = pool
                .filterNot { it.features?.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED) == true }
                .sortedWith(compareByDescending<android.speech.tts.Voice> { it.locale.country == locale.country }
                    .thenByDescending { it.quality })
                .firstOrNull()
            if (best != null) engine.voice = best
        } catch (_: Exception) {
        }
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}

val UrduLocale: Locale = Locale("ur", "PK")

@Composable
fun rememberSpeaker(): Speaker {
    val appContext = LocalContext.current.applicationContext
    val speaker = remember { Speaker(appContext) }
    DisposableEffect(Unit) { onDispose { speaker.shutdown() } }
    return speaker
}
