package com.littlelearners.app

import android.content.Context
import android.speech.tts.TextToSpeech
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import java.util.Locale

/**
 * Wraps the phone's built-in text-to-speech (works offline when the voice is installed).
 * If a language voice is missing (e.g. Urdu), it silently does nothing.
 */
class Speaker(context: Context) {
    private var tts: TextToSpeech? = null
    private var ready = false

    init {
        tts = TextToSpeech(context) { status ->
            ready = status == TextToSpeech.SUCCESS
        }
    }

    fun say(text: String, locale: Locale = Locale.US) {
        val engine = tts ?: return
        if (!ready || text.isBlank()) return
        val result = engine.setLanguage(locale)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) return
        engine.setSpeechRate(0.85f)
        engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "ll")
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}

val UrduLocale: Locale = Locale("ur", "PK")

@Composable
fun rememberSpeaker(): Speaker {
    val appContext = LocalContext.current.applicationContext
    val speaker = remember { Speaker(appContext) }
    DisposableEffect(Unit) { onDispose { speaker.shutdown() } }
    return speaker
}
