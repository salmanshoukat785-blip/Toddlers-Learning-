package com.littlelearners.app

import android.content.Context

/** Stars earned in quizzes and games. Every STARS_PER_STICKER stars unlock a sticker. Stored locally only. */
object Rewards {
    const val STARS_PER_STICKER = 2
    private const val FILE = "little_learners"
    
    private fun sp(ctx: Context) = ctx.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    private fun k(ctx: Context) = ParentStore.key(ctx, "stars")

    fun stars(ctx: Context): Int = sp(ctx).getInt(k(ctx), 0)

    fun add(ctx: Context, n: Int) {
        if (n <= 0) return
        sp(ctx).edit().putInt(k(ctx), stars(ctx) + n).apply()
    }
}
