package com.littlelearners.app.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.littlelearners.app.Rewards
import com.littlelearners.app.rememberSpeaker
import android.widget.Toast

private class PageGroup(val title: String, val prefix: String, val slugs: List<String>)

private val pageGroups = listOf(
    PageGroup("Animals", "an", listOf("camel", "cheetah", "dolphin", "donkey", "elephant", "giraffe", "horse",
        "kangaroo", "owl", "pigeon", "whale", "wolf", "zebra", "gazelle", "ram", "leopard")),
    PageGroup("Birds", "bi", listOf("dove", "eagle", "flamingo", "magpie", "ostrich", "parrot", "penguin",
        "rooster", "sparrow", "turkey")),
    PageGroup("Fruits", "fr", listOf("cherry", "watermelon", "coconut")),
    PageGroup("Vehicles", "ve", listOf("bicycle", "rocket", "airplane", "zeppelin", "kickscooter")),
    PageGroup("Insects", "in", listOf("butterfly"))
)

private val crayons = listOf(
    Color(0xFFE53935), Color(0xFFFB8C00), Color(0xFFFDD835), Color(0xFF43A047),
    Color(0xFF1E88E5), Color(0xFF8E24AA), Color(0xFFF48FB1), Color(0xFF795548),
    Color(0xFF9E9E9E)
)

private fun pretty(slug: String) = when (slug) {
    "kickscooter" -> "Kick scooter"
    else -> slug.replaceFirstChar { it.uppercase() }
}

/** Outline pictures (made from the app's photos) that the child fills with a tap. */
@Composable
fun ColorPagesScreen(onBack: () -> Unit) {
    val accent = Color(0xFF81C784)
    var group by remember { mutableStateOf(0) }
    var open by remember { mutableStateOf<String?>(null) }
    val ctx = LocalContext.current

    val current = open
    if (current != null) {
        PaintPage(current, accent, onBack = { open = null })
        return
    }
    ScreenScaffold("Coloring Pages", accent, onBack) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            pageGroups.forEachIndexed { i, g ->
                val on = i == group
                Box(
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(14.dp))
                        .background(if (on) accent else Color.White)
                        .border(2.dp, accent, RoundedCornerShape(14.dp))
                        .pointerInput(i) { detectTapGestures { group = i } }
                ) {
                    Text(
                        g.title, fontSize = 11.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp)
                    )
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        val g = pageGroups[group]
        val names = g.slugs.map { "${g.prefix}_$it" }.filter { photoRes(ctx, "cp_$it") != 0 }
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.weight(1f)
        ) {
            items(names) { n ->
                Box(
                    Modifier
                        .aspectRatio(1f)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color.White)
                        .border(2.dp, accent, RoundedCornerShape(16.dp))
                        .pointerInput(n) { detectTapGestures { open = n } }
                ) {
                    PhotoImage("cp_$n", Modifier.fillMaxWidth().padding(8.dp))
                }
            }
        }
    }
}

@Composable
private fun PaintPage(name: String, accent: Color, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val speaker = rememberSpeaker()
    val bmp = remember(name) {
        val id = photoRes(ctx, "cp_$name")
        val src = BitmapFactory.decodeResource(ctx.resources, id)
        src.copy(Bitmap.Config.ARGB_8888, true)
    }
    var rev by remember(name) { mutableStateOf(0) }
    var color by remember { mutableStateOf(crayons[0]) }
    val label = pretty(name.substringAfter('_'))
    val image = remember(rev, bmp) { bmp.asImageBitmap() }

    ScreenScaffold(label, accent, onBack) {
        Box(
            Modifier
                .fillMaxWidth()
                .weight(1f)
                .clip(RoundedCornerShape(16.dp))
                .background(Color.White)
                .border(2.dp, accent, RoundedCornerShape(16.dp)),
            contentAlignment = androidx.compose.ui.Alignment.Center
        ) {
            val ratio = bmp.width.toFloat() / bmp.height.toFloat()
            Image(
                bitmap = image,
                contentDescription = label,
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(ratio)
                    .pointerInput(bmp, color) {
                        detectTapGestures { p ->
                            val x = (p.x / size.width * bmp.width).toInt()
                            val y = (p.y / size.height * bmp.height).toInt()
                            if (floodFill(bmp, x, y, color.toArgb())) rev++
                        }
                    }
            )
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            crayons.forEach { c ->
                Box(
                    Modifier
                        .weight(1f)
                        .aspectRatio(1f)
                        .clip(CircleShape)
                        .background(c)
                        .border(if (c == color) 4.dp else 1.dp, if (c == color) Color(0xFF7B3FA0) else Color.LightGray, CircleShape)
                        .pointerInput(c) { detectTapGestures { color = c } }
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = {
                    val id = photoRes(ctx, "cp_$name")
                    val fresh = BitmapFactory.decodeResource(ctx.resources, id)
                    val px = IntArray(fresh.width * fresh.height)
                    fresh.getPixels(px, 0, fresh.width, 0, 0, fresh.width, fresh.height)
                    bmp.setPixels(px, 0, fresh.width, 0, 0, fresh.width, fresh.height)
                    rev++
                },
                modifier = Modifier.weight(1f).height(50.dp)
            ) { Text("Clear", fontSize = 16.sp) }
            Button(
                onClick = {
                    val ok = saveArt(ctx, bmp, "coloring_$label".lowercase().replace(' ', '_'))
                    if (ok) {
                        Rewards.add(ctx, 1)
                        speaker.say("Beautiful $label!")
                    }
                    Toast.makeText(ctx, if (ok) "Saved! ⭐" else "Could not save", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier.weight(1f).height(50.dp)
            ) { Text("Save 💾", fontSize = 16.sp) }
        }
    }
}

/** Scanline flood fill. Black outline pixels are never painted. Returns true if anything changed. */
private fun floodFill(bmp: Bitmap, sx: Int, sy: Int, fill: Int): Boolean {
    val w = bmp.width
    val h = bmp.height
    if (sx !in 0 until w || sy !in 0 until h) return false
    val px = IntArray(w * h)
    bmp.getPixels(px, 0, w, 0, 0, w, h)
    val target = px[sy * w + sx]
    val line = 0xFF000000.toInt()
    if (target == fill || target == line) return false
    val stack = ArrayDeque<Int>()
    stack.addLast(sy * w + sx)
    while (stack.isNotEmpty()) {
        val i = stack.removeLast()
        val y = i / w
        var x1 = i % w
        if (px[y * w + x1] != target) continue
        while (x1 > 0 && px[y * w + x1 - 1] == target) x1--
        var x = x1
        var up = false
        var down = false
        while (x < w && px[y * w + x] == target) {
            px[y * w + x] = fill
            if (y > 0) {
                val m = px[(y - 1) * w + x] == target
                if (m && !up) stack.addLast((y - 1) * w + x)
                up = m
            }
            if (y < h - 1) {
                val m = px[(y + 1) * w + x] == target
                if (m && !down) stack.addLast((y + 1) * w + x)
                down = m
            }
            x++
        }
    }
    bmp.setPixels(px, 0, w, 0, 0, w, h)
    return true
}
