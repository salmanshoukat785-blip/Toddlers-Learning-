@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.littlelearners.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.CompositionLocalProvider
import com.littlelearners.app.Category
import com.littlelearners.app.LearningModule
import com.littlelearners.app.NamedColor
import com.littlelearners.app.UrduLocale
import com.littlelearners.app.countLayout
import com.littlelearners.app.englishAlphabetFor
import com.littlelearners.app.noneUrdu
import com.littlelearners.app.numberItemsFor
import com.littlelearners.app.items
import com.littlelearners.app.learnColors
import com.littlelearners.app.mixPalette
import com.littlelearners.app.mixResults
import com.littlelearners.app.numberWordsEn
import com.littlelearners.app.numberWordsUr
import com.littlelearners.app.rememberSpeaker
import com.littlelearners.app.toUrduDigits
import com.littlelearners.app.urduAlphabetFor

/** Routes a home-screen tile to its screen (unbuilt modules show the placeholder). */
@Composable
fun ModuleRouter(module: LearningModule, category: Category, onBack: () -> Unit) {
    when (module) {
        LearningModule.NUMBERS -> NumbersScreen(category, onBack)
        LearningModule.ENGLISH_ABC -> AbcScreen(category, onBack)
        LearningModule.URDU -> UrduScreen(category, onBack)
        LearningModule.COLORS_LEARNING -> ColorsScreen(onBack)
        LearningModule.COLOR_MIXING -> ColorMixScreen(onBack)
        LearningModule.TRACING -> TracingScreen(onBack)
        LearningModule.DRAWING -> DrawingScreen(onBack)
        LearningModule.COLORING -> ColoringScreen(onBack)
        LearningModule.MINI_GAMES -> GamesScreen(category, 0, onBack)
        LearningModule.MATCHING -> GamesScreen(category, 1, onBack)
        LearningModule.PUZZLES -> GamesScreen(category, 2, onBack)
        LearningModule.QUIZZES -> QuizzesScreen(category, onBack)
        LearningModule.STICKERS -> StickerBookScreen(onBack)
        LearningModule.FUN_GAMES -> FunGamesScreen(category, onBack)
        LearningModule.WORD_BUILD -> WordBuildScreen(category, onBack)
        LearningModule.CALENDAR -> CalendarScreen(onBack)
        LearningModule.CLOCK -> ClockScreen(onBack)
        LearningModule.MONEY -> MoneyScreen(onBack)
        LearningModule.SPOT_DIFF -> SpotDifferenceScreen(category, onBack)
        LearningModule.SEQUENCE -> SequenceScreen(onBack)
        LearningModule.STORY_MAKER -> StoryMakerScreen(category, onBack)
        LearningModule.BLOCKS -> BlocksScreen(onBack)
        LearningModule.MAZE -> MazeScreen(onBack)
        LearningModule.PAIRS -> PairsScreen(onBack)
        LearningModule.COLOR_PAGES -> ColorPagesScreen(onBack)
        LearningModule.VOCAB -> VocabularyScreen(onBack)
        LearningModule.HABITS -> HabitsScreen(onBack)
        LearningModule.ISLAMIC -> IslamicScreen(onBack)
        LearningModule.RHYMES -> RhymesScreen(onBack)
        LearningModule.MATH -> MathScreen(onBack)
        LearningModule.LEARNING_LIST -> LearningListScreen(category, onBack)
        LearningModule.WORLDS -> WorldsScreen(onBack)
        LearningModule.MUSIC -> MusicScreen(onBack)
        LearningModule.ANIMAL_CARE -> AnimalCareScreen(onBack)
        LearningModule.STORIES -> StoriesScreen(onBack)
        LearningModule.ANIMAL_SOUNDS -> AnimalSoundsScreen(onBack)
        else -> ModuleScreen(module, category, onBack)
    }
}

/** Large card showing the selected item; tap to hear it again. */
@Composable
private fun BigCard(
    accent: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
    content: @Composable () -> Unit
) {
    Card(
        onClick = onClick,
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(3.dp, accent),
        shape = RoundedCornerShape(28.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) { content() }
    }
}

@Composable
private fun GridTile(text: String, accent: Color, selected: Boolean, fontSize: Int = 26, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        colors = CardDefaults.cardColors(containerColor = if (selected) accent else Color.White),
        border = BorderStroke(2.dp, accent),
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.aspectRatio(1f)
    ) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(text, fontSize = fontSize.sp, fontWeight = FontWeight.ExtraBold)
        }
    }
}

// ======================= NUMBERS =======================

@Composable
fun NumbersScreen(category: Category, onBack: () -> Unit) {
    val accent = Color(0xFFEF9A9A)
    val speaker = rememberSpeaker()
    var tab by remember { mutableStateOf(0) }
    var selected by remember { mutableStateOf(1) }
    val numberItems = remember(category) { numberItemsFor(category) }

    ScreenScaffold("Numbers 123 ${category.emoji}", accent, onBack) {
        if (numberItems == null) {
            ComingSoon(accent, category)
            return@ScreenScaffold
        }
        TabsBar(listOf("Learn", "Count", "Quiz"), tab, accent) { tab = it }
        Spacer(Modifier.height(10.dp))
        when (tab) {
            0 -> Column(Modifier.fillMaxSize()) {
                BigCard(accent, Modifier.weight(1f), onClick = { speaker.say(numberWordsEn[selected]) }) {
                    Text("$selected", fontSize = 60.sp, fontWeight = FontWeight.ExtraBold)
                    Text(numberWordsEn[selected], fontSize = 28.sp, fontWeight = FontWeight.Bold)
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                        Text("${selected.toUrduDigits()}  •  ${numberWordsUr[selected]}", fontSize = 24.sp)
                    }
                    run {
                        val a = numberItems[selected - 1]
                        PhotoGrid(a.photo, selected)
                        Text(a.en, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                            Text(a.ur, fontSize = 22.sp)
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        androidx.compose.material3.Button(onClick = { speaker.say(numberWordsEn[selected]) }) {
                            Text("🔊 English")
                        }
                        androidx.compose.material3.Button(onClick = { speaker.say(numberWordsUr[selected], UrduLocale) }) {
                            Text("🔊 اردو")
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                LazyVerticalGrid(
                    columns = GridCells.Fixed(5),
                    modifier = Modifier.height(170.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(bottom = 8.dp)
                ) {
                    items((1..20).toList()) { n ->
                        GridTile("$n", accent, n == selected) {
                            selected = n
                            speaker.say(numberWordsEn[n])
                        }
                    }
                }
            }

            1 -> QuizView(accent, speaker) {
                List(8) {
                    val n = (1..10).random()
                    val (opts, idx) = buildChoices(n, (1..10).toList())
                    Question(
                        prompt = "How many?",
                        big = "",
                        photo = numberItems.random().photo,
                        photoCount = n,
                        options = opts.map { Option("$it") },
                        correct = idx,
                        say = "How many?"
                    )
                }
            }

            else -> QuizView(accent, speaker) {
                List(8) {
                    val n = (1..20).random()
                    val (opts, idx) = buildChoices(n, (1..20).toList())
                    Question(
                        prompt = "Tap the number",
                        big = numberWordsEn[n],
                        options = opts.map { Option("$it") },
                        correct = idx,
                        say = numberWordsEn[n]
                    )
                }
            }
        }
    }
}

// ======================= ENGLISH ABC =======================

@Composable
fun ComingSoon(accent: Color, category: Category) {
    Column(
        Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        EmojiView(category.emoji, 90)
        Spacer(Modifier.height(10.dp))
        Text("${category.label}: content coming soon", fontSize = 20.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
    }
}

@Composable
fun AbcScreen(category: Category, onBack: () -> Unit) {
    val letters = remember(category) { englishAlphabetFor(category) }
    val accent = Color(0xFF90CAF9)
    val speaker = rememberSpeaker()
    var tab by remember { mutableStateOf(0) }
    var selected by remember { mutableStateOf(0) }

    ScreenScaffold("English ABC ${category.emoji}", accent, onBack) {
        if (letters.isEmpty()) {
            ComingSoon(accent, category)
            return@ScreenScaffold
        }
        TabsBar(listOf("Learn", "Quiz"), tab, accent) { tab = it }
        Spacer(Modifier.height(10.dp))
        if (tab == 0) {
            val item = letters[selected.coerceIn(letters.indices)]
            Column(Modifier.fillMaxSize()) {
                BigCard(accent, Modifier.weight(1f), onClick = {
                    speaker.say("${item.letter}. ${item.letter} for ${item.word}")
                }) {
                    if (item.photo != null && !item.plain) {
                        PhotoImage(item.photo, Modifier.fillMaxWidth())
                    } else if (item.plain && item.photo != null) {
                        Text("${item.letter} ${item.letter.lowercaseChar()}", fontSize = 56.sp, fontWeight = FontWeight.ExtraBold)
                        PhotoImage(item.photo, Modifier.fillMaxWidth(0.75f))
                        Text(item.word, fontSize = 32.sp, fontWeight = FontWeight.Bold)
                        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                            Text(item.urdu, fontSize = 26.sp)
                        }
                    } else {
                        Text("${item.letter} ${item.letter.lowercaseChar()}", fontSize = 56.sp, fontWeight = FontWeight.ExtraBold)
                        EmojiView(item.emoji, 170)
                        Text(item.word, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Spacer(Modifier.height(10.dp))
                LazyVerticalGrid(
                    columns = GridCells.Fixed(6),
                    modifier = Modifier.height(150.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    contentPadding = PaddingValues(bottom = 8.dp)
                ) {
                    items(letters.indices.toList()) { i ->
                        GridTile("${letters[i].letter}", accent, i == selected, 22) {
                            selected = i
                            val entry = letters[i]
                            speaker.say("${entry.letter}. ${entry.letter} for ${entry.word}")
                        }
                    }
                }
            }
        } else {
            QuizView(accent, speaker) {
                letters.shuffled().take(8).map { item ->
                    val (opts, idx) = buildChoices(item.letter, letters.map { it.letter })
                    Question(
                        prompt = "What letter does this start with?",
                        big = if (item.photo != null) "" else item.emoji,
                        sub = if (item.photo != null) "" else item.word,
                        photo = item.quizPhoto,
                        bigSize = 140,
                        options = opts.map { Option("$it") },
                        correct = idx,
                        say = item.word
                    )
                }
            }
        }
    }
}

// ======================= URDU =======================

@Composable
fun UrduScreen(category: Category, onBack: () -> Unit) {
    val letters = remember(category) { urduAlphabetFor(category) }
    val accent = Color(0xFFA5D6A7)
    val speaker = rememberSpeaker()
    var tab by remember { mutableStateOf(0) }
    var selected by remember { mutableStateOf(0) }

    ScreenScaffold("Urdu  حروف ${category.emoji}", accent, onBack) {
        if (letters.isEmpty()) {
            ComingSoon(accent, category)
            return@ScreenScaffold
        }
        TabsBar(listOf("Learn", "Quiz"), tab, accent) { tab = it }
        Spacer(Modifier.height(10.dp))
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            if (tab == 0) {
                val item = letters[selected.coerceIn(letters.indices)]
                Column(Modifier.fillMaxSize()) {
                    BigCard(accent, Modifier.weight(1f), onClick = {
                        if (!item.none) speaker.say(item.word, UrduLocale)
                    }) {
                        Text(item.letter, fontSize = 60.sp, fontWeight = FontWeight.Bold)
                        Text(item.name, fontSize = 22.sp)
                        if (item.none) {
                            Spacer(Modifier.height(16.dp))
                            Text(category.noneUrdu, fontSize = 26.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                        } else {
                            if (item.photo != null) {
                                PhotoImage(item.photo, Modifier.fillMaxWidth(0.8f))
                            } else if (item.emoji.isNotBlank()) {
                                EmojiView(item.emoji, 150)
                            }
                            Text(item.word, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                                Text(item.meaning, fontSize = 18.sp, color = Color.Gray)
                            }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(6),
                        modifier = Modifier.height(150.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                        contentPadding = PaddingValues(bottom = 8.dp)
                    ) {
                        items(letters.indices.toList()) { i ->
                            GridTile(letters[i].letter, accent, i == selected, 24) {
                                selected = i
                                if (!letters[i].none) speaker.say(letters[i].word, UrduLocale)
                            }
                        }
                    }
                }
            } else {
                val quizItems = letters.filter { !it.none && (it.photo != null || it.emoji.isNotBlank()) }
                val pool = letters.filter { !it.none }.map { it.letter }
                QuizView(accent, speaker) {
                    quizItems.shuffled().take(8).map { item ->
                        val (opts, idx) = buildChoices(item.letter, pool)
                        Question(
                            prompt = "یہ کس حرف سے شروع ہوتا ہے؟",
                            big = if (item.photo != null) "" else item.emoji,
                            photo = item.photo,
                            bigSize = 140,
                            options = opts.map { Option(it) },
                            correct = idx,
                            say = item.word,
                            sayLocale = UrduLocale
                        )
                    }
                }
            }
        }
    }
}

// ======================= COLORS =======================

@Composable
fun ColorsScreen(onBack: () -> Unit) {
    val accent = Color(0xFFCE93D8)
    val speaker = rememberSpeaker()
    var tab by remember { mutableStateOf(0) }
    var selected by remember { mutableStateOf(0) }

    ScreenScaffold("Colors", accent, onBack) {
        TabsBar(listOf("Learn", "Match"), tab, accent) { tab = it }
        Spacer(Modifier.height(10.dp))
        if (tab == 0) {
            val c = learnColors[selected]
            Column(Modifier.fillMaxSize()) {
                BigCard(accent, Modifier.weight(1f), onClick = { speaker.say(c.en) }) {
                    EmojiView(c.emoji, 150)
                    Box(
                        Modifier
                            .size(70.dp)
                            .clip(CircleShape)
                            .background(c.color)
                            .border(2.dp, Color.LightGray, CircleShape)
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(c.en, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold)
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                        Text(c.ur, fontSize = 28.sp)
                    }
                }
                Spacer(Modifier.height(10.dp))
                LazyVerticalGrid(
                    columns = GridCells.Fixed(5),
                    modifier = Modifier.height(130.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(learnColors.indices.toList()) { i ->
                        val col = learnColors[i]
                        Card(
                            onClick = { selected = i; speaker.say(col.en) },
                            colors = CardDefaults.cardColors(containerColor = col.color),
                            border = BorderStroke(if (i == selected) 5.dp else 1.dp, if (i == selected) accent else Color.LightGray),
                            shape = CircleShape,
                            modifier = Modifier.aspectRatio(1f)
                        ) {}
                    }
                }
            }
        } else {
            QuizView(accent, speaker) {
                List(8) {
                    val target = learnColors.random()
                    val (opts, idx) = buildChoices(target, learnColors)
                    Question(
                        prompt = "Tap the color",
                        big = target.emoji,
                        sub = "${target.en}  •  ${target.ur}",
                        bigSize = 140,
                        options = opts.map { Option("", it.color) },
                        correct = idx,
                        say = target.en
                    )
                }
            }
        }
    }
}

// ======================= COLOR MIXING =======================

@Composable
fun ColorMixScreen(onBack: () -> Unit) {
    val accent = Color(0xFFF48FB1)
    val speaker = rememberSpeaker()
    var first by remember { mutableStateOf<NamedColor?>(null) }
    var second by remember { mutableStateOf<NamedColor?>(null) }

    val result: NamedColor? =
        if (first != null && second != null) mixResults[setOf(first!!.en, second!!.en)] else null
    val message = when {
        first == null || second == null -> "Pick two colors!"
        first == second -> "Same color! Pick a different one."
        result == null -> "Hmm, try another mix! 🙂"
        else -> "${first!!.en} + ${second!!.en} = ${result.en}"
    }

    var tab by remember { mutableStateOf(0) }
    ScreenScaffold("Color Mixing", accent, onBack) {
        TabsBar(listOf("Mix", "Challenge"), tab, accent) { tab = it }
        Spacer(Modifier.height(10.dp))
        if (tab == 1) {
            Column(Modifier.verticalScroll(rememberScrollState())) { ColorChallenge(accent, speaker) }
            return@ScreenScaffold
        }
        Text("First color", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Palette(mixPalette, first, accent) { first = it; speaker.say(it.en) }
        Spacer(Modifier.height(10.dp))
        Text("Second color", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Palette(mixPalette, second, accent) { second = it; speaker.say(it.en) }
        Spacer(Modifier.height(16.dp))
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Swatch(first?.color)
            Text("  +  ", fontSize = 32.sp, fontWeight = FontWeight.Bold)
            Swatch(second?.color)
            Text("  =  ", fontSize = 32.sp, fontWeight = FontWeight.Bold)
            Swatch(result?.color, big = true)
        }
        Spacer(Modifier.height(16.dp))
        Text(
            message,
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
        androidx.compose.runtime.LaunchedEffect(result) {
            if (result != null) speaker.say("${first?.en} and ${second?.en} make ${result.en}")
        }
    }
}

@Composable
private fun Palette(colors: List<NamedColor>, selected: NamedColor?, accent: Color, onPick: (NamedColor) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        colors.forEach { c ->
            Card(
                onClick = { onPick(c) },
                colors = CardDefaults.cardColors(containerColor = c.color),
                border = BorderStroke(if (c == selected) 5.dp else 1.dp, if (c == selected) accent else Color.LightGray),
                shape = CircleShape,
                modifier = Modifier
                    .weight(1f)
                    .aspectRatio(1f)
            ) {}
        }
    }
}

@Composable
private fun Swatch(color: Color?, big: Boolean = false) {
    val size = if (big) 90.dp else 64.dp
    Box(
        Modifier
            .size(size)
            .clip(CircleShape)
            .background(color ?: Color(0xFFEEEEEE))
            .padding(2.dp)
    ) {
        if (color == null) Text("?", fontSize = 28.sp, modifier = Modifier.align(Alignment.Center), color = Color.Gray)
    }
}
