@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.littlelearners.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.littlelearners.app.Category
import com.littlelearners.app.Rewards
import com.littlelearners.app.rememberSpeaker

/**
 * Sticker Book: stars from quizzes and games unlock stickers (one picture each).
 * Unlock order interleaves all categories so every category gets stickers early.
 */
@Composable
fun StickerBookScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val speaker = rememberSpeaker()
    val accent = Color(0xFF9FA8DA)
    val stars = remember { Rewards.stars(ctx) }

    val pools = remember { Category.entries.associateWith { gameItems(it) } }
    val order = remember {
        val cats = Category.entries.filter { pools.getValue(it).isNotEmpty() }
        val maxN = cats.maxOfOrNull { pools.getValue(it).size } ?: 0
        buildList {
            for (i in 0 until maxN) {
                for (c in cats) if (i < pools.getValue(c).size) add(c to i)
            }
        }
    }
    val unlockedCount = (stars / Rewards.STARS_PER_STICKER).coerceAtMost(order.size)
    val unlocked = remember(unlockedCount) { order.take(unlockedCount).toSet() }
    var cat by remember { mutableStateOf(Category.default) }
    val list = pools.getValue(cat)
    val inCat = list.indices.count { (cat to it) in unlocked }
    val toNext = Rewards.STARS_PER_STICKER - (stars % Rewards.STARS_PER_STICKER)

    ScreenScaffold("Sticker Book", accent, onBack) {
        Text(
            "⭐ $stars stars   •   Stickers: $unlockedCount / ${order.size}",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
        Text(
            if (unlockedCount < order.size) "Play quizzes and games: $toNext more ⭐ for the next sticker" else "You collected them all! 🎉",
            fontSize = 14.sp,
            color = Color.Gray,
            textAlign = TextAlign.Center,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
        Spacer(Modifier.height(8.dp))
        CategorySwitcher(cat) { cat = it }
        Spacer(Modifier.height(6.dp))
        Text("${cat.label}: $inCat / ${list.size}", fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(6.dp))
        if (list.isEmpty()) {
            ComingSoon(accent, cat)
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(list.size) { i ->
                    val g = list[i]
                    val open = (cat to i) in unlocked
                    Card(
                        onClick = { if (open) speaker.say(g.en) },
                        colors = CardDefaults.cardColors(containerColor = if (open) Color.White else Color(0xFFE0E0E0)),
                        border = BorderStroke(3.dp, if (open) accent else Color(0xFFBDBDBD)),
                        shape = RoundedCornerShape(18.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(0.9f)
                    ) {
                        Box(Modifier.fillMaxSize().padding(4.dp), contentAlignment = Alignment.Center) {
                            if (open) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    PhotoImage(g.photo, Modifier.fillMaxWidth(0.85f))
                                    Text(g.en, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                                }
                            } else {
                                Text("🔒", fontSize = 30.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}
