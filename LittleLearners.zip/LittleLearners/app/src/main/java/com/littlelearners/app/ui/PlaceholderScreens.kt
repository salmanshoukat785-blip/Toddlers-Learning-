package com.littlelearners.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.littlelearners.app.Category
import com.littlelearners.app.LearningModule

/** Stand-in for every module until its development phase is built. */
@Composable
fun ModuleScreen(module: LearningModule, category: Category, onBack: () -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .background(module.color.copy(alpha = 0.35f))
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(module.emoji, fontSize = 80.sp)
        Spacer(Modifier.height(12.dp))
        Text(module.title, style = MaterialTheme.typography.headlineLarge, textAlign = TextAlign.Center)
        Spacer(Modifier.height(8.dp))
        Text("Category: ${category.emoji} ${category.label}", fontSize = 18.sp)
        Spacer(Modifier.height(8.dp))
        Text(
            "Coming in Phase ${module.phase}",
            fontSize = 16.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.primary
        )
        Spacer(Modifier.height(24.dp))
        Button(onClick = onBack, modifier = Modifier.height(64.dp).fillMaxWidth(0.7f)) {
            Text("⬅  Back", fontSize = 20.sp)
        }
    }
}

/** Simple parent gate (solve a sum) before the settings placeholder. Full dashboard: Phase 6. */
@Composable
fun ParentGateScreen(onBack: () -> Unit) {
    val a = remember { (3..9).random() }
    val b = remember { (3..9).random() }
    var answer by remember { mutableStateOf("") }
    var unlocked by remember { mutableStateOf(false) }
    var wrong by remember { mutableStateOf(false) }

    Column(
        Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        if (!unlocked) {
            Text("Parents only", style = MaterialTheme.typography.headlineLarge)
            Spacer(Modifier.height(12.dp))
            Text("What is $a + $b ?", fontSize = 22.sp)
            Spacer(Modifier.height(12.dp))
            androidx.compose.material3.OutlinedTextField(
                value = answer,
                onValueChange = { answer = it.filter(Char::isDigit).take(2); wrong = false },
                singleLine = true,
                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                    keyboardType = androidx.compose.ui.text.input.KeyboardType.Number
                )
            )
            if (wrong) Text("Try again", color = MaterialTheme.colorScheme.error)
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(onClick = onBack) { Text("Back") }
                Button(onClick = {
                    if (answer.toIntOrNull() == a + b) unlocked = true else wrong = true
                }) { Text("Enter") }
            }
        } else {
            Text("Parent Section", style = MaterialTheme.typography.headlineLarge)
            Spacer(Modifier.height(8.dp))
            Text(
                "Progress dashboard, language, sound and reset options arrive in Phase 6.",
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(16.dp))
            Button(onClick = onBack) { Text("Back") }
        }
    }
}
