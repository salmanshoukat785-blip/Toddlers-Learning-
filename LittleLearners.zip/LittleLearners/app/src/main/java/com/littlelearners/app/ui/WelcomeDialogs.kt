package com.littlelearners.app.ui

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.littlelearners.app.ParentStore
import com.littlelearners.app.rememberSpeaker

private class WelcomePage(val emoji: String, val title: String, val text: String, val say: String)

private val welcomePages = listOf(
    WelcomePage("🦉", "Hello! I am Lulu", "Welcome to Little Learners! Offline, no ads, no login. Pick a category at the top, then tap an activity.",
        "Hello! I am Lulu. Welcome to Little Learners!"),
    WelcomePage("⭐", "Earn stars", "Quizzes and games give stars. Every 2 stars unlock a sticker in the Sticker Book.",
        "Play games to earn stars!"),
    WelcomePage("👨‍👩‍👧", "For parents", "The Parents button has a PIN, a daily play-time limit and voice choices. If Urdu is silent, install an Urdu voice in the phone's Text-to-speech settings.",
        "Parents, please look at the Parents section.")
)

@Composable
private fun WelcomeBackdrop(content: @Composable () -> Unit) {
    Box(
        Modifier
            .fillMaxSize()
            .background(SoftSky)
            // swallow touches so nothing underneath can be tapped
            .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) {}
    ) { content() }
}

@Composable
private fun BigButton(label: String, onClick: () -> Unit) {
    Button(onClick = onClick, modifier = Modifier.fillMaxWidth().height(60.dp)) {
        Text(label, fontSize = 22.sp, fontWeight = FontWeight.Bold)
    }
}

/**
 * First run: three animated welcome pages with Lulu the owl. Then "Who is playing?" (if there are several
 * children). Every new day: Lulu gives a daily star and shows the streak. Drawn over the app as a full screen.
 */
@Composable
fun WelcomeFlow() {
    val ctx = LocalContext.current
    val speaker = rememberSpeaker()
    val many = ParentStore.profileCount(ctx) > 1
    val afterTutorial = if (many) 50 else 100
    var step by remember { mutableStateOf(if (ParentStore.tutorialDone(ctx)) afterTutorial else 0) }

    if (step > 100) return

    if (step < welcomePages.size) {
        val page = welcomePages[step]
        LaunchedEffect(step) { speaker.say(page.say) }
        WelcomeBackdrop {
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Crossfade(targetState = step, label = "page") { i ->
                    val p = welcomePages[i]
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        BouncyEmoji(p.emoji, 110)
                        Spacer(Modifier.height(20.dp))
                        Text(
                            p.title, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF7B3FA0), textAlign = TextAlign.Center
                        )
                        Spacer(Modifier.height(12.dp))
                        Box(Modifier.background(Color.White, RoundedCornerShape(24.dp)).padding(18.dp)) {
                            Text(p.text, fontSize = 18.sp, textAlign = TextAlign.Center, color = Color(0xFF424242))
                        }
                    }
                }
                Spacer(Modifier.height(24.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    welcomePages.indices.forEach { i ->
                        Box(
                            Modifier
                                .size(if (i == step) 16.dp else 11.dp)
                                .background(if (i == step) Color(0xFF7B3FA0) else Color(0xFFBDBDBD), CircleShape)
                        )
                    }
                }
                Spacer(Modifier.height(24.dp))
                val last = step == welcomePages.size - 1
                BigButton(if (last) "Start 🚀" else "Next ▶") {
                    if (last) ParentStore.setTutorialDone(ctx)
                    step = if (last) afterTutorial else step + 1
                }
            }
        }
        return
    }

    if (step == 50) {
        LaunchedEffect(Unit) { speaker.say("Who is playing?") }
        WelcomeBackdrop {
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                BouncyEmoji("👋", 80)
                Text("Who is playing?", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF7B3FA0))
                Spacer(Modifier.height(16.dp))
                for (i in 0 until ParentStore.profileCount(ctx)) {
                    Card(
                        onClick = { ParentStore.setProfile(ctx, i); step = 100 },
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(28.dp),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
                    ) {
                        Row(
                            Modifier.fillMaxWidth().padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            EmojiView(ParentStore.avatars[i], 52)
                            Spacer(Modifier.width(16.dp))
                            Text(ParentStore.profileLabel(ctx, i), fontSize = 26.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
        return
    }

    // step == 100: daily star
    DailyReward(onClose = { step = 101 })
}

@Composable
private fun DailyReward(onClose: () -> Unit) {
    val ctx = LocalContext.current
    val speaker = rememberSpeaker()
    val daily = remember { ParentStore.claimDaily(ctx) }
    if (!daily.isNew) {
        LaunchedEffect(Unit) { onClose() }
        return
    }
    val who = ParentStore.profileLabel(ctx, ParentStore.profileId(ctx))
    val pop = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        speaker.say("Good day, $who! You get ${daily.stars} ${if (daily.stars == 1) "star" else "stars"}!")
        pop.animateTo(1f, spring(dampingRatio = 0.35f, stiffness = Spring.StiffnessLow))
    }
    val filled = ((daily.streak - 1) % 5) + 1
    WelcomeBackdrop {
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            BouncyEmoji("🦉", 100)
            Text("Hello, $who!", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF7B3FA0))
            Spacer(Modifier.height(16.dp))
            Box(
                Modifier
                    .graphicsLayer { scaleX = pop.value; scaleY = pop.value }
                    .background(Color(0xFFFFF59D), RoundedCornerShape(32.dp))
                    .padding(horizontal = 36.dp, vertical = 18.dp)
            ) {
                Text(
                    "⭐ +${daily.stars}", fontSize = 48.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF3E2723)
                )
            }
            Spacer(Modifier.height(18.dp))
            Text(
                "🔥 ${daily.streak} day${if (daily.streak == 1) "" else "s"} in a row",
                fontSize = 22.sp, fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (i in 1..5) {
                    Box(
                        Modifier
                            .size(34.dp)
                            .background(if (i <= filled) Color(0xFFFFB300) else Color.White, CircleShape),
                        contentAlignment = Alignment.Center
                    ) { Text(if (i == 5) "🎁" else if (i <= filled) "⭐" else "", fontSize = 16.sp) }
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(
                if (daily.stars > 1) "🎁 5-day bonus!" else "Come back tomorrow for another star!",
                fontSize = 16.sp, color = Color(0xFF5D4037), textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(24.dp))
            BigButton("Yay! 🎉", onClose)
        }
    }
}
