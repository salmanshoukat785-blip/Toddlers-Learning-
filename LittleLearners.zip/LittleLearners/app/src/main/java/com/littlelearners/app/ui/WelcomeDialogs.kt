@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.littlelearners.app.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import com.littlelearners.app.ParentStore
import com.littlelearners.app.rememberSpeaker

private val tutorial = listOf(
    "Welcome to Little Learners! 🎉" to "Offline, no ads, no login. Pick a category at the top, then tap an activity.",
    "Earn stars ⭐" to "Quizzes and games give stars. Every 2 stars unlock a sticker in the Sticker Book.",
    "For parents 👨‍👩‍👧" to "The Parents button has a PIN, a daily play-time limit and voice choices. If Urdu is silent, install an Urdu voice in the phone's Text-to-speech settings."
)

/** First run: a short parent tutorial. Every new day: Lulu the owl gives a daily star and shows the streak. */
@Composable
fun WelcomeFlow() {
    val ctx = LocalContext.current
    val speaker = rememberSpeaker()
    val many = ParentStore.profileCount(ctx) > 1
    val afterTutorial = if (many) 50 else 100
    var step by remember { mutableStateOf(if (ParentStore.tutorialDone(ctx)) afterTutorial else 0) }

    if (step < tutorial.size) {
        val (title, text) = tutorial[step]
        AlertDialog(
            onDismissRequest = {},
            title = { Text(title) },
            text = { Text(text) },
            confirmButton = {
                TextButton(onClick = {
                    if (step == tutorial.size - 1) ParentStore.setTutorialDone(ctx)
                    step = if (step == tutorial.size - 1) afterTutorial else step + 1
                }) { Text(if (step == tutorial.size - 1) "Start 🚀" else "Next ▶") }
            }
        )
        return
    }
    if (step == 50) {
        AlertDialog(
            onDismissRequest = {},
            title = { Text("Who is playing? 👋") },
            text = {
                Column {
                    for (i in 0 until ParentStore.profileCount(ctx)) {
                        Button(
                            onClick = { ParentStore.setProfile(ctx, i); step = 100 },
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                        ) { Text("${ParentStore.avatars[i]}  ${ParentStore.profileLabel(ctx, i)}", fontSize = 20.sp) }
                    }
                }
            },
            confirmButton = {}
        )
        return
    }
    if (step == 100) {
        val daily = remember { ParentStore.claimDaily(ctx) }
        if (!daily.isNew) { step = 101; return }
        val bonus = daily.stars > 1
        val who = ParentStore.profileLabel(ctx, ParentStore.profileId(ctx))
        val msg = "Good day, $who! You get ${daily.stars} ${if (daily.stars == 1) "star" else "stars"}!"
        LaunchedEffect(Unit) { speaker.say(msg) }
        AlertDialog(
            onDismissRequest = { step = 101 },
            title = { Text("🦉 Lulu says: Hello, $who!") },
            text = {
                Text(
                    "⭐ +${daily.stars} daily ${if (daily.stars == 1) "star" else "stars"}\n" +
                        "🔥 ${daily.streak} day${if (daily.streak == 1) "" else "s"} in a row" +
                        if (bonus) "\n🎁 5-day bonus!" else "\nCome back tomorrow for another star!"
                )
            },
            confirmButton = { TextButton(onClick = { step = 101 }) { Text("Yay! 🎉") } }
        )
    }
}
