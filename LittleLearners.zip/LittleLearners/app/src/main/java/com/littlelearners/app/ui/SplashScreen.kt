package com.littlelearners.app.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloat
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.BiasAlignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.littlelearners.app.R
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

val SoftSky = Brush.verticalGradient(listOf(Color(0xFFFFF8E1), Color(0xFFFFE0B2), Color(0xFFF8BBD0)))

// emoji, horizontal bias, vertical bias, phase
private val floaters = listOf(
    listOf("🔤", -0.8f, -0.75f, 0f), listOf("🔢", 0.8f, -0.8f, 0.3f), listOf("🎨", -0.85f, -0.1f, 0.6f),
    listOf("🐯", 0.85f, 0.05f, 0.15f), listOf("🍎", -0.7f, 0.7f, 0.45f), listOf("🚗", 0.75f, 0.75f, 0.75f),
    listOf("⭐", 0.0f, -0.92f, 0.5f), listOf("🎵", -0.1f, 0.92f, 0.9f)
)

/** Animated start-up screen (about 2.5 s; tap to skip). */
@Composable
fun SplashScreen(onDone: () -> Unit) {
    val scale = remember { Animatable(0f) }
    val textAlpha = remember { Animatable(0f) }
    val progress = remember { Animatable(0f) }
    val finished = remember { booleanArrayOf(false) }
    val finish = { if (!finished[0]) { finished[0] = true; onDone() } }

    LaunchedEffect(Unit) {
        launch { scale.animateTo(1f, spring(dampingRatio = 0.4f, stiffness = Spring.StiffnessLow)) }
        launch { delay(500); textAlpha.animateTo(1f, tween(700)) }
        progress.animateTo(1f, tween(2200, easing = LinearEasing))
        delay(150)
        finish()
    }

    val t = rememberInfiniteTransition(label = "splash")
    val bob by t.animateFloat(
        0f, 1f, infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "bob"
    )
    val drift by t.animateFloat(
        0f, 1f, infiniteRepeatable(tween(2400, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "drift"
    )

    Box(
        Modifier
            .fillMaxSize()
            .background(SoftSky)
            .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { finish() }
    ) {
        floaters.forEach { f ->
            val phase = f[3] as Float
            val wave = ((drift + phase) % 1f)
            Box(
                Modifier
                    .align(BiasAlignment(f[1] as Float, (f[2] as Float) + (wave - 0.5f) * 0.08f))
                    .graphicsLayer { alpha = textAlpha.value * 0.9f }
            ) { EmojiView(f[0] as String, 40) }
        }
        Column(
            Modifier.align(Alignment.Center).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(
                painter = painterResource(R.drawable.logo),
                contentDescription = "Little Learners",
                modifier = Modifier
                    .size(150.dp)
                    .offset(y = (-12 * bob).dp)
                    .graphicsLayer { scaleX = scale.value; scaleY = scale.value }
            )
            Spacer(Modifier.height(16.dp))
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.graphicsLayer { alpha = textAlpha.value; translationY = (1f - textAlpha.value) * 40f }
            ) {
                Text(
                    "Little Learners", fontSize = 38.sp, fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFF7B3FA0), textAlign = TextAlign.Center
                )
                Text(
                    "Learn • Play • Explore", fontSize = 16.sp, fontWeight = FontWeight.SemiBold,
                    color = Color(0xFFE64A19)
                )
                Text(
                    "سیکھو • کھیلو • دریافت کرو", fontSize = 18.sp, color = Color(0xFF5D4037),
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
            Spacer(Modifier.height(32.dp))
            Box(
                Modifier.width(200.dp).height(10.dp).clip(RoundedCornerShape(5.dp)).background(Color.White.copy(alpha = 0.7f))
            ) {
                Box(
                    Modifier.fillMaxSize().graphicsLayer {
                        scaleX = progress.value
                        transformOrigin = androidx.compose.ui.graphics.TransformOrigin(0f, 0.5f)
                    }.background(Color(0xFF7B3FA0), RoundedCornerShape(5.dp))
                )
            }
        }
        Text(
            "No Ads • No Login • 100% Offline", fontSize = 12.sp, color = Color(0xFF2E7D32),
            fontWeight = FontWeight.Medium,
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 28.dp)
        )
    }
}
