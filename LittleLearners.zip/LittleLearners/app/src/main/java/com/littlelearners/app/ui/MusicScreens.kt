@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.littlelearners.app.ui

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

/** Tiny offline synthesizer: a piano-like tone made from a few harmonics with a decaying envelope. */
private object Synth {
    private const val RATE = 22050

    suspend fun play(freq: Double, ms: Int = 700) = withContext(Dispatchers.Default) {
        val n = RATE * ms / 1000
        val pcm = ShortArray(n) { i ->
            val t = i.toDouble() / RATE
            val env = exp(-3.5 * t) * (if (i < 200) i / 200.0 else 1.0)
            val s = sin(2 * PI * freq * t) + 0.5 * sin(4 * PI * freq * t) + 0.25 * sin(6 * PI * freq * t)
            (s / 1.75 * env * 0.8 * Short.MAX_VALUE).toInt().toShort()
        }
        try {
            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(RATE)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(pcm.size * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
            track.write(pcm, 0, pcm.size)
            track.play()
            delay(ms.toLong() + 100)
            track.release()
        } catch (_: Exception) {
        }
    }
}

private class Key(val name: String, val freq: Double, val color: Color)

private val keys = listOf(
    Key("Do", 261.63, Color(0xFFEF5350)),
    Key("Re", 293.66, Color(0xFFFF9800)),
    Key("Mi", 329.63, Color(0xFFFFEE58)),
    Key("Fa", 349.23, Color(0xFF66BB6A)),
    Key("Sol", 392.00, Color(0xFF26C6DA)),
    Key("La", 440.00, Color(0xFF42A5F5)),
    Key("Si", 493.88, Color(0xFFAB47BC)),
    Key("Do", 523.25, Color(0xFFEC407A))
)

private class Song(val title: String, val notes: List<Int>)

// indices into keys
private val songs = listOf(
    Song("Twinkle Twinkle", listOf(0, 0, 4, 4, 5, 5, 4, 3, 3, 2, 2, 1, 1, 0)),
    Song("Mary Had a Little Lamb", listOf(2, 1, 0, 1, 2, 2, 2, 1, 1, 1, 2, 4, 4)),
    Song("Do Re Mi", listOf(0, 1, 2, 3, 4, 5, 6, 7))
)

@Composable
fun MusicScreen(onBack: () -> Unit) {
    val accent = Color(0xFFCE93D8)
    val scope = rememberCoroutineScope()
    var tab by remember { mutableStateOf(0) }
    var lit by remember { mutableStateOf(-1) }
    var job by remember { mutableStateOf<Job?>(null) }
    var songName by remember { mutableStateOf("") }

    ScreenScaffold("Music 🎹", accent, onBack) {
        TabsBar(listOf("Piano", "Songs"), tab, accent) { job?.cancel(); lit = -1; tab = it }
        Spacer(Modifier.height(10.dp))
        Text(
            if (tab == 0) "Tap the colors to play!" else if (songName.isEmpty()) "Pick a song and watch the keys" else "Playing: $songName",
            fontSize = 18.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))
        if (tab == 1) {
            songs.forEach { s ->
                Button(
                    onClick = {
                        job?.cancel()
                        songName = s.title
                        job = scope.launch {
                            for (i in s.notes) {
                                lit = i
                                launch { Synth.play(keys[i].freq) }
                                delay(450)
                                lit = -1
                                delay(60)
                            }
                            songName = ""
                        }
                    },
                    modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)
                ) { Text("▶  ${s.title}", fontSize = 16.sp) }
            }
            Spacer(Modifier.height(10.dp))
        }
        Row(
            Modifier.fillMaxWidth().weight(1f),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            keys.forEachIndexed { i, k ->
                Box(
                    Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (lit == i) Color.White else k.color)
                        .clickable { lit = i; scope.launch { Synth.play(k.freq); if (lit == i) lit = -1 } },
                    contentAlignment = Alignment.BottomCenter
                ) {
                    Text(k.name, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.Black,
                        modifier = Modifier.padding(bottom = 10.dp))
                }
            }
        }
    }
}
