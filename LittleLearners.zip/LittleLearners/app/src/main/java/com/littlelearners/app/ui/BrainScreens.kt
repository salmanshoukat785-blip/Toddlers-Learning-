@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.littlelearners.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.littlelearners.app.Category
import com.littlelearners.app.Rewards
import com.littlelearners.app.rememberSpeaker
import kotlin.math.sqrt
import kotlin.random.Random

private fun poolFor(category: Category, own: List<GameItem>, animals: List<GameItem>) = if (own.size >= 8) own else animals

// ------------------------------------------------------------------ Spot the difference

private class Diff(val fx: Float, val fy: Float, val kind: Int, val color: Color)

private val diffColors = listOf(Color(0xFFE53935), Color(0xFF1E88E5), Color(0xFFFDD835), Color(0xFF8E24AA), Color(0xFFFB8C00))

private fun newDiffs(): List<Diff> {
    val out = mutableListOf<Diff>()
    while (out.size < 3) {
        val fx = 0.2f + Random.nextFloat() * 0.6f
        val fy = 0.2f + Random.nextFloat() * 0.6f
        if (out.all { sqrt((it.fx - fx) * (it.fx - fx) + (it.fy - fy) * (it.fy - fy)) > 0.28f }) {
            out.add(Diff(fx, fy, out.size % 3, diffColors.random()))
        }
    }
    return out
}

@Composable
fun SpotDifferenceScreen(category: Category, onBack: () -> Unit) {
    val accent = Color(0xFFF48FB1)
    val ctx = LocalContext.current
    val speaker = rememberSpeaker()
    val own = remember(category) { gameItems(category) }
    val animals = remember { gameItems(Category.ANIMALS) }
    val pool = poolFor(category, own, animals)
    var round by remember { mutableStateOf(0) }
    val item = remember(round, pool) { pool.random() }
    val diffs = remember(round) { newDiffs() }
    var found by remember(round) { mutableStateOf(setOf<Int>()) }
    var msg by remember(round) { mutableStateOf("Find 3 differences in the bottom picture") }
    val won = found.size == 3
    LaunchedEffect(won, round) { if (won) { Rewards.add(ctx, 3); speaker.say("You found them all!") } }
    val resId = remember(item) { photoRes(ctx, item.photo) }

    ScreenScaffold("Spot the Difference 🔍", accent, onBack) {
        Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(if (won) "🎉 You found all 3! +3 ⭐" else "$msg  (${found.size}/3)", fontSize = 17.sp,
                fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            Spacer(Modifier.height(6.dp))
            Box(Modifier.weight(1f).fillMaxWidth().background(Color.White).border(2.dp, accent), contentAlignment = Alignment.Center) {
                if (resId != 0) Image(painterResource(resId), null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
            }
            Spacer(Modifier.height(6.dp))
            Box(
                Modifier.weight(1f).fillMaxWidth().background(Color.White).border(2.dp, accent)
                    .pointerInput(round) {
                        detectTapGestures { off ->
                            val w = size.width.toFloat()
                            val h = size.height.toFloat()
                            val hit = diffs.indexOfFirst { d ->
                                val dx = off.x / w - d.fx
                                val dy = (off.y / h - d.fy) * (h / w)
                                sqrt(dx * dx + dy * dy) < 0.09f
                            }
                            if (hit >= 0 && hit !in found) { found = found + hit; msg = "Yes! Found one" ; speaker.say("Yes") }
                            else if (hit < 0) msg = "Not there. Look again"
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                if (resId != 0) Image(painterResource(resId), null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                Canvas(Modifier.fillMaxSize()) {
                    val r = minOf(size.width, size.height) * 0.07f
                    diffs.forEachIndexed { i, d ->
                        val c = Offset(d.fx * size.width, d.fy * size.height)
                        when (d.kind) {
                            0 -> drawCircle(d.color, radius = r, center = c)
                            1 -> drawRect(d.color, topLeft = Offset(c.x - r, c.y - r), size = Size(2 * r, 2 * r))
                            else -> drawRect(Color.White, topLeft = Offset(c.x - r * 1.4f, c.y - r * 1.4f), size = Size(r * 2.8f, r * 2.8f))
                        }
                        if (i in found) drawCircle(Color(0xFF43A047), radius = r * 1.9f, center = c, style = Stroke(width = 8f))
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            if (won) Button(onClick = { round++ }) { Text("Next picture ▶") }
            else OutlinedButton(onClick = { round++ }) { Text("🔁 Another picture") }
        }
    }
}

// ------------------------------------------------------------------ Put it in order

private class Seq(val title: String, val steps: List<Pair<String, String>>)

private val sequences = listOf(
    Seq("A plant grows", listOf("🌱" to "Seed", "🌿" to "Sprout", "🌻" to "Flower")),
    Seq("A butterfly grows", listOf("🥚" to "Egg", "🐛" to "Caterpillar", "🦋" to "Butterfly")),
    Seq("A day", listOf("🌅" to "Morning", "☀️" to "Noon", "🌇" to "Evening", "🌙" to "Night")),
    Seq("Growing up", listOf("👶" to "Baby", "🧒" to "Child", "🧑" to "Adult", "🧓" to "Old")),
    Seq("Rain", listOf("☁️" to "Cloud", "🌧️" to "Rain", "🌈" to "Rainbow")),
    Seq("Getting ready", listOf("🛏️" to "Wake up", "🪥" to "Brush teeth", "🍳" to "Breakfast", "🎒" to "School"))
)

@Composable
fun SequenceScreen(onBack: () -> Unit) {
    val accent = Color(0xFF80CBC4)
    val ctx = LocalContext.current
    val speaker = rememberSpeaker()
    var round by remember { mutableStateOf(0) }
    val seq = remember(round) { sequences.random() }
    val order = remember(round) {
        var o = seq.steps.indices.shuffled()
        while (o == seq.steps.indices.toList()) o = seq.steps.indices.shuffled()
        o
    }
    var placed by remember(round) { mutableStateOf(0) }
    var msg by remember(round) { mutableStateOf("Tap what comes FIRST") }
    val won = placed == seq.steps.size
    LaunchedEffect(won, round) { if (won) { Rewards.add(ctx, 2); speaker.say("Well done!") } }

    ScreenScaffold("What Comes Next? ➡️", accent, onBack) {
        Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(seq.title, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
            Text(if (won) "🎉 Perfect order! +2 ⭐" else msg, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                seq.steps.forEachIndexed { i, s ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = if (i < placed) Color(0xFFC8E6C9) else Color(0xFFF5F5F5)),
                        border = BorderStroke(2.dp, accent),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.size(width = 78.dp, height = 96.dp)
                    ) {
                        Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                            Text("${i + 1}", fontSize = 14.sp, color = Color.Gray)
                            if (i < placed) { Text(s.first, fontSize = 34.sp); Text(s.second, fontSize = 11.sp, maxLines = 1) }
                        }
                    }
                }
            }
            Spacer(Modifier.height(28.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                order.forEach { idx ->
                    if (idx >= placed || idx !in 0 until placed) {
                        val s = seq.steps[idx]
                        val gone = idx < placed
                        if (!gone) Card(
                            onClick = {
                                if (idx == placed) { placed++; msg = "Yes! ${s.second}"; speaker.say(s.second) }
                                else msg = "Not yet. What comes first?"
                            },
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = BorderStroke(3.dp, accent),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.size(width = 78.dp, height = 96.dp)
                        ) {
                            Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                                Text(s.first, fontSize = 36.sp)
                                Text(s.second, fontSize = 11.sp, maxLines = 1)
                            }
                        }
                    }
                }
            }
            if (won) {
                Spacer(Modifier.height(20.dp))
                Button(onClick = { round++ }) { Text("Next ▶") }
            }
        }
    }
}

// ------------------------------------------------------------------ Make a story

private fun art(n: String) = if (n.first().lowercaseChar() in "aeiou") "an" else "a"
private fun cap(s: String) = s.replaceFirstChar { it.uppercase() }

private fun makeStory(t: Int, a: String, b: String, c: String): String = when (t) {
    0 -> "One sunny day, ${art(a)} $a went for a walk. On the way, it met ${art(b)} $b. Then they both saw ${art(c)} $c. They became best friends. The end."
    1 -> "Once upon a time, ${art(a)} $a and ${art(b)} $b wanted to play. Suddenly ${art(c)} $c came and said, can I play too? They all played together and had so much fun. The end."
    else -> "${cap(art(a))} $a was very hungry. ${cap(art(b))} $b said, follow me! ${cap(art(c))} $c showed them where to find food. Everyone ate and was happy. The end."
}

@Composable
fun StoryMakerScreen(category: Category, onBack: () -> Unit) {
    val accent = Color(0xFFCE93D8)
    val ctx = LocalContext.current
    val speaker = rememberSpeaker()
    val own = remember(category) { gameItems(category) }
    val animals = remember { gameItems(Category.ANIMALS) }
    val pool = poolFor(category, own, animals)
    var round by remember { mutableStateOf(0) }
    val choices = remember(round, pool) { pool.shuffled().take(9) }
    var picked by remember(round) { mutableStateOf(listOf<Int>()) }
    var story by remember(round) { mutableStateOf<String?>(null) }
    val text = story
    LaunchedEffect(text) { if (text != null) { Rewards.add(ctx, 2); speaker.say(text, rate = 0.8f) } }

    ScreenScaffold("Make a Story ✍️", accent, onBack) {
        if (text == null) {
            Text("Pick 3 pictures (${picked.size}/3)", fontSize = 20.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.CenterHorizontally))
            Spacer(Modifier.height(6.dp))
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.weight(1f)
            ) {
                itemsIndexed(choices) { i, g ->
                    val n = picked.indexOf(i)
                    Card(
                        onClick = {
                            picked = if (i in picked) picked - i else if (picked.size < 3) picked + i else picked
                        },
                        colors = CardDefaults.cardColors(containerColor = if (n >= 0) Color(0xFFF3E5F5) else Color.White),
                        border = BorderStroke(if (n >= 0) 4.dp else 2.dp, if (n >= 0) Color(0xFF8E24AA) else accent),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(Modifier.padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            PhotoImage(g.photo, Modifier.fillMaxWidth(0.9f))
                            Text(if (n >= 0) "${n + 1}. ${g.en}" else g.en, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                        }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = {
                    val n = picked.map { choices[it].en.lowercase() }
                    story = makeStory((0..2).random(), n[0], n[1], n[2])
                },
                enabled = picked.size == 3,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            ) { Text("✨ Make my story") }
        } else {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                picked.forEach { PhotoImage(choices[it].photo, Modifier.size(96.dp)) }
            }
            Spacer(Modifier.height(12.dp))
            Text(text, fontSize = 20.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(8.dp))
            Text("⭐ +2", fontSize = 16.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                OutlinedButton(onClick = { speaker.say(text, rate = 0.8f) }) { Text("🔊 Read again") }
                Button(onClick = { round++ }) { Text("New story ▶") }
            }
        }
    }
}
