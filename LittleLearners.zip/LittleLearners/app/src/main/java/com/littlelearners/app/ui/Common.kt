@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.littlelearners.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.littlelearners.app.Speaker
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale

/** Page frame: back button + title + content. */
@Composable
fun ScreenScaffold(
    title: String,
    accent: Color,
    onBack: () -> Unit,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Button(onClick = onBack, modifier = Modifier.height(52.dp)) { Text("⬅", fontSize = 22.sp) }
            Spacer(Modifier.width(12.dp))
            Text(
                title,
                style = MaterialTheme.typography.headlineLarge.copy(fontSize = 26.sp),
                color = MaterialTheme.colorScheme.primary
            )
        }
        Spacer(Modifier.height(8.dp))
        Box(Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)).background(accent))
        Spacer(Modifier.height(10.dp))
        content()
    }
}

@Composable
fun TabsBar(tabs: List<String>, selected: Int, accent: Color, onSelect: (Int) -> Unit) {
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        tabs.forEachIndexed { i, label ->
            val on = i == selected
            Card(
                onClick = { onSelect(i) },
                colors = CardDefaults.cardColors(containerColor = if (on) accent else Color.White),
                border = BorderStroke(2.dp, accent),
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    label,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp),
                    textAlign = TextAlign.Center,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            }
        }
    }
}

// ---------------- Quiz ----------------

data class Option(val label: String, val color: Color? = null)

data class Question(
    val prompt: String,
    val big: String,
    val options: List<Option>,
    val correct: Int,
    val say: String? = null,
    val sayLocale: Locale = Locale.US
)

/**
 * Generic multiple-choice quiz. Wrong answer = "Try again" (no penalty screen, toddler friendly);
 * score counts questions answered correctly on the first try.
 */
@Composable
fun QuizView(
    accent: Color,
    speaker: Speaker,
    newRound: () -> List<Question>
) {
    var round by remember { mutableStateOf(0) }
    val questions = remember(round) { newRound() }
    var index by remember(round) { mutableStateOf(0) }
    var score by remember(round) { mutableStateOf(0) }
    var missed by remember(round, index) { mutableStateOf(false) }
    var message by remember(round, index) { mutableStateOf("") }
    var locked by remember(round, index) { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    if (index >= questions.size) {
        Column(
            Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("🎉", fontSize = 80.sp)
            Text("Well done!", style = MaterialTheme.typography.headlineLarge)
            Text("$score / ${questions.size}  ⭐", fontSize = 32.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(20.dp))
            Button(
                onClick = { round++ },
                modifier = Modifier.height(64.dp).fillMaxWidth(0.7f)
            ) { Text("Play again", fontSize = 20.sp) }
        }
        return
    }

    val q = questions[index]
    LaunchedEffect(round, index) { q.say?.let { speaker.say(it, q.sayLocale) } }

    Column(
        Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Question ${index + 1} / ${questions.size}", fontSize = 14.sp, color = Color.Gray)
        Spacer(Modifier.height(6.dp))
        Text(q.prompt, fontSize = 20.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        Spacer(Modifier.height(10.dp))
        Card(
            onClick = { q.say?.let { speaker.say(it, q.sayLocale) } },
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(3.dp, accent),
            shape = RoundedCornerShape(28.dp),
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(q.big, fontSize = 44.sp, textAlign = TextAlign.Center, lineHeight = 56.sp)
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(message, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.height(34.dp))
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            q.options.forEachIndexed { i, opt ->
                Card(
                    onClick = {
                        if (locked) return@Card
                        if (i == q.correct) {
                            locked = true
                            if (!missed) score++
                            message = "🌟 Great!"
                            scope.launch {
                                delay(800)
                                index++
                            }
                        } else {
                            missed = true
                            message = "Try again 🙂"
                        }
                    },
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(3.dp, accent),
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(100.dp)
                ) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        if (opt.color != null) {
                            Box(
                                Modifier
                                    .size(64.dp)
                                    .clip(CircleShape)
                                    .background(opt.color)
                                    .padding(2.dp)
                            )
                        } else {
                            Text(opt.label, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold)
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}

/** Builds options = correct + distractors, shuffled; returns the options and correct index. */
fun <T> buildChoices(correct: T, pool: List<T>, count: Int = 3): Pair<List<T>, Int> {
    val wrong = pool.filter { it != correct }.shuffled().take(count - 1)
    val all = (wrong + correct).shuffled()
    return all to all.indexOf(correct)
}
