@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.littlelearners.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.littlelearners.app.Rewards
import com.littlelearners.app.UrduLocale
import com.littlelearners.app.rememberSpeaker
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private class Rhyme(
    val title: String,
    val photo: String,
    val lines: List<String>,
    val urdu: Boolean = false,
    val lullaby: Boolean = false
)

// All rhymes and lullabies below are original, written for this app.
private val rhymes = listOf(
    Rhyme("Little Lion", "an_lion", listOf(
        "Little lion, big and bold,", "Golden mane, a heart of gold.",
        "Roar, roar, roar so loud,", "Be so brave and kind and proud.")),
    Rhyme("Duck in the Pond", "bi_duck", listOf(
        "Quack quack, little duck,", "Splash in the pond, what good luck!",
        "Paddle left and paddle right,", "Fluffy feathers, clean and bright.")),
    Rhyme("Busy Bee", "in_bee", listOf(
        "Buzz buzz, busy bee,", "Fly from flower to flower with me.",
        "Sweet honey in the hive,", "Happy bees, so alive!")),
    Rhyme("Big Elephant", "an_elephant", listOf(
        "One big elephant walks along,", "Two big ears and a happy song.",
        "Three big steps and four big toes,", "Five, away the elephant goes!")),
    Rhyme("ننھی چڑیا", "bi_sparrow", listOf(
        "ننھی چڑیا چوں چوں چوں،", "صبح سویرے گاتی ہوں۔",
        "دانہ چگتی، پانی پیتی،", "ٹہنی پر اڑ جاتی ہوں۔"), urdu = true),
    Rhyme("پیارا ہاتھی", "an_elephant", listOf(
        "موٹا ہاتھی جھوم کے آیا،", "لمبی سونڈ ہلاتا آیا۔",
        "پانی پی کر پھوار اڑائی،", "سب بچوں کو خوب ہنسایا۔"), urdu = true),
    Rhyme("رنگ برنگی تتلی", "in_butterfly", listOf(
        "رنگ برنگی تتلی آئی،", "پھولوں پر وہ اڑتی آئی۔",
        "پنکھ ہلا کر ناچ دکھایا،", "سب نے مل کر تالی بجائی۔"), urdu = true),
    Rhyme("بطخ", "bi_duck", listOf(
        "بطخ بولی قیں قیں قیں،", "تالاب میں تیرتی ہوں میں۔",
        "پانی میں وہ پیر چلائے،", "ننھی منی پیاری بطخ۔"), urdu = true),
    Rhyme("Sleepy Moon", "bi_owl", listOf(
        "Close your eyes, the moon is high,", "Little stars light up the sky.",
        "Owl says hoo, it is time for bed,", "Rest your sleepy little head."), lullaby = true),
    Rhyme("Good Night Little Lamb", "an_sheep", listOf(
        "Little lamb, it is time to sleep,", "Count the stars, not a peep.",
        "Soft and warm, snuggle tight,", "Sweet dreams, little lamb, good night."), lullaby = true),
    Rhyme("چاند اور تارے", "bi_owl", listOf(
        "چاند نکلا، تارے آئے،", "نیند کے سارے سپنے لائے۔",
        "آنکھیں بند کرو اب منے،", "میٹھی نیند تمہیں بلائے۔"), urdu = true, lullaby = true),
    Rhyme("سو جا ننھے بھیڑ کے بچے", "an_sheep", listOf(
        "سو جا ننھے بھیڑ کے بچے،", "رات ہوئی ہے سو جا بچے۔",
        "امی تیرے پاس کھڑی ہیں،", "میٹھے سپنے دیکھ لے بچے۔"), urdu = true, lullaby = true)
)

@Composable
fun RhymesScreen(onBack: () -> Unit) {
    val accent = Color(0xFFD1C4E9)
    var tab by remember { mutableStateOf(0) }
    var current by remember { mutableStateOf<Rhyme?>(null) }
    val open = current

    ScreenScaffold(open?.title ?: "Rhymes & Lullabies 🎶", accent, { if (open != null) current = null else onBack() }) {
        if (open == null) {
            TabsBar(listOf("English", "اردو", "😴 Lullabies"), tab, accent) { tab = it }
            Spacer(Modifier.height(8.dp))
            Column(Modifier.verticalScroll(rememberScrollState())) {
                rhymes.filter {
                    when (tab) { 0 -> !it.urdu && !it.lullaby; 1 -> it.urdu && !it.lullaby; else -> it.lullaby }
                }.forEach { r ->
                    Card(
                        onClick = { current = r },
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        border = BorderStroke(3.dp, accent),
                        shape = RoundedCornerShape(18.dp),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)
                    ) {
                        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            PhotoImage(r.photo, Modifier.size(70.dp))
                            Spacer(Modifier.padding(6.dp))
                            Text(r.title, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        } else {
            RhymePlayer(open, accent)
        }
    }
}

@Composable
private fun RhymePlayer(r: Rhyme, accent: Color) {
    val ctx = LocalContext.current
    val speaker = rememberSpeaker()
    val scope = rememberCoroutineScope()
    var lit by remember(r) { mutableStateOf(-1) }
    var job by remember(r) { mutableStateOf<Job?>(null) }
    val locale = if (r.urdu) UrduLocale else java.util.Locale.US
    val rate = if (r.lullaby) 0.65f else 0.8f
    DisposableEffect(r) { onDispose { job?.cancel() } }

    Column(Modifier.verticalScroll(rememberScrollState()), horizontalAlignment = Alignment.CenterHorizontally) {
        PhotoImage(r.photo, Modifier.size(160.dp))
        Spacer(Modifier.height(10.dp))
        r.lines.forEachIndexed { i, line ->
            Text(
                line,
                fontSize = if (i == lit) 26.sp else 22.sp,
                fontWeight = if (i == lit) FontWeight.ExtraBold else FontWeight.Normal,
                color = if (i == lit) Color(0xFF7E57C2) else Color.Unspecified,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)
            )
        }
        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = {
                job?.cancel()
                job = scope.launch {
                    for (i in r.lines.indices) {
                        lit = i
                        speaker.say(r.lines[i], locale, rate)
                        delay((r.lines[i].length * (if (r.lullaby) 130L else 100L)).coerceAtLeast(1800L))
                    }
                    lit = -1
                    Rewards.add(ctx, 1)
                }
            }) { Text(if (r.lullaby) "😴 Sing softly" else "▶ Sing") }
            OutlinedButton(onClick = { job?.cancel(); lit = -1 }) { Text("⏹ Stop") }
        }
    }
}
