package com.littlelearners.app.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.littlelearners.app.LearningModule
import com.littlelearners.app.ParentStore
import com.littlelearners.app.Rewards
import com.littlelearners.app.Speaker
import kotlinx.coroutines.launch
import java.util.Calendar

/** An emoji that gently bounces up and down. */
@Composable
fun BouncyEmoji(emoji: String, size: Int, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "bounce")
    val y by t.animateFloat(
        0f, 1f, infiniteRepeatable(tween(850, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "y"
    )
    Box(modifier.offset(y = (-12 * y).dp)) { EmojiView(emoji, size) }
}

private fun greeting(): Pair<String, String> {
    val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    return when {
        h < 12 -> "Good morning" to "صبح بخیر"
        h < 17 -> "Good afternoon" to "سلام"
        else -> "Good evening" to "شام بخیر"
    }
}

@Composable
private fun Pill(emoji: String, value: String, bg: Color, onClick: (() -> Unit)?) {
    Row(
        Modifier
            .background(bg, RoundedCornerShape(24.dp))
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        EmojiView(emoji, 22)
        Spacer(Modifier.width(4.dp))
        Text(value, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF3E2723))
    }
}

/** Who is playing, a time-of-day greeting, the star count (opens the Sticker Book) and the day streak. */
@Composable
fun StatsRow(onOpenStickers: () -> Unit) {
    val ctx = LocalContext.current
    val stars = remember { Rewards.stars(ctx) }
    val streak = remember { ParentStore.streak(ctx) }
    val id = ParentStore.profileId(ctx)
    val avatar = ParentStore.avatars.getOrElse(id) { "🐯" }
    val name = ParentStore.profileLabel(ctx, id)
    val (en, ur) = remember { greeting() }
    Row(
        Modifier
            .fillMaxWidth()
            .background(Color.White.copy(alpha = 0.85f), RoundedCornerShape(28.dp))
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        EmojiView(avatar, 40)
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f)) {
            Text("$en, $name!", fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            Text(ur, fontSize = 14.sp, color = Color(0xFF6D4C41), maxLines = 1)
        }
        Pill("⭐", "$stars", Color(0xFFFFF59D), onOpenStickers)
        Spacer(Modifier.width(6.dp))
        Pill("🔥", "$streak", Color(0xFFFFCCBC), null)
    }
}

private val luluTips = listOf(
    "Hello! I am Lulu. Let's learn something fun today!",
    "Tap a picture to start playing!",
    "Every 2 stars give you a new sticker!",
    "Can you find the animals? Roar!",
    "Count with me: one, two, three!",
    "Let's draw and colour a picture!",
    "Learning is fun. Great job, friend!"
)

/** Lulu the owl: tap her and she jumps, says something and shows it in a speech bubble. */
@Composable
fun LuluCard(speaker: Speaker) {
    var idx by remember { mutableStateOf(0) }
    val jump = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    Row(
        Modifier
            .fillMaxWidth()
            .background(Color(0xFFE1F5FE), RoundedCornerShape(28.dp))
            .clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) {
                idx = (idx + 1) % luluTips.size
                speaker.say(luluTips[idx])
                scope.launch {
                    jump.snapTo(0f)
                    jump.animateTo(1f, tween(220))
                    jump.animateTo(0f, tween(260))
                }
            }
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.graphicsLayer { translationY = -jump.value * 40f; rotationZ = jump.value * 12f }) {
            BouncyEmoji("🦉", 56)
        }
        Spacer(Modifier.width(10.dp))
        Box(
            Modifier
                .weight(1f)
                .background(Color.White, RoundedCornerShape(topStart = 4.dp, topEnd = 20.dp, bottomEnd = 20.dp, bottomStart = 20.dp))
                .padding(12.dp)
        ) {
            Column {
                Text(luluTips[idx], fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF01579B))
                Text("👆 Tap me!", fontSize = 11.sp, color = Color.Gray)
            }
        }
    }
}

/** Big "Continue" card for the activity the child opened last. */
@Composable
fun ContinueCard(module: LearningModule, onClick: () -> Unit) {
    val t = rememberInfiniteTransition(label = "cont")
    val pulse by t.animateFloat(
        1f, 1.06f, infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulse"
    )
    Row(
        Modifier
            .fillMaxWidth()
            .background(module.color, RoundedCornerShape(28.dp))
            .clickable { onClick() }
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        EmojiView(module.emoji, 44)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("Continue playing", fontSize = 12.sp, color = Color(0xFF424242))
            Text(module.title, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF212121), maxLines = 1)
        }
        Box(
            Modifier
                .graphicsLayer { scaleX = pulse; scaleY = pulse }
                .background(Color(0xFF7B3FA0), CircleShape)
                .padding(horizontal = 16.dp, vertical = 10.dp)
        ) { Text("▶", fontSize = 20.sp, color = Color.White) }
    }
}
