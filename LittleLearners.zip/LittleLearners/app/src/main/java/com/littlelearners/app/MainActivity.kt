package com.littlelearners.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.littlelearners.app.ui.HomeScreen
import com.littlelearners.app.ui.LittleLearnersTheme
import com.littlelearners.app.ui.ModuleScreen
import com.littlelearners.app.ui.ParentGateScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = Prefs(applicationContext)

        setContent {
            LittleLearnersTheme {
                val nav = rememberNavController()
                var category by remember { mutableStateOf(prefs.lastCategory) }

                NavHost(navController = nav, startDestination = "home") {
                    composable("home") {
                        HomeScreen(
                            selected = category,
                            onCategorySelected = {
                                category = it
                                prefs.lastCategory = it   // remembered locally
                            },
                            onOpenModule = { nav.navigate("module/${it.name}") },
                            onOpenParents = { nav.navigate("parents") }
                        )
                    }
                    composable("module/{id}") { entry ->
                        val module = LearningModule.valueOf(entry.arguments?.getString("id") ?: "NUMBERS")
                        ModuleScreen(module, category, onBack = { nav.popBackStack() })
                    }
                    composable("parents") {
                        ParentGateScreen(onBack = { nav.popBackStack() })
                    }
                }
            }
        }
    }
}
