package com.littlelearners.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.littlelearners.app.ui.HomeScreen
import com.littlelearners.app.ui.LittleLearnersTheme
import com.littlelearners.app.ui.ModuleRouter
import com.littlelearners.app.ui.ParentGateScreen
import com.littlelearners.app.ui.TimeUpScreen
import com.littlelearners.app.ui.WelcomeFlow
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    private var resumed = false

    override fun onResume() { super.onResume(); resumed = true }
    override fun onPause() { resumed = false; super.onPause() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = Prefs(applicationContext)

        setContent {
            LittleLearnersTheme {
                val nav = rememberNavController()
                var timeUp by remember { mutableStateOf(ParentStore.timeUp(applicationContext)) }
                LaunchedEffect(Unit) {
                    // count only the seconds the app is on screen
                    while (true) {
                        delay(1000)
                        if (resumed && !timeUp) {
                            ParentStore.addUsed(applicationContext, 1)
                            if (ParentStore.timeUp(applicationContext)) timeUp = true
                        }
                    }
                }
                if (timeUp) {
                    TimeUpScreen(onExtend = {
                        ParentStore.grantExtra(applicationContext, 15)
                        timeUp = ParentStore.timeUp(applicationContext)
                    })
                } else {
                WelcomeFlow()
                var category by remember { mutableStateOf(prefs.lastCategory) }

                NavHost(navController = nav, startDestination = "home") {
                    composable("home") {
                        HomeScreen(
                            selected = category,
                            onCategorySelected = {
                                category = it
                                prefs.lastCategory = it   // remembered locally
                            },
                            onOpenModule = { nav.navigate("module/${it.name}") },
                            onOpenParents = { nav.navigate("parents") }
                        )
                    }
                    composable("module/{id}") { entry ->
                        val module = LearningModule.valueOf(entry.arguments?.getString("id") ?: "NUMBERS")
                        LaunchedEffect(module) { ParentStore.openModule(applicationContext, module) }
                        ModuleRouter(module, category, onBack = { nav.popBackStack() })
                    }
                    composable("parents") {
                        ParentGateScreen(onBack = { nav.popBackStack() })
                    }
                }
                }
            }
        }
    }
}
