@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.littlelearners.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.littlelearners.app.rememberSpeaker

private data class Critter(val photo: String, val name: String, val sound: String, val say: String)

/** Animals whose sound is well known. Photos come from the animal/bird/insect/sea sets. */
private val critters = listOf(
    Critter("an_cow", "Cow", "Moo!", "Moo moo"),
    Critter("an_sheep", "Sheep", "Baa!", "Baa baa"),
    Critter("an_goat", "Goat", "Meh!", "Meh eh eh"),
    Critter("an_horse", "Horse", "Neigh!", "Neigh"),
    Critter("an_donkey", "Donkey", "Hee-haw!", "Hee haw"),
    Critter("an_lion", "Lion", "Roar!", "Roar"),
    Critter("an_tiger", "Tiger", "Grrr!", "Grrr roar"),
    Critter("an_elephant", "Elephant", "Toot!", "Toot toot"),
    Critter("an_wolf", "Wolf", "Howl!", "Ow oooo"),
    Critter("an_snake", "Snake", "Hiss!", "Ssss"),
    Critter("an_owl", "Owl", "Hoo hoo!", "Hoo hoo"),
    Critter("an_monkey", "Monkey", "Ooh ooh!", "Ooh ooh ah ah"),
    Critter("bi_rooster", "Rooster", "Cock-a-doodle-doo!", "Cock a doodle doo"),
    Critter("bi_hen", "Hen", "Cluck!", "Cluck cluck"),
    Critter("bi_duck", "Duck", "Quack!", "Quack quack"),
    Critter("bi_crow", "Crow", "Caw!", "Caw caw"),
    Critter("bi_goose", "Goose", "Honk!", "Honk honk"),
    Critter("bi_pigeon", "Pigeon", "Coo!", "Coo coo"),
    Critter("bi_turkey", "Turkey", "Gobble!", "Gobble gobble"),
    Critter("in_bee", "Bee", "Buzz!", "Buzz zz"),
    Critter("in_mosquito", "Mosquito", "Bzzz!", "Bzzzz"),
    Critter("se_dolphin", "Dolphin", "Click!", "Eee eee click")
)

@Composable
fun AnimalSoundsScreen(onBack: () -> Unit) {
    val accent = Color(0xFFC5E1A5)
    val speaker = rememberSpeaker()
    var tab by remember { mutableStateOf(0) }
    var last by remember { mutableStateOf<Critter?>(null) }

    ScreenScaffold("Animal Sounds 🐘", accent, onBack) {
        TabsBar(listOf("Listen", "Who says?"), tab, accent) { tab = it }
        Spacer(Modifier.height(10.dp))
        if (tab == 0) {
            Text(
                last?.let { "${it.name} says ${it.sound}" } ?: "Tap an animal to hear it!",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
            )
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(critters) { c ->
                    Card(
                        onClick = { last = c; speaker.say(c.say) },
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        border = BorderStroke(3.dp, if (last == c) Color(0xFFFF8A65) else accent),
                        shape = RoundedCornerShape(18.dp),
                        modifier = Modifier.fillMaxWidth().aspectRatio(0.9f)
                    ) {
                        Column(
                            Modifier.fillMaxSize().padding(4.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            PhotoImage(c.photo, Modifier.fillMaxWidth(0.85f))
                            Text("🔊 ${c.name}", fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                        }
                    }
                }
            }
        } else {
            QuizView(accent, speaker, "Worlds") {
                critters.shuffled().take(5).map { c ->
                    val wrong = critters.filter { it.name != c.name }.shuffled().take(2)
                    val opts = (wrong + c).shuffled()
                    Question(
                        prompt = "Who says this?",
                        big = "🔊 ${c.sound}",
                        bigSize = 30,
                        options = opts.map { Option(it.name) },
                        correct = opts.indexOf(c),
                        say = c.say
                    )
                }
            }
        }
    }
}

private data class World(val title: String, val emoji: String, val color: Color, val photos: List<Pair<String, String>>)

private val worlds = listOf(
    World("Farm", "🐄", Color(0xFFFFCC80), listOf(
        "an_cow" to "Cow", "an_sheep" to "Sheep", "an_goat" to "Goat", "an_horse" to "Horse",
        "an_donkey" to "Donkey", "bi_hen" to "Hen", "bi_rooster" to "Rooster", "bi_duck" to "Duck", "bi_goose" to "Goose"
    )),
    World("Jungle", "🦁", Color(0xFFA5D6A7), listOf(
        "an_lion" to "Lion", "an_tiger" to "Tiger", "an_elephant" to "Elephant", "an_giraffe" to "Giraffe",
        "an_zebra" to "Zebra", "an_monkey" to "Monkey", "an_leopard" to "Leopard", "an_cheetah" to "Cheetah", "an_snake" to "Snake"
    )),
    World("Ocean", "🐬", Color(0xFF81D4FA), listOf(
        "se_dolphin" to "Dolphin", "se_whale" to "Whale", "se_turtle" to "Turtle", "se_seahorse" to "Seahorse",
        "se_starfish" to "Starfish", "se_jellyfish" to "Jellyfish", "se_octopus" to "Octopus", "se_clownfish" to "Clownfish", "se_lobster" to "Lobster"
    )),
    World("Sky", "🦅", Color(0xFFB3E5FC), listOf(
        "bi_eagle" to "Eagle", "bi_owl" to "Owl", "bi_parrot" to "Parrot", "bi_swan" to "Swan",
        "bi_flamingo" to "Flamingo", "bi_peacock" to "Peacock", "bi_hummingbird" to "Hummingbird", "bi_toucan" to "Toucan", "in_butterfly" to "Butterfly"
    )),
    World("Garden", "🐝", Color(0xFFF0F4C3), listOf(
        "in_bee" to "Bee", "in_butterfly" to "Butterfly", "in_ant" to "Ant", "in_spider" to "Spider",
        "in_dragonfly" to "Dragonfly", "in_grasshopper" to "Grasshopper", "in_caterpillar" to "Caterpillar", "in_firefly" to "Firefly", "in_mantis" to "Mantis"
    ))
)

/** Interactive Worlds: pick a world, tap any picture to hear its name, or play "Find the ...". */
@Composable
fun WorldsScreen(onBack: () -> Unit) {
    val speaker = rememberSpeaker()
    var w by remember { mutableStateOf(0) }
    var mode by remember { mutableStateOf(0) }
    val world = worlds[w]

    ScreenScaffold("Worlds ${world.emoji}", world.color, onBack) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            worlds.forEachIndexed { i, x ->
                Card(
                    onClick = { w = i },
                    colors = CardDefaults.cardColors(containerColor = if (i == w) x.color else Color(0xFFF5F5F5)),
                    border = BorderStroke(2.dp, x.color),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Box(Modifier.fillMaxWidth().padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
                        Text(x.emoji, fontSize = 24.sp)
                    }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        TabsBar(listOf("Explore", "Find it"), mode, world.color) { mode = it }
        Spacer(Modifier.height(8.dp))
        if (mode == 0) {
            Text("${world.title} World", fontSize = 20.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.CenterHorizontally))
            Spacer(Modifier.height(6.dp))
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(world.photos) { (photo, name) ->
                    Card(
                        onClick = { speaker.say(name) },
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        border = BorderStroke(3.dp, world.color),
                        shape = RoundedCornerShape(18.dp),
                        modifier = Modifier.fillMaxWidth().aspectRatio(0.9f)
                    ) {
                        Column(
                            Modifier.fillMaxSize().padding(4.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            PhotoImage(photo, Modifier.fillMaxWidth(0.85f))
                            Text(name, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                        }
                    }
                }
            }
        } else {
            QuizView(world.color, speaker, "Worlds") {
                world.photos.shuffled().take(5).map { (photo, name) ->
                    val wrong = world.photos.filter { it.first != photo }.shuffled().take(2)
                    val opts = (wrong + (photo to name)).shuffled()
                    Question(
                        prompt = "Find the $name",
                        big = "",
                        options = opts.map { Option(it.second) },
                        correct = opts.indexOfFirst { it.first == photo },
                        say = name,
                        photo = photo
                    )
                }
            }
        }
    }
}
