@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.littlelearners.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.littlelearners.app.Rewards
import com.littlelearners.app.rememberSpeaker

private class Page(val photos: List<String>, val text: String)
private class Story(val title: String, val cover: String, val pages: List<Page>)

private val stories = listOf(
    Story("The Little Caterpillar", "in_caterpillar", listOf(
        Page(listOf("in_caterpillar"), "Once there was a little caterpillar. He was very hungry."),
        Page(listOf("in_caterpillar", "in_ant"), "He ate and ate all day. His friend the ant said, you are getting big!"),
        Page(listOf("in_moth"), "One day the caterpillar made a cozy home and went to sleep."),
        Page(listOf("in_butterfly"), "When he woke up, he was a beautiful butterfly! He flew up to the sky. The end.")
    )),
    Story("The Thirsty Crow", "bi_crow", listOf(
        Page(listOf("bi_crow"), "It was a hot sunny day. A crow was very thirsty."),
        Page(listOf("bi_crow"), "He found a pot with a little water at the bottom. But his beak could not reach it."),
        Page(listOf("bi_crow"), "The clever crow dropped small stones into the pot, one by one."),
        Page(listOf("bi_crow"), "The water came up! The crow drank and was happy. Being clever helps us. The end.")
    )),
    Story("The Kind Elephant", "an_elephant", listOf(
        Page(listOf("an_elephant"), "Ellie the elephant lived near a big river."),
        Page(listOf("an_elephant", "an_monkey"), "One day a little monkey could not cross the water. He was scared."),
        Page(listOf("an_elephant", "an_monkey"), "Ellie said, jump on my back! I will carry you."),
        Page(listOf("an_monkey", "an_rabbit"), "The monkey and his friend the rabbit said thank you. Being kind makes everyone happy. The end.")
    )),
    Story("The Brave Duckling", "bi_duck", listOf(
        Page(listOf("bi_duck"), "A little duckling loved to swim in the pond."),
        Page(listOf("bi_duck", "an_fox"), "One day a sly fox came near the pond. The duckling was scared, but he was brave."),
        Page(listOf("bi_duck", "bi_goose"), "He called, quack quack! The big goose heard him and came running."),
        Page(listOf("bi_duck", "bi_goose"), "The fox ran away. The duckling said thank you. Calling for help is brave. The end.")
    )),
    Story("The Busy Bee", "in_bee", listOf(
        Page(listOf("in_bee"), "Buzzy the bee woke up early in the morning."),
        Page(listOf("in_bee", "in_butterfly"), "She flew to the garden and said hello to the butterfly."),
        Page(listOf("in_bee"), "She collected sweet nectar from many flowers."),
        Page(listOf("in_bee"), "She took it home and made yummy honey for everyone. Hard work is sweet. The end.")
    ))
)

@Composable
fun StoriesScreen(onBack: () -> Unit) {
    val accent = Color(0xFFF48FB1)
    val ctx = LocalContext.current
    val speaker = rememberSpeaker()
    var current by remember { mutableStateOf<Story?>(null) }
    var page by remember { mutableStateOf(0) }

    val story = current
    ScreenScaffold(story?.title ?: "Stories 📖", accent, { if (story != null) current = null else onBack() }) {
        if (story == null) {
            stories.forEach { s ->
                Card(
                    onClick = { current = s; page = 0 },
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(3.dp, accent),
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)
                ) {
                    Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        PhotoImage(s.cover, Modifier.size(70.dp))
                        Spacer(Modifier.padding(6.dp))
                        Text(s.title, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        } else {
            val p = story.pages[page]
            val last = page == story.pages.size - 1
            LaunchedEffect(story, page) { speaker.say(p.text) }
            LaunchedEffect(story, last) { if (last) Rewards.add(ctx, 2) }
            Text("Page ${page + 1} / ${story.pages.size}", fontSize = 14.sp, color = Color.Gray,
                modifier = Modifier.align(Alignment.CenterHorizontally))
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                p.photos.forEach { PhotoImage(it, Modifier.weight(1f).padding(6.dp)) }
            }
            Spacer(Modifier.height(10.dp))
            Text(p.text, fontSize = 22.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(8.dp))
            Spacer(Modifier.height(10.dp))
            Button(onClick = { speaker.say(p.text) }, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                Text("🔊 Read to me")
            }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                OutlinedButton(onClick = { if (page > 0) page-- }, enabled = page > 0) { Text("◀ Back") }
                if (last) Button(onClick = { current = null }) { Text("🎉 Finish") }
                else Button(onClick = { page++ }) { Text("Next ▶") }
            }
        }
    }
}
