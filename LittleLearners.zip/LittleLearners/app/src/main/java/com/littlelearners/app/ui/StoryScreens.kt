@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.littlelearners.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.littlelearners.app.Rewards
import com.littlelearners.app.UrduLocale
import com.littlelearners.app.rememberSpeaker

private class Page(val photos: List<String>, val text: String)
private class Story(val title: String, val cover: String, val pages: List<Page>, val urdu: Boolean = false)

private val stories = listOf(
    Story("The Little Caterpillar", "in_caterpillar", listOf(
        Page(listOf("in_caterpillar"), "Once there was a little caterpillar. He was very hungry."),
        Page(listOf("in_caterpillar", "in_ant"), "He ate and ate all day. His friend the ant said, you are getting big!"),
        Page(listOf("in_moth"), "One day the caterpillar made a cozy home and went to sleep."),
        Page(listOf("in_butterfly"), "When he woke up, he was a beautiful butterfly! He flew up to the sky. The end.")
    )),
    Story("The Thirsty Crow", "bi_crow", listOf(
        Page(listOf("bi_crow"), "It was a hot sunny day. A crow was very thirsty."),
        Page(listOf("bi_crow"), "He found a pot with a little water at the bottom. But his beak could not reach it."),
        Page(listOf("bi_crow"), "The clever crow dropped small stones into the pot, one by one."),
        Page(listOf("bi_crow"), "The water came up! The crow drank and was happy. Being clever helps us. The end.")
    )),
    Story("The Kind Elephant", "an_elephant", listOf(
        Page(listOf("an_elephant"), "Ellie the elephant lived near a big river."),
        Page(listOf("an_elephant", "an_monkey"), "One day a little monkey could not cross the water. He was scared."),
        Page(listOf("an_elephant", "an_monkey"), "Ellie said, jump on my back! I will carry you."),
        Page(listOf("an_monkey", "an_rabbit"), "The monkey and his friend the rabbit said thank you. Being kind makes everyone happy. The end.")
    )),
    Story("The Brave Duckling", "bi_duck", listOf(
        Page(listOf("bi_duck"), "A little duckling loved to swim in the pond."),
        Page(listOf("bi_duck", "an_fox"), "One day a sly fox came near the pond. The duckling was scared, but he was brave."),
        Page(listOf("bi_duck", "bi_goose"), "He called, quack quack! The big goose heard him and came running."),
        Page(listOf("bi_duck", "bi_goose"), "The fox ran away. The duckling said thank you. Calling for help is brave. The end.")
    )),
    Story("The Busy Bee", "in_bee", listOf(
        Page(listOf("in_bee"), "Buzzy the bee woke up early in the morning."),
        Page(listOf("in_bee", "in_butterfly"), "She flew to the garden and said hello to the butterfly."),
        Page(listOf("in_bee"), "She collected sweet nectar from many flowers."),
        Page(listOf("in_bee"), "She took it home and made yummy honey for everyone. Hard work is sweet. The end.")
    )),
    Story("The Sleepy Lion", "an_lion", listOf(
        Page(listOf("an_lion"), "Leo the lion was very sleepy. He yawned a big yawn."),
        Page(listOf("an_lion", "bi_owl"), "The owl said, hoo hoo, it is bedtime. Close your eyes."),
        Page(listOf("an_lion", "an_monkey"), "The monkey sang a soft song, la la la."),
        Page(listOf("an_lion"), "Leo closed his eyes and went to sleep. Good night, Leo. The end.")
    )),
    Story("The Turtle and the Rabbit", "an_rabbit", listOf(
        Page(listOf("an_rabbit", "se_turtle"), "A fast rabbit and a slow turtle wanted to have a race."),
        Page(listOf("an_rabbit"), "The rabbit ran very fast. Then he sat down to take a nap."),
        Page(listOf("se_turtle"), "The turtle kept walking, slowly, slowly, and did not stop."),
        Page(listOf("an_rabbit", "se_turtle"), "The turtle reached the end first! Never give up. The end.")
    )),
    Story("Sharing is Caring", "an_panda", listOf(
        Page(listOf("an_panda"), "Pinky the panda had a big pile of yummy bamboo."),
        Page(listOf("an_panda", "an_zebra"), "A hungry zebra came by. He said, may I have some, please?"),
        Page(listOf("an_panda", "an_zebra"), "Pinky smiled and shared her bamboo with the zebra."),
        Page(listOf("an_panda", "an_zebra"), "Now they were both happy and full. Sharing is caring. The end.")
    )),
    Story("The Little Penguin", "bi_penguin", listOf(
        Page(listOf("bi_penguin"), "A little penguin lived on the cold, white ice."),
        Page(listOf("bi_penguin", "se_seal"), "He met a friendly seal. The seal said, let us slide on the ice!"),
        Page(listOf("bi_penguin", "se_seal"), "Whee! They slid down the ice again and again."),
        Page(listOf("bi_penguin"), "The little penguin went home with a big smile. The end.")
    )),
    Story("Friends of the Ocean", "se_dolphin", listOf(
        Page(listOf("se_dolphin"), "Deep in the blue ocean lived a happy dolphin."),
        Page(listOf("se_dolphin", "se_octopus"), "He met an octopus with eight long arms. Hello, said the octopus!"),
        Page(listOf("se_starfish", "se_seahorse"), "A starfish and a seahorse came to say hello too."),
        Page(listOf("se_dolphin", "se_octopus", "se_seahorse"), "All the ocean friends played together all day. The end.")
    )),
    Story("The Proud Peacock", "bi_peacock", listOf(
        Page(listOf("bi_peacock"), "A peacock had beautiful, colorful feathers. He felt very proud."),
        Page(listOf("bi_peacock", "bi_parrot"), "A little parrot said, your feathers are lovely. Can you help me, please?"),
        Page(listOf("bi_peacock", "bi_parrot"), "The peacock was too busy showing off. The parrot felt sad."),
        Page(listOf("bi_peacock", "bi_parrot"), "The peacock said sorry and helped his friend. Be kind, not proud. The end.")
    )),
    Story("Counting Farm Animals", "an_cow", listOf(
        Page(listOf("an_cow"), "Let us count the farm animals! One cow says moo."),
        Page(listOf("an_cow", "an_sheep"), "Two sheep say baa."),
        Page(listOf("an_goat", "an_horse"), "Three goats and four horses. Count with me: three, four!"),
        Page(listOf("bi_hen"), "Five hens say cluck. We counted one, two, three, four, five. The end.")
    )),
    Story("The Lost Lamb", "an_sheep", listOf(
        Page(listOf("an_sheep"), "A little lamb walked away from her mother and got lost."),
        Page(listOf("an_sheep"), "She felt scared and said, baa baa, where is my mama?"),
        Page(listOf("an_sheep", "bi_owl"), "A wise owl saw her. Do not cry, I will help you."),
        Page(listOf("an_sheep"), "The owl led her home. Mama hugged the little lamb. The end.")
    )),
    Story("The Firefly's Light", "in_firefly", listOf(
        Page(listOf("in_firefly"), "A little firefly glowed softly in the dark night."),
        Page(listOf("in_ant"), "A tiny ant was lost and could not see the way home."),
        Page(listOf("in_firefly", "in_ant"), "The firefly said, follow my light!"),
        Page(listOf("in_firefly", "in_ant"), "The ant got home safe. Thank you, firefly! Helping is a good thing. The end.")
    )),
    Story("The Tall Giraffe", "an_giraffe", listOf(
        Page(listOf("an_giraffe"), "Gigi the giraffe was the tallest animal in the jungle."),
        Page(listOf("an_monkey", "an_zebra"), "The monkey and the zebra could not reach the sweet fruit on the tree."),
        Page(listOf("an_giraffe"), "Gigi stretched her long neck up, up, up!"),
        Page(listOf("an_giraffe", "an_monkey", "an_zebra"), "She shared the fruit with her friends. Being tall is great for helping! The end.")
    )),
    Story("پیاسا کوا", "bi_crow", listOf(
        Page(listOf("bi_crow"), "ایک گرم دن تھا۔ ایک کوا بہت پیاسا تھا۔"),
        Page(listOf("bi_crow"), "اسے ایک مٹکا ملا۔ مٹکے میں تھوڑا سا پانی تھا، مگر کوے کی چونچ وہاں تک نہیں پہنچتی تھی۔"),
        Page(listOf("bi_crow"), "کوے نے چھوٹے چھوٹے کنکر مٹکے میں ڈالے۔"),
        Page(listOf("bi_crow"), "پانی اوپر آ گیا۔ کوے نے پانی پیا اور خوش ہو گیا۔ عقل مند بنو۔ ختم شد۔")
    ), urdu = true),
    Story("خرگوش اور کچھوا", "an_rabbit", listOf(
        Page(listOf("an_rabbit", "se_turtle"), "ایک تیز خرگوش اور ایک سست کچھوے کی دوڑ ہوئی۔"),
        Page(listOf("an_rabbit"), "خرگوش بہت تیز بھاگا، پھر وہ درخت کے نیچے سو گیا۔"),
        Page(listOf("se_turtle"), "کچھوا آہستہ آہستہ چلتا رہا اور رکا نہیں۔"),
        Page(listOf("an_rabbit", "se_turtle"), "کچھوا پہلے پہنچ گیا! ہمت نہیں ہارنی چاہیے۔ ختم شد۔")
    ), urdu = true),
    Story("چھوٹی چیونٹی", "in_ant", listOf(
        Page(listOf("in_ant"), "ایک چھوٹی چیونٹی سارا دن کام کرتی تھی۔"),
        Page(listOf("in_ant"), "وہ دانے اٹھا کر اپنے گھر لے جاتی تھی۔"),
        Page(listOf("in_ant"), "سردی آئی تو چیونٹی کے پاس بہت سا کھانا تھا۔"),
        Page(listOf("in_ant"), "وہ اپنے دوستوں کے ساتھ مزے سے کھانا کھاتی رہی۔ محنت کا پھل میٹھا ہوتا ہے۔ ختم شد۔")
    ), urdu = true),
    Story("مہربان ہاتھی", "an_elephant", listOf(
        Page(listOf("an_elephant"), "ایک ہاتھی دریا کے کنارے رہتا تھا۔"),
        Page(listOf("an_elephant", "an_monkey"), "ایک ننھا بندر پانی سے ڈر رہا تھا۔"),
        Page(listOf("an_elephant", "an_monkey"), "ہاتھی نے کہا، میری پیٹھ پر بیٹھ جاؤ۔"),
        Page(listOf("an_elephant", "an_monkey"), "بندر نے شکریہ کہا۔ مہربانی سب کو خوش کرتی ہے۔ ختم شد۔")
    ), urdu = true),
    Story("شہد کی مکھی", "in_bee", listOf(
        Page(listOf("in_bee"), "ننھی مکھی صبح سویرے اٹھی۔"),
        Page(listOf("in_bee", "in_butterfly"), "وہ باغ میں گئی اور تتلی کو سلام کیا۔"),
        Page(listOf("in_bee"), "اس نے پھولوں سے میٹھا رس جمع کیا۔"),
        Page(listOf("in_bee"), "گھر جا کر اس نے سب کے لیے شہد بنایا۔ ختم شد۔")
    ), urdu = true),
    Story("تتلی کی کہانی", "in_butterfly", listOf(
        Page(listOf("in_caterpillar"), "ایک چھوٹا سا کیٹرپلر تھا۔ اسے بہت بھوک لگی تھی۔"),
        Page(listOf("in_caterpillar"), "اس نے خوب پتے کھائے اور بڑا ہو گیا۔"),
        Page(listOf("in_moth"), "پھر وہ ایک گھر میں سو گیا۔"),
        Page(listOf("in_butterfly"), "جب جاگا تو خوبصورت تتلی بن چکا تھا! ختم شد۔")
    ), urdu = true),
    Story("بھیڑ کا بچہ", "an_sheep", listOf(
        Page(listOf("an_sheep"), "ایک ننھا بھیڑ کا بچہ ماں سے بچھڑ گیا۔"),
        Page(listOf("an_sheep"), "وہ ڈر کر رونے لگا۔"),
        Page(listOf("an_sheep", "bi_owl"), "ایک الو نے اسے دیکھا اور کہا، مت رو، میں تمہاری مدد کروں گا۔"),
        Page(listOf("an_sheep", "bi_owl"), "الو اسے ماں کے پاس لے گیا۔ ماں نے اسے گلے لگا لیا۔ ختم شد۔")
    ), urdu = true),
    Story("سوتا ہوا شیر", "an_lion", listOf(
        Page(listOf("an_lion"), "شیر بہت تھکا ہوا تھا۔ اس نے بڑی سی جمائی لی۔"),
        Page(listOf("an_lion", "an_monkey"), "بندر نے اس کے لیے میٹھی لوری گائی۔"),
        Page(listOf("an_lion"), "شیر نے آنکھیں بند کیں۔"),
        Page(listOf("an_lion"), "وہ آرام سے سو گیا۔ شب بخیر! ختم شد۔")
    ), urdu = true)
)

@Composable
fun StoriesScreen(onBack: () -> Unit) {
    val accent = Color(0xFFF48FB1)
    val ctx = LocalContext.current
    val speaker = rememberSpeaker()
    var current by remember { mutableStateOf<Story?>(null) }
    var page by remember { mutableStateOf(0) }
    var lang by remember { mutableStateOf(0) }

    val story = current
    ScreenScaffold(story?.title ?: "Stories 📖", accent, { if (story != null) current = null else onBack() }) {
        if (story == null) {
          Column(Modifier.verticalScroll(rememberScrollState())) {
            TabsBar(listOf("English", "اردو"), lang, accent) { lang = it }
            Spacer(Modifier.height(8.dp))
            stories.filter { it.urdu == (lang == 1) }.forEach { s ->
                Card(
                    onClick = { current = s; page = 0 },
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(3.dp, accent),
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)
                ) {
                    Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        PhotoImage(s.cover, Modifier.size(70.dp))
                        Spacer(Modifier.padding(6.dp))
                        Text(s.title, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
          }
        } else {
            val p = story.pages[page]
            val last = page == story.pages.size - 1
            val loc = if (story.urdu) UrduLocale else java.util.Locale.US
            LaunchedEffect(story, page) { speaker.say(p.text, loc) }
            LaunchedEffect(story, last) { if (last) Rewards.add(ctx, 2) }
            Text("Page ${page + 1} / ${story.pages.size}", fontSize = 14.sp, color = Color.Gray,
                modifier = Modifier.align(Alignment.CenterHorizontally))
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                p.photos.forEach { PhotoImage(it, Modifier.weight(1f).padding(6.dp)) }
            }
            Spacer(Modifier.height(10.dp))
            Text(p.text, fontSize = 22.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(8.dp))
            Spacer(Modifier.height(10.dp))
            Button(onClick = { speaker.say(p.text, loc) }, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                Text(if (story.urdu) "🔊 سنیں" else "🔊 Read to me")
            }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                OutlinedButton(onClick = { if (page > 0) page-- }, enabled = page > 0) { Text("◀ Back") }
                if (last) Button(onClick = { current = null }) { Text("🎉 Finish") }
                else Button(onClick = { page++ }) { Text("Next ▶") }
            }
        }
    }
}
