plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.littlelearners.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.littlelearners.app"
        minSdk = 24
        targetSdk = 34
        versionCode = 2
        versionName = "1.0.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            // Debug-signed so the release APK installs for testing.
            // Replace with your own keystore before publishing to Play Store.
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.14"
    }
    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.06.00")
    implementation(composeBom)
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("androidx.navigation:navigation-compose:2.7.7")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.foundation:foundation")
    debugImplementation("androidx.compose.ui:ui-tooling")
}

// Before every build, download 3D emoji pictures (needs internet + python3; never fails the build).
tasks.register("fetchEmoji") {
    doLast {
        try {
            val script = File(rootProject.projectDir, "tools/fetch_emoji.py")
            if (script.exists()) {
                ProcessBuilder("python3", script.absolutePath)
                    .directory(rootProject.projectDir)
                    .inheritIO()
                    .start()
                    .waitFor()
            }
        } catch (e: Exception) {
            println("3D emoji download skipped: ${e.message}")
        }
    }
}
tasks.matching { it.name == "preBuild" }.configureEach { dependsOn("fetchEmoji") }
