# Little Learners (Kotlin)

Offline, ad-free, no-login toddler learning app for ages 2–5.
Native Android: **Kotlin + Jetpack Compose**. Min SDK 24 (low-end friendly).

## Status

| Phase | Scope | State |
|---|---|---|
| 1 | Home screen, 6-category switcher (remembered locally), navigation, parent gate | **Done** |
| 2 | Numbers 1–20, English ABC, Urdu alphabet (RTL), Colors, Color Mixing, quizzes, speech | **Done** |
| 3 | Tracing Center (123/ABC/Urdu), Drawing Studio, Coloring Book (4 pictures), save to gallery | **Done** |
| 4 | Mini-games, puzzles, matching, quizzes | Next |
| 5 | Audio, stories, worlds, stickers, rewards | Planned |
| 6 | Progress tracking, Parent Area, offline storage | Planned |
| 7 | Testing, bug fixing, release | Planned |

Phase 2 uses the phone's built-in text-to-speech (offline once the voice is installed; Urdu is silent if no Urdu voice is installed).
App logo: adaptive icon + legacy PNGs in `res/mipmap-*`, header logo in `res/drawable-nodpi/logo.png`.

Saved artwork goes to Pictures/LittleLearners (Android 10+) or the app's own Pictures folder on older phones; no storage permission needed.

Tiles for later phases open a "Coming in Phase N" placeholder.

## Get the APK from GitHub (no Android Studio needed)

1. Create a new GitHub repo and push this folder:
   ```bash
   git init
   git add .
   git commit -m "Phase 1: home screen and category switcher"
   git branch -M main
   git remote add origin https://github.com/<you>/LittleLearners.git
   git push -u origin main
   ```
2. Open the repo's **Actions** tab → **Build APK** run.
3. Download the `LittleLearners-debug` artifact (a zip containing the `.apk`).
4. Copy it to your phone and install (allow "install unknown apps").

## Build locally with Android Studio

1. Install Android Studio (Koala or newer) with JDK 17.
2. **File → Open** this folder, let Gradle sync (Android Studio creates the Gradle wrapper).
3. Run on a device/emulator, or **Build → Build APK(s)**.
4. Output: `app/build/outputs/apk/debug/app-debug.apk`.

Command line (with Gradle 8.7 installed): `gradle assembleDebug` / `gradle assembleRelease`.

## Release signing

The release build is signed with the debug key so it installs for testing.
Before publishing to Google Play, create your own keystore and replace the
`signingConfig` in `app/build.gradle.kts`. Never commit the keystore (it is gitignored).

## Project layout

```
app/src/main/java/com/littlelearners/app/
  MainActivity.kt        navigation (home, module placeholder, parents)
  Models.kt              Category and LearningModule definitions
  Prefs.kt               local storage (last category)
  ui/Theme.kt            rainbow/pastel theme
  ui/HomeScreen.kt       header, category switcher, module grid
  Content.kt             numbers, alphabets, colors data
  Speaker.kt             text-to-speech wrapper
  ui/Common.kt           scaffold, tabs, generic quiz
  ui/LearningScreens.kt  Numbers, ABC, Urdu, Colors, Color Mixing
  ui/DrawingEngine.kt    strokes, colorable pictures, PNG saving
  ui/CreativeScreens.kt  Tracing, Drawing Studio, Coloring Book
  ui/PlaceholderScreens.kt  module placeholder + parent gate
```

## Content from the supplied PDFs

Animals category: ABC (26 flashcards), Urdu (40 letters, photos where the PDF has one) and
Numbers (20 animal photos) come from the PDFs; photos live in `res/drawable-nodpi`
Photos live in `res/drawable-nodpi`, one prefix per category: `an_` Animals, `bi_` Birds, `in_` Insects, `se_` Sea, `vg_` Vegetables, `fr_` Fruits, `th_` Things, `ve_` Vehicles, `bo_` Body, `sh_` Shapes, `na_` Nature, `we_` Weather, `co_` Colors. The app draws letters and names itself.
Fruits (26 English, 21 Urdu letters, 20 numbers) uses the supplied fruit photo sheets. Other categories only show their own words (nothing is
Vegetables (26 English, 17 Urdu letters, 20 numbers) uses the supplied vegetable sheets: 40 photos (`vg_*`). Colors, Things and Nature are still "coming soon".
Things (26 English, 27 Urdu letters, 20 numbers) uses the supplied object sheets: 54 photos (`th_*`). Nature and Colors are still "coming soon".
Nature (26 English, 23 Urdu letters, 20 numbers) uses the supplied nature sheets: 48 photos (`na_*`). Colors (26 English, 17 Urdu, 20 numbers) uses 36 photos (`co_*`). All 6 categories now have content.
borrowed from another category) and are placeholders until their PDFs are supplied.

## 3D pictures

Before each build `tools/fetch_emoji.py` downloads 3D emoji from Microsoft's
[Fluent Emoji](https://github.com/microsoft/fluentui-emoji) (MIT licence) into
`res/drawable-nodpi/e_<codepoint>.png`. The app shows them automatically; any emoji that
could not be downloaded falls back to the normal text emoji. Needs internet + python3 at build
time (GitHub Actions has both).

## Notes

- No `INTERNET` permission: fully offline by design.
- Urdu text uses the system font with RTL support enabled (`supportsRtl`). A bundled
  Urdu font (e.g. Noto Nastaliq Urdu) will be added in Phase 2.

## Phase 4 – Part 1: Mini-Games
`GameScreens.kt`: Memory (3/6/8 pairs), Match (picture to name, English + Urdu) and Picture Puzzle (2x2 / 3x3 swap). They use the selected category pictures. Mini-Games, Matching Games and Puzzles tiles all open this screen. Quizzes, Animal Care and the rest follow in the next parts.

## Categories (13)
Animals, Birds, Insects, Sea Creatures, Vegetables, Fruits, Things, Vehicles, Body Parts, Shapes, Nature, Weather, Colors. Each has English A–Z, Urdu letters and Numbers 1–20 from the supplied photo sheets.
Known gaps: Insects has no Cricket / Housefly / Ladybug photo yet (substitutes used); Body Parts letter Q uses a hair photo.

## Phase 4 – Part 2: Quizzes
`QuizzesScreen` (in `GameScreens.kt`): Name quiz, Letter quiz, Urdu quiz (picture shown, pick the answer) and Odd-one-out (two pictures from one category, one from another, mixed across all categories). The Quizzes tile opens it.

## Phase 5 Part 1 – Rewards & Sticker Book
- `Rewards.kt`: stars saved locally (SharedPreferences). Quizzes give 1 star per correct answer, Memory +3, Match +2, Puzzle +3/+5.
- Sticker Book: every 2 stars unlock one sticker (picture) across all categories.

## Phase 5 Part 2 – Worlds & Animal Sounds
- Animal Sounds: 22 animals/birds/insects, tap to hear the sound (TTS), plus a "Who says?" quiz.
- Worlds: Farm, Jungle, Ocean, Sky, Garden. Explore (tap to hear name) and "Find it" quiz. Both give stars.

## Phase 5 Part 3 – Music & Stories
- Music: offline synthesized piano (AudioTrack, no audio files), 8 colored keys, 3 auto-play songs with lit keys.
- Stories: 5 short illustrated stories read aloud with TTS (Read to me / Next / Back); finishing gives +2 stars.

## Phase 4 – Animal Care
- Pick a pet (rabbit, horse, cow, sheep, hen, duck, panda); Feed / Water / Wash / Play / Sleep fill meters. All full = +3 stars.
