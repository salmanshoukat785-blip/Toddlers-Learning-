# Little Learners (Kotlin)

Offline, ad-free, no-login toddler learning app for ages 2–5.
Native Android: **Kotlin + Jetpack Compose**. Min SDK 24 (low-end friendly).

## Status

| Phase | Scope | State |
|---|---|---|
| 1 | Home screen, 6-category switcher (remembered locally), navigation, parent gate | **Done** |
| 2 | Numbers 1–20, English ABC, Urdu alphabet (RTL), Colors, Color Mixing, quizzes, speech | **Done** |
| 3 | Tracing Center (123/ABC/Urdu), Drawing Studio, Coloring Book (4 pictures), save to gallery | **Done** |
| 4 | Mini-games, puzzles, matching, quizzes | Next |
| 5 | Audio, stories, worlds, stickers, rewards | Planned |
| 6 | Progress tracking, Parent Area, offline storage | Planned |
| 7 | Testing, bug fixing, release | Planned |

Phase 2 uses the phone's built-in text-to-speech (offline once the voice is installed; Urdu is silent if no Urdu voice is installed).
App logo: adaptive icon + legacy PNGs in `res/mipmap-*`, header logo in `res/drawable-nodpi/logo.png`.

Saved artwork goes to Pictures/LittleLearners (Android 10+) or the app's own Pictures folder on older phones; no storage permission needed.

Tiles for later phases open a "Coming in Phase N" placeholder.

## Get the APK from GitHub (no Android Studio needed)

1. Create a new GitHub repo and push this folder:
   ```bash
   git init
   git add .
   git commit -m "Phase 1: home screen and category switcher"
   git branch -M main
   git remote add origin https://github.com/<you>/LittleLearners.git
   git push -u origin main
   ```
2. Open the repo's **Actions** tab → **Build APK** run.
3. Download the `LittleLearners-debug` artifact (a zip containing the `.apk`).
4. Copy it to your phone and install (allow "install unknown apps").

## Build locally with Android Studio

1. Install Android Studio (Koala or newer) with JDK 17.
2. **File → Open** this folder, let Gradle sync (Android Studio creates the Gradle wrapper).
3. Run on a device/emulator, or **Build → Build APK(s)**.
4. Output: `app/build/outputs/apk/debug/app-debug.apk`.

Command line (with Gradle 8.7 installed): `gradle assembleDebug` / `gradle assembleRelease`.

## Release signing

The release build is signed with the debug key so it installs for testing.
Before publishing to Google Play, create your own keystore and replace the
`signingConfig` in `app/build.gradle.kts`. Never commit the keystore (it is gitignored).

## Project layout

```
app/src/main/java/com/littlelearners/app/
  MainActivity.kt        navigation (home, module placeholder, parents)
  Models.kt              Category and LearningModule definitions
  Prefs.kt               local storage (last category)
  ui/Theme.kt            rainbow/pastel theme
  ui/HomeScreen.kt       header, category switcher, module grid
  Content.kt             numbers, alphabets, colors data
  Speaker.kt             text-to-speech wrapper
  ui/Common.kt           scaffold, tabs, generic quiz
  ui/LearningScreens.kt  Numbers, ABC, Urdu, Colors, Color Mixing
  ui/DrawingEngine.kt    strokes, colorable pictures, PNG saving
  ui/CreativeScreens.kt  Tracing, Drawing Studio, Coloring Book
  ui/PlaceholderScreens.kt  module placeholder + parent gate
```

## Content from the supplied PDFs

Animals category: ABC (26 flashcards), Urdu (40 letters, photos where the PDF has one) and
Numbers (20 animal photos) come from the PDFs; photos live in `res/drawable-nodpi`
Photos live in `res/drawable-nodpi`, one prefix per category: `an_` Animals, `bi_` Birds, `in_` Insects, `se_` Sea, `vg_` Vegetables, `fr_` Fruits, `th_` Things, `ve_` Vehicles, `bo_` Body, `sh_` Shapes, `na_` Nature, `we_` Weather, `co_` Colors. The app draws letters and names itself.
Fruits (26 English, 21 Urdu letters, 20 numbers) uses the supplied fruit photo sheets. Other categories only show their own words (nothing is
Vegetables (26 English, 17 Urdu letters, 20 numbers) uses the supplied vegetable sheets: 40 photos (`vg_*`). Colors, Things and Nature are still "coming soon".
Things (26 English, 27 Urdu letters, 20 numbers) uses the supplied object sheets: 54 photos (`th_*`). Nature and Colors are still "coming soon".
Nature (26 English, 23 Urdu letters, 20 numbers) uses the supplied nature sheets: 48 photos (`na_*`). Colors (26 English, 17 Urdu, 20 numbers) uses 36 photos (`co_*`). All 6 categories now have content.
borrowed from another category) and are placeholders until their PDFs are supplied.

## 3D pictures

Before each build `tools/fetch_emoji.py` downloads 3D emoji from Microsoft's
[Fluent Emoji](https://github.com/microsoft/fluentui-emoji) (MIT licence) into
`res/drawable-nodpi/e_<codepoint>.png`. The app shows them automatically; any emoji that
could not be downloaded falls back to the normal text emoji. Needs internet + python3 at build
time (GitHub Actions has both).

## Notes

- No `INTERNET` permission: fully offline by design.
- Urdu text uses the system font with RTL support enabled (`supportsRtl`). A bundled
  Urdu font (e.g. Noto Nastaliq Urdu) will be added in Phase 2.

## Phase 4 – Part 1: Mini-Games
`GameScreens.kt`: Memory (3/6/8 pairs), Match (picture to name, English + Urdu) and Picture Puzzle (2x2 / 3x3 swap). They use the selected category pictures. Mini-Games, Matching Games and Puzzles tiles all open this screen. Quizzes, Animal Care and the rest follow in the next parts.

## Categories (13)
Animals, Birds, Insects, Sea Creatures, Vegetables, Fruits, Things, Vehicles, Body Parts, Shapes, Nature, Weather, Colors. Each has English A–Z, Urdu letters and Numbers 1–20 from the supplied photo sheets.
Known gaps: Insects has no Cricket / Housefly / Ladybug photo yet (substitutes used); Body Parts letter Q uses a hair photo.

## Phase 4 – Part 2: Quizzes
`QuizzesScreen` (in `GameScreens.kt`): Name quiz, Letter quiz, Urdu quiz (picture shown, pick the answer) and Odd-one-out (two pictures from one category, one from another, mixed across all categories). The Quizzes tile opens it.

## Phase 5 Part 1 – Rewards & Sticker Book
- `Rewards.kt`: stars saved locally (SharedPreferences). Quizzes give 1 star per correct answer, Memory +3, Match +2, Puzzle +3/+5.
- Sticker Book: every 2 stars unlock one sticker (picture) across all categories.

## Phase 5 Part 2 – Worlds & Animal Sounds
- Animal Sounds: 22 animals/birds/insects, tap to hear the sound (TTS), plus a "Who says?" quiz.
- Worlds: Farm, Jungle, Ocean, Sky, Garden. Explore (tap to hear name) and "Find it" quiz. Both give stars.

## Phase 5 Part 3 – Music & Stories
- Music: offline synthesized piano (AudioTrack, no audio files), 8 colored keys, 3 auto-play songs with lit keys.
- Stories: 5 short illustrated stories read aloud with TTS (Read to me / Next / Back); finishing gives +2 stars.

## Phase 4 – Animal Care
- Pick a pet (rabbit, horse, cow, sheep, hen, duck, panda); Feed / Water / Wash / Play / Sleep fill meters. All full = +3 stars.

## Phase 6 – Progress & Parent Section
- Parent gate: 4-digit PIN (or a sum if no PIN / forgot PIN).
- Progress tab: stars, stickers, play time today, favourite activities.
- Settings tab: daily time limit (Off/15/30/45/60 min), set/remove PIN, reset progress.
- When the limit is reached the app shows a "Time is up" screen; a parent can add 15 minutes. Only on-screen time counts.
- All data in local SharedPreferences (`ParentStore.kt`), nothing leaves the device.

## Phase 7 – Release prep
- Version 1.0.0 (code 2). No INTERNET permission, no ads, backup disabled (PIN stays on device).
- `res/raw/keep.xml` stops the resource shrinker removing photos that are loaded by name.
- Workflow now builds both debug and release APKs (release is signed with the debug key for testing; use your own keystore for Play Store).
- See TESTING.md for the on-device checklist.

## Update – More stories
- Stories now 15 (10 new, English). Story list scrolls.

## Update – Learning List
- New home tile "Learning List": for the selected category lists every A–Z picture and 1–20 picture with English + Urdu names; tap a name to hear it.

## Update – Math for toddlers
- New tile "Math": Count (1–10 pictures), Add, Take away, More/Less, Order (before/after/missing). Uses photos/emoji already in the app; gives stars through QuizView.
- Opposites & Position words need new photo sheets (see Toddler_Vocabulary_Pack_Part9.md, sheets 9–11).

## Update – Urdu stories
- Stories screen has English / اردو tabs; 8 Urdu stories read aloud with the Urdu TTS voice (needs Urdu voice installed on the phone).

## Update – Voice choice
- Parent > Settings > Voice: per language (English / اردو) pick Auto, Offline or Online voice, test it, and open the phone's voice settings to download voices. Online voices are provided by the phone's speech engine; the app still has no INTERNET permission.

## Update – Daily reward, streak, tutorial (Part A of "add everything")
- Lulu the owl 🦉 gives +1 star on the first open each day, +3 bonus every 5th day in a row. 3-page parent tutorial on first run.

## Update – Child profiles (Part B)
- Up to 3 children (Parent > Settings > Children): own name, stars, stickers, streak and activity history. "Who is playing?" appears at start when more than one child exists. Profile 1 keeps the old data. Play-time limit and PIN are shared.

## Update – Rhymes, Lullabies & Bedtime mode (Part C)
- New tile "Rhymes & Lullabies": 12 original rhymes/lullabies (English + اردو) sung line by line with TTS, current line highlighted; +1 star per full play.
- Parent > Settings > Bedtime mode: home shows only Stories, Music and Rhymes.

## Update – Islamic Learning (Part D)
- New tile "Islamic Learning": 12 duas, 10 names of Allah, 5 pillars, 5 prayers (with fard rakats), special days; Arabic + Urdu + English with 🔊 buttons (Arabic voice depends on the phone's TTS), and a quiz. **Please have an elder/scholar verify the Arabic text before publishing.**

## Update – Fun Games (Part E)
- New tile "Fun Games": Shape Sorter (tap shape, tap hole), Find it (hidden object scenes from the selected category), Bubble Pop (numbers / letters), Dots Join (House, Rocket, Star, Boat). All give stars.

## Update – Habits & Sounds (Part F)
- New tile "Habits & Sounds": 5 step-by-step routines (wash hands, brush teeth, get dressed, school, bedtime) in English + اردو, read aloud, +2 stars; and a "Guess the sound" quiz (spoken sounds, no audio files).

## Update – Report, Backup & Themes (Part G)
- Parent > Progress: quiz accuracy per category/area (first-try correct), weak spots flagged below 60%.
- Parent > Settings > Backup & restore: share a text code and paste it on another phone (PIN not included).
- Home background tints with the selected category colour.

## Update – Vocabulary module
- New tile "Vocabulary": groups Family, Home, Food, Clothes, Toys, Actions, Feelings, School, Opposites, Positions. A group shows words whose photo exists as `res/drawable-nodpi/vo_<group>_<slug>.jpg` (group keys: family, home, food, clothes, toys, actions, feelings, school, opp, pos). Family sheet is in; more sheets are added by cropping into that naming scheme.
- Vocabulary words without a photo fall back to an emoji (third field in `VocabScreens.kt`), so groups are usable before all photo sheets arrive; a photo with the right name always takes priority.

## Update – Make Words, Days & Months
- "Make Words": spell the picture's word (3–6 letters) by tapping shuffled letters, from the selected category. English only for now.
- "Days & Months": weekdays (Mon–Sun, اردو names), months, Islamic months, a "Today is ..." card and a quiz.

## Update – Clock & Rupees
- "Learn the Clock": analog clock (hour buttons + :00/:15/:30/:45), spoken time ("half past 3"), quiz reading the clock.
- "Rupees": Learn coins/notes (English + اردو), Count (how much money is this?), Shop (pay the exact price). Drawn in code; toy money, not real currency artwork.

## Update – Spot the Difference, What Comes Next?, Make a Story
- Spot the Difference: 3 differences (added shapes or a white patch) on a copy of a photo from the selected category; tap them in the lower picture.
- What Comes Next?: put 3–4 emoji cards in order (plant, butterfly, day, growing up, rain, getting ready).
- Make a Story: pick 3 pictures, the app writes and reads a short story (3 templates). English only.

## Update – Blocks, Age levels, Vocabulary photos
- "Build Blocks": 6 colours, tap a column to drop a block, undo/clear, +2 stars for 10 blocks.
- Age level per child (Parent > Settings): 2–3 years (easier) or 4–5 years (standard). Affects Math ranges, Clock, Rupees, Bubble Pop, Find it, Make Words, Memory and Puzzle start level.
- Vocabulary photos added: Clothes, Home, Food (36 photos `vo_clothes_*`, `vo_home_*`, `vo_food_*`).

## Update – Urdu Make Words, Maze
- Make Words now has English / اردو tabs. Urdu: spell the Urdu name of the picture from shuffled letters (right-to-left slots).
- "Maze": random maze (4x4 easy / 6x6 standard); drag a finger from the animal to its food. +2 stars.

## Update – Go Together (pairs)
- "Go Together": match what goes together (key–lock, shoe–sock, rabbit–carrot ...). 16 emoji pairs, 3 per round (easy) or 4. +2 stars.

## Colour Mixing challenge + Coloring Pages
- **Color Mixing → Challenge tab**: 5 rounds, "Make Orange!" — the child taps two paint colours. Stars = score; right/wrong feeds the parent Progress ("Mixing").
- **Coloring Pages** (new tile): 35 outline pictures (Animals, Birds, Fruits, Vehicles, Insects) in `res/drawable-nodpi/cp_<photo>.png`, generated from the app's own photos (silhouette + a few big regions). Tap to fill (flood-fill), Clear, Save to Pictures/LittleLearners (+1 star).
- To add more pages: drop `cp_<prefix>_<name>.png` (black lines on white) and add the slug to `pageGroups` in `ColorPagesScreen.kt`.
- Phone-check: fill works inside every shape; outlines with small gaps leak colour into the background (tell me which picture).

## Urdu font (Nastaliq)
- `res/font/jameel_noori.ttf` = Jameel Noori Nastaleeq (supplied by the project owner). Check its licence before a Play Store release.
- Arabic with harakat (duas) is excluded and uses the system Naskh font. `ui/UrduText.kt` defines `Text` in the `ui` package; any text containing Urdu letters automatically uses the font (Latin text is unchanged). New screens just use `Text(...)` and don't import `material3.Text`.
- Phone-check: Nastaliq is tall — look for clipped Urdu in small buttons/tiles and tell me which.

## Splash, Welcome and interactive Dashboard
- `SplashScreen.kt`: ~2.5 s animated start (bouncing logo, floating emoji, loading bar; tap to skip). The window background is cream (`splash_bg`) so there is no white flash.
- `WelcomeDialogs.kt` (`WelcomeFlow`): now full screen — 3 animated pages with Lulu (first run), "Who is playing?" with big avatar cards, and the daily-star screen with a pop animation and a 5-day streak row.
- Home (`HomeScreen.kt`, `DashboardParts.kt`): greeting + child avatar, ⭐ stars pill (opens Sticker Book), 🔥 streak, Lulu card (tap: she jumps and speaks a tip), "Continue playing" card (last opened activity), tiles pop in one by one and squish when pressed.
- Phone-check: animation smoothness on a low-end phone, and that the Welcome screen covers the whole screen.

## Vocabulary photos
Realistic photos now exist for every Vocabulary group (Family, Home, Food, Clothes, Toys, Actions, Feelings, School & Daily, Opposites, Positions). Pairs (Big/Small, Tall/Short, Long/Short) share one canvas size so the size difference shows.
