# Little Learners (Kotlin)

Offline, ad-free, no-login toddler learning app for ages 2–5.
Native Android: **Kotlin + Jetpack Compose**. Min SDK 24 (low-end friendly).

## Status

| Phase | Scope | State |
|---|---|---|
| 1 | Home screen, 6-category switcher (remembered locally), navigation, parent gate | **Done** |
| 2 | Numbers 1–20, English ABC, Urdu alphabet (RTL), Colors, Color Mixing, quizzes, speech | **Done** |
| 3 | Tracing Center (123/ABC/Urdu), Drawing Studio, Coloring Book (4 pictures), save to gallery | **Done** |
| 4 | Mini-games, puzzles, matching, quizzes | Next |
| 5 | Audio, stories, worlds, stickers, rewards | Planned |
| 6 | Progress tracking, Parent Area, offline storage | Planned |
| 7 | Testing, bug fixing, release | Planned |

Phase 2 uses the phone's built-in text-to-speech (offline once the voice is installed; Urdu is silent if no Urdu voice is installed).
App logo: adaptive icon + legacy PNGs in `res/mipmap-*`, header logo in `res/drawable-nodpi/logo.png`.

Saved artwork goes to Pictures/LittleLearners (Android 10+) or the app's own Pictures folder on older phones; no storage permission needed.

Tiles for later phases open a "Coming in Phase N" placeholder.

## Get the APK from GitHub (no Android Studio needed)

1. Create a new GitHub repo and push this folder:
   ```bash
   git init
   git add .
   git commit -m "Phase 1: home screen and category switcher"
   git branch -M main
   git remote add origin https://github.com/<you>/LittleLearners.git
   git push -u origin main
   ```
2. Open the repo's **Actions** tab → **Build APK** run.
3. Download the `LittleLearners-debug` artifact (a zip containing the `.apk`).
4. Copy it to your phone and install (allow "install unknown apps").

## Build locally with Android Studio

1. Install Android Studio (Koala or newer) with JDK 17.
2. **File → Open** this folder, let Gradle sync (Android Studio creates the Gradle wrapper).
3. Run on a device/emulator, or **Build → Build APK(s)**.
4. Output: `app/build/outputs/apk/debug/app-debug.apk`.

Command line (with Gradle 8.7 installed): `gradle assembleDebug` / `gradle assembleRelease`.

## Release signing

The release build is signed with the debug key so it installs for testing.
Before publishing to Google Play, create your own keystore and replace the
`signingConfig` in `app/build.gradle.kts`. Never commit the keystore (it is gitignored).

## Project layout

```
app/src/main/java/com/littlelearners/app/
  MainActivity.kt        navigation (home, module placeholder, parents)
  Models.kt              Category and LearningModule definitions
  Prefs.kt               local storage (last category)
  ui/Theme.kt            rainbow/pastel theme
  ui/HomeScreen.kt       header, category switcher, module grid
  Content.kt             numbers, alphabets, colors data
  Speaker.kt             text-to-speech wrapper
  ui/Common.kt           scaffold, tabs, generic quiz
  ui/LearningScreens.kt  Numbers, ABC, Urdu, Colors, Color Mixing
  ui/DrawingEngine.kt    strokes, colorable pictures, PNG saving
  ui/CreativeScreens.kt  Tracing, Drawing Studio, Coloring Book
  ui/PlaceholderScreens.kt  module placeholder + parent gate
```

## Content from the supplied PDFs

Animals category: ABC (26 flashcards), Urdu (40 letters, photos where the PDF has one) and
Numbers (20 animal photos) come from the PDFs; photos live in `res/drawable-nodpi`
(`abc_*`, `abcq_*`, `ur_*`, `num_*`). Fruits: 42 photos (`fr_*`) sliced from the supplied sheets; the app draws the letters/names itself.
Other categories only show their own words (nothing is
borrowed from another category) and are placeholders until their PDFs are supplied.

## 3D pictures

Before each build `tools/fetch_emoji.py` downloads 3D emoji from Microsoft's
[Fluent Emoji](https://github.com/microsoft/fluentui-emoji) (MIT licence) into
`res/drawable-nodpi/e_<codepoint>.png`. The app shows them automatically; any emoji that
could not be downloaded falls back to the normal text emoji. Needs internet + python3 at build
time (GitHub Actions has both).

## Notes

- No `INTERNET` permission: fully offline by design.
- Urdu text uses the system font with RTL support enabled (`supportsRtl`). A bundled
  Urdu font (e.g. Noto Nastaliq Urdu) will be added in Phase 2.
